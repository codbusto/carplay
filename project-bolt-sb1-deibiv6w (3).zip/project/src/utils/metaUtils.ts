// Meta tag utility functions for dynamic SEO
export const updateMetaTags = (metaData: {
  title?: string;
  description?: string;
  ogTitle?: string;
  ogDescription?: string;
  ogImage?: string;
  ogUrl?: string;
  twitterTitle?: string;
  twitterDescription?: string;
  twitterImage?: string;
}) => {
  // Update title
  if (metaData.title) {
    document.title = metaData.title;
  }

  // Update meta description
  if (metaData.description) {
    updateMetaTag('name', 'description', metaData.description);
  }

  // Update Open Graph tags
  if (metaData.ogTitle) {
    updateMetaTag('property', 'og:title', metaData.ogTitle);
  }
  if (metaData.ogDescription) {
    updateMetaTag('property', 'og:description', metaData.ogDescription);
  }
  if (metaData.ogImage) {
    updateMetaTag('property', 'og:image', metaData.ogImage);
  }
  if (metaData.ogUrl) {
    updateMetaTag('property', 'og:url', metaData.ogUrl);
  }

  // Update Twitter tags
  if (metaData.twitterTitle) {
    updateMetaTag('property', 'twitter:title', metaData.twitterTitle);
  }
  if (metaData.twitterDescription) {
    updateMetaTag('property', 'twitter:description', metaData.twitterDescription);
  }
  if (metaData.twitterImage) {
    updateMetaTag('property', 'twitter:image', metaData.twitterImage);
  }
};

const updateMetaTag = (attribute: string, name: string, content: string) => {
  let element = document.querySelector(`meta[${attribute}="${name}"]`) as HTMLMetaElement;
  
  if (element) {
    element.content = content;
  } else {
    element = document.createElement('meta');
    element.setAttribute(attribute, name);
    element.content = content;
    document.head.appendChild(element);
  }
};

// Predefined meta data for different pages - NO IMAGES
export const getMetaDataForPage = (page: string) => {
  const baseUrl = 'https://tuttosconto.store';
  
  switch (page) {
    case 'hair-straightener':
      return {
        title: 'Tuttosconto - Eccellenza Italiana',
        description: 'Eccellenza Italiana',
        ogTitle: 'Tuttosconto - Eccellenza Italiana',
        ogDescription: 'Eccellenza Italiana',
        ogUrl: `${baseUrl}/piastra-capelli`,
        twitterTitle: 'Tuttosconto - Eccellenza Italiana',
        twitterDescription: 'Eccellenza Italiana'
        // Removed ogImage and twitterImage
      };
    
    case 'tritatutto':
      return {
        title: 'Tuttosconto - Eccellenza Italiana',
        description: 'Eccellenza Italiana',
        ogTitle: 'Tuttosconto - Eccellenza Italiana',
        ogDescription: 'Eccellenza Italiana',
        ogUrl: `${baseUrl}/tritatutto`,
        twitterTitle: 'Tuttosconto - Eccellenza Italiana',
        twitterDescription: 'Eccellenza Italiana'
        // Removed ogImage and twitterImage
      };
    
    case 'carplay':
      return {
        title: 'Tuttosconto - Eccellenza Italiana',
        description: 'Eccellenza Italiana',
        ogTitle: 'Tuttosconto - Eccellenza Italiana',
        ogDescription: 'Eccellenza Italiana',
        ogImage: `${baseUrl}/Immagine 2025-07-08 221317 copy copy copy.jpg`,
        ogImage: `${baseUrl}/Immagine 2025-07-08 221317 copy copy copy copy.jpg`,
        ogUrl: `${baseUrl}/carplay`,
        twitterTitle: 'Tuttosconto - Eccellenza Italiana',
        twitterDescription: 'Eccellenza Italiana',
        twitterImage: `${baseUrl}/Immagine 2025-07-08 221317 copy copy copy.jpg`
        // Removed ogImage and twitterImage
      };
    
    case 'idropulitrice':
    default:
      return {
        title: 'Tuttosconto - Eccellenza Italiana',
        description: 'Eccellenza Italiana',
        ogTitle: 'Tuttosconto - Eccellenza Italiana',
        ogDescription: 'Eccellenza Italiana',
        ogUrl: baseUrl,
        twitterTitle: 'Tuttosconto - Eccellenza Italiana',
        twitterDescription: 'Eccellenza Italiana',
        twitterImage: `${baseUrl}/Immagine 2025-07-08 221317 copy copy copy copy.jpg`
      };
  }
};