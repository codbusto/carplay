// Crisp Chat integration utility
declare global {
  interface Window {
    $crisp: any;
    CRISP_WEBSITE_ID: string;
  }
}

export const initCrispChat = () => {
  if (typeof window === 'undefined') return;

  // Set Crisp website ID
  window.CRISP_WEBSITE_ID = "6a6294e3-0f21-4a7f-a7c8-e5bcc0af8d8c";

  // Load Crisp chat script
  (function() {
    const d = document;
    const s = d.createElement("script");
    s.src = "https://client.crisp.chat/l.js";
    s.async = true;
    d.getElementsByTagName("head")[0].appendChild(s);
  })();

  // Adjust Crisp position after it loads - multiple attempts to ensure it works
  setTimeout(() => {
    adjustCrispPosition();
  }, 1000);
  
  setTimeout(() => {
    adjustCrispPosition();
  }, 3000);
  
  setTimeout(() => {
    adjustCrispPosition();
  }, 5000);

  console.log('💬 Crisp Chat initialized with ID: 6a6294e3-0f21-4a7f-a7c8-e5bcc0af8d8c');
};

// Adjust Crisp chat position to be well above the order button
export const adjustCrispPosition = () => {
  if (typeof window === 'undefined') return;

  // Remove any existing Crisp position styles
  const existingStyle = document.getElementById('crisp-position-fix');
  if (existingStyle) {
    existingStyle.remove();
  }

  // Add custom CSS to move Crisp chat much higher and more to the right
  const style = document.createElement('style');
  style.id = 'crisp-position-fix';
  style.textContent = `
    /* IMPORTANT: Move Crisp chat widget higher and more to the right */
    .crisp-client .cc-tlyw {
      bottom: 140px !important; /* Moved up significantly */
      right: 25px !important; /* Moved right */
      z-index: 35 !important; /* Below fixed order button (z-40) */
      position: fixed !important;
    }
    
    /* Mobile specific positioning - even higher and more right */
    @media (max-width: 768px) {
      .crisp-client .cc-tlyw {
        bottom: 160px !important; /* Much higher on mobile */
        right: 20px !important; /* More to the right on mobile */
        z-index: 35 !important;
      }
    }
    
    /* Chat window positioning when opened */
    .crisp-client .cc-kxtf {
      bottom: 200px !important; /* Higher to match chat bubble */
      right: 25px !important; /* Aligned with chat bubble */
      z-index: 35 !important;
      position: fixed !important;
    }
    
    @media (max-width: 768px) {
      .crisp-client .cc-kxtf {
        bottom: 220px !important; /* Very high on mobile */
        right: 20px !important; /* Aligned with mobile chat bubble */
        max-height: calc(100vh - 260px) !important; /* Prevent overflow */
      }
    }
    
    /* Ensure chat bubble stays in position during animations */
    .crisp-client .cc-tlyw.cc-1vwt {
      transform: translateY(0) !important;
      bottom: 140px !important;
      right: 25px !important;
    }
    
    @media (max-width: 768px) {
      .crisp-client .cc-tlyw.cc-1vwt {
        bottom: 160px !important;
        right: 20px !important;
      }
    }
    
    /* Override any inline styles that might interfere */
    .crisp-client .cc-tlyw[style] {
      bottom: 140px !important;
      right: 25px !important;
    }
    
    @media (max-width: 768px) {
      .crisp-client .cc-tlyw[style] {
        bottom: 160px !important;
        right: 20px !important;
      }
    }
    
    /* Ensure the order button area is clear */
    .crisp-client .cc-tlyw:not(.cc-1vwt) {
      bottom: 140px !important;
      right: 25px !important;
    }
    
    @media (max-width: 768px) {
      .crisp-client .cc-tlyw:not(.cc-1vwt) {
        bottom: 160px !important;
        right: 20px !important;
      }
    }
    
    /* Additional positioning overrides for stubborn cases */
    .crisp-client .cc-tlyw,
    .crisp-client .cc-tlyw.cc-unoo,
    .crisp-client .cc-tlyw.cc-1vwt.cc-unoo {
      bottom: 140px !important;
      right: 25px !important;
    }
    
    @media (max-width: 768px) {
      .crisp-client .cc-tlyw,
      .crisp-client .cc-tlyw.cc-unoo,
      .crisp-client .cc-tlyw.cc-1vwt.cc-unoo {
        bottom: 160px !important;
        right: 20px !important;
      }
    }
  `;
  
  document.head.appendChild(style);
  
  // Also try to adjust via Crisp API if available
  if (window.$crisp) {
    try {
      // Set chat position via Crisp API
      window.$crisp.push(["config", "position:reverse", [true]]);
      window.$crisp.push(["config", "position:x", ["right"]]);
      window.$crisp.push(["config", "position:y", ["bottom"]]);
    } catch (e) {
      console.log('Crisp API positioning not available yet');
    }
  }
  
  console.log('💬 Crisp position adjusted: moved up and right for better placement');
};

// Set user data for better support
export const setCrispUserData = (userData: {
  email?: string;
  name?: string;
  phone?: string;
  [key: string]: any;
}) => {
  if (typeof window !== 'undefined' && window.$crisp) {
    if (userData.email) {
      window.$crisp.push(["set", "user:email", userData.email]);
    }
    if (userData.name) {
      window.$crisp.push(["set", "user:nickname", userData.name]);
    }
    if (userData.phone) {
      window.$crisp.push(["set", "user:phone", userData.phone]);
    }
    
    // Set custom data
    Object.keys(userData).forEach(key => {
      if (!['email', 'name', 'phone'].includes(key)) {
        window.$crisp.push(["set", "session:data", [[key, userData[key]]]]);
      }
    });
    
    console.log('💬 Crisp user data set:', userData);
  }
};

// Send a message to Crisp
export const sendCrispMessage = (message: string) => {
  if (typeof window !== 'undefined' && window.$crisp) {
    window.$crisp.push(["do", "message:send", ["text", message]]);
  }
};

// Open Crisp chat
export const openCrispChat = () => {
  if (typeof window !== 'undefined' && window.$crisp) {
    window.$crisp.push(["do", "chat:open"]);
  }
};

// Close Crisp chat
export const closeCrispChat = () => {
  if (typeof window !== 'undefined' && window.$crisp) {
    window.$crisp.push(["do", "chat:close"]);
  }
};

// Set Crisp availability
export const setCrispAvailability = (available: boolean) => {
  if (typeof window !== 'undefined' && window.$crisp) {
    window.$crisp.push(["set", "chat:availability", available ? "online" : "away"]);
  }
};

// Track Crisp events
export const trackCrispEvent = (eventName: string, data?: any) => {
  if (typeof window !== 'undefined' && window.$crisp) {
    try {
      // Ensure eventName is a valid string
      if (!eventName || typeof eventName !== 'string') {
        console.warn('💬 Crisp Event: Invalid event name', eventName);
        return;
      }

      // Prepare the data for Crisp - it expects specific formats
      let eventData;
      if (data !== undefined && data !== null) {
        // Convert data to string if it's an object or complex type
        if (typeof data === 'object') {
          eventData = JSON.stringify(data);
        } else {
          eventData = String(data);
        }
      } else {
        eventData = '';
      }

      // Push the event to Crisp with proper format
      window.$crisp.push(["set", "session:event", [[eventName, eventData]]]);
      console.log(`💬 Crisp Event: ${eventName}`, eventData);
    } catch (error) {
      console.warn('💬 Crisp Event Error:', error, { eventName, data });
    }
  }
};

// Force reposition function that can be called manually
export const forceCrispReposition = () => {
  adjustCrispPosition();
  
  // Also try to force reposition via DOM manipulation
  setTimeout(() => {
    const crispWidget = document.querySelector('.crisp-client .cc-tlyw') as HTMLElement;
    if (crispWidget) {
      crispWidget.style.bottom = window.innerWidth <= 768 ? '160px' : '140px';
      crispWidget.style.right = window.innerWidth <= 768 ? '20px' : '25px';
      crispWidget.style.zIndex = '35';
      crispWidget.style.position = 'fixed';
    }
  }, 500);
};