// Microsoft Clarity tracking utility functions
declare global {
  interface Window {
    clarity: any;
  }
}

// Track custom events in Clarity
export const trackClarityEvent = (eventName: string, data?: Record<string, any>) => {
  if (typeof window !== 'undefined' && window.clarity) {
    window.clarity('event', eventName, data);
    console.log(`📊 Clarity Event: ${eventName}`, data);
  }
};

// Track user interactions
export const trackOrderFormOpen = () => {
  trackClarityEvent('order_form_opened', {
    timestamp: new Date().toISOString(),
    page: 'landing_page'
  });
};

export const trackOrderFormSubmit = (orderData: {
  orderNumber: string;
  totalAmount: number;
  quantity: number;
}) => {
  trackClarityEvent('order_submitted', {
    order_number: orderData.orderNumber,
    total_amount: orderData.totalAmount,
    quantity: orderData.quantity,
    timestamp: new Date().toISOString()
  });
};

export const trackSectionView = (sectionName: string) => {
  trackClarityEvent('section_viewed', {
    section: sectionName,
    timestamp: new Date().toISOString()
  });
};

export const trackButtonClick = (buttonName: string, location: string) => {
  trackClarityEvent('button_clicked', {
    button: buttonName,
    location: location,
    timestamp: new Date().toISOString()
  });
};

export const trackFAQInteraction = (question: string) => {
  trackClarityEvent('faq_clicked', {
    question: question,
    timestamp: new Date().toISOString()
  });
};

export const trackContactAttempt = (method: 'phone' | 'email') => {
  trackClarityEvent('contact_attempted', {
    method: method,
    timestamp: new Date().toISOString()
  });
};

// Set user properties for better segmentation
export const setClarityUserProperties = (properties: Record<string, any>) => {
  if (typeof window !== 'undefined' && window.clarity) {
    window.clarity('set', properties);
    console.log('📊 Clarity User Properties Set:', properties);
  }
};

// Identify user sessions (useful for tracking returning visitors)
export const identifyClarityUser = (userId: string) => {
  if (typeof window !== 'undefined' && window.clarity) {
    window.clarity('identify', userId);
    console.log('📊 Clarity User Identified:', userId);
  }
};