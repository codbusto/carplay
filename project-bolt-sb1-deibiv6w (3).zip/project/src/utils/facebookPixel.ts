// Facebook Pixel utility functions
declare global {
  interface Window {
    fbq: any;
  }
}

// Event deduplication system
const firedEvents = new Set<string>();

// Generate consistent event ID for deduplication
const generateEventId = (eventName: string, data?: any): string => {
  const baseData = {
    event: eventName,
    page: window.location.pathname,
    timestamp: Math.floor(Date.now() / 1000), // Round to seconds to allow some deduplication
    ...data
  };
  
  const dataString = JSON.stringify(baseData);
  return `${eventName}_${btoa(dataString).slice(0, 16)}`;
};

// Check if event was already fired
const isEventAlreadyFired = (eventId: string): boolean => {
  if (firedEvents.has(eventId)) {
    console.log(`⚠️ Event already fired, skipping: ${eventId}`);
    return true;
  }
  firedEvents.add(eventId);
  return false;
};

// Initialize Facebook Pixel with ONLY the specified pixel
export const initFacebookPixel = () => {
  if (typeof window === 'undefined') return;

  // Facebook Pixel Code
  (function(f: any, b: any, e: any, v: any, n: any, t: any, s: any) {
    if (f.fbq) return;
    n = f.fbq = function() {
      n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments);
    };
    if (!f._fbq) f._fbq = n;
    n.push = n;
    n.loaded = !0;
    n.version = '2.0';
    n.queue = [];
    t = b.createElement(e);
    t.async = !0;
    t.src = v;
    s = b.getElementsByTagName(e)[0];
    s.parentNode.insertBefore(t, s);
  })(window, document, 'script', 'https://connect.facebook.net/en_US/fbevents.js');

  // Initialize ONLY the specified Facebook Pixel
  window.fbq('init', '1077076157172275');
  console.log('📊 Facebook Pixel initialized: 1077076157172275');
  
  // Track PageView ONLY ONCE
  const pageViewEventId = generateEventId('PageView', { url: window.location.href });
  if (!isEventAlreadyFired(pageViewEventId)) {
    window.fbq('track', 'PageView');
    console.log('📊 PageView tracked');
  }
};

// Single event tracking function with deduplication
export const trackEvent = (eventName: string, parameters?: any) => {
  if (typeof window === 'undefined' || !window.fbq) return;

  const eventId = generateEventId(eventName, parameters);
  
  if (isEventAlreadyFired(eventId)) {
    return eventId;
  }

  window.fbq('track', eventName, parameters, {eventID: eventId});
  console.log(`📊 Facebook Pixel: ${eventName}`, parameters, `EventID: ${eventId}`);
  
  return eventId;
};

// Custom event tracking with deduplication
export const trackCustomEvent = (eventName: string, parameters?: any) => {
  if (typeof window === 'undefined' || !window.fbq) return;

  const eventId = generateEventId(`Custom_${eventName}`, parameters);
  
  if (isEventAlreadyFired(eventId)) {
    return eventId;
  }

  window.fbq('trackCustom', eventName, parameters, {eventID: eventId});
  console.log(`📊 Facebook Pixel Custom: ${eventName}`, parameters, `EventID: ${eventId}`);
  
  return eventId;
};

// LEAD TRACKING - All forms will track as Lead events
export const trackLead = (leadData: {
  content_name?: string;
  value?: number;
  currency?: string;
  customer_name?: string;
  customer_phone?: string;
  order_number?: string;
  [key: string]: any;
}) => {
  if (typeof window === 'undefined' || !window.fbq) return null;

  const eventData = {
    content_name: leadData.content_name || 'Tuttosconto Product',
    content_category: leadData.content_category || 'E-commerce',
    content_type: 'product',
    value: leadData.value || 49.99,
    currency: 'EUR',
    ...leadData
  };
  
  // Generate unique event ID for this specific lead
  const leadEventId = generateEventId('Lead', {
    order_number: leadData.order_number,
    customer_phone: leadData.customer_phone
  });
  
  if (isEventAlreadyFired(leadEventId)) {
    return { leadEventID: leadEventId };
  }

  // Track Lead event
  window.fbq('track', 'Lead', eventData, {eventID: leadEventId});
  
  console.log('🎯 LEAD TRACKED:', eventData);
  console.log('🎯 Lead Event ID:', leadEventId);
  
  return { leadEventID: leadEventId };
};

// Simplified InitiateCheckout tracking
export const trackInitiateCheckout = (productData?: any) => {
  let defaultData = {
    content_name: 'Tuttosconto Product',
    content_category: 'E-commerce',
    value: 49.99,
    currency: 'EUR',
    num_items: 1
  };
  
  // Auto-detect product based on current page
  if (window.location.pathname.includes('tritatutto')) {
    defaultData = {
      content_name: 'Tritatutto Elettrico 3-in-1',
      content_category: 'Kitchen & Dining',
      value: 54.99,
      currency: 'EUR',
      num_items: 1
    };
  } else if (window.location.pathname.includes('piastra-capelli')) {
    defaultData = {
      content_name: 'Piastra Capelli Crasts',
      content_category: 'Beauty & Personal Care',
      value: 34.99,
      currency: 'EUR',
      num_items: 1
    };
  } else if (window.location.pathname.includes('carplay')) {
    defaultData = {
      content_name: 'CarPlay Android Auto Display',
      content_category: 'Electronics',
      value: 79.99,
      currency: 'EUR',
      num_items: 1
    };
  } else if (window.location.pathname === '/') {
    defaultData = {
      content_name: 'Idropulitrice Professionale 21V',
      content_category: 'Home & Garden',
      value: 54.99,
      currency: 'EUR',
      num_items: 1
    };
  }
  
  return trackEvent('InitiateCheckout', {
    ...defaultData,
    ...productData
  });
};

// Simplified ViewContent tracking
export const trackViewContent = (contentName: string, contentType: string = 'product') => {
  let eventData = {
    content_name: contentName,
    content_type: contentType,
    content_category: 'E-commerce',
    value: 49.99,
    currency: 'EUR'
  };
  
  // Auto-detect product values
  if (contentName.includes('Tritatutto') || window.location.pathname.includes('tritatutto')) {
    eventData = {
      content_name: 'Tritatutto Elettrico 3-in-1',
      content_type: contentType,
      content_category: 'Kitchen & Dining',
      value: 54.99,
      currency: 'EUR'
    };
  } else if (contentName.includes('Piastra') || window.location.pathname.includes('piastra-capelli')) {
    eventData = {
      content_name: 'Piastra Capelli Crasts',
      content_type: contentType,
      content_category: 'Beauty & Personal Care',
      value: 34.99,
      currency: 'EUR'
    };
  } else if (contentName.includes('CarPlay') || window.location.pathname.includes('carplay')) {
    eventData = {
      content_name: 'CarPlay Android Auto Display',
      content_type: contentType,
      content_category: 'Electronics',
      value: 79.99,
      currency: 'EUR'
    };
  } else if (contentName.includes('Idropulitrice')) {
    eventData = {
      content_name: 'Idropulitrice Professionale 21V',
      content_type: contentType,
      content_category: 'Home & Garden',
      value: 54.99,
      currency: 'EUR'
    };
  }
  
  return trackEvent('ViewContent', eventData);
};

// Simplified AddToCart tracking
export const trackAddToCart = (quantity: number = 1) => {
  let productData = {
    content_name: 'Tuttosconto Product',
    content_category: 'E-commerce',
    value: 49.99
  };
  
  // Auto-detect product based on current page
  if (window.location.pathname.includes('tritatutto')) {
    productData = {
      content_name: 'Tritatutto Elettrico 3-in-1',
      content_category: 'Kitchen & Dining',
      value: 54.99
    };
  } else if (window.location.pathname.includes('piastra-capelli')) {
    productData = {
      content_name: 'Piastra Capelli Crasts',
      content_category: 'Beauty & Personal Care',
      value: 34.99
    };
  } else if (window.location.pathname.includes('carplay')) {
    productData = {
      content_name: 'CarPlay Android Auto Display',
      content_category: 'Electronics',
      value: 79.99
    };
  } else if (window.location.pathname === '/') {
    productData = {
      content_name: 'Idropulitrice Professionale 21V',
      content_category: 'Home & Garden',
      value: 54.99
    };
  }
  
  return trackEvent('AddToCart', {
    ...productData,
    value: productData.value * quantity,
    currency: 'EUR',
    num_items: quantity
  });
};

// Contact tracking
export const trackContact = () => {
  return trackCustomEvent('Contact', {
    content_name: 'Contact Form',
    content_category: 'Customer Service'
  });
};

// Test pixel connection
export const testPixelConnection = () => {
  let fbWorking = false;
  
  if (typeof window !== 'undefined') {
    if (window.fbq) {
      console.log('📊 Facebook Pixel is loaded and working');
      fbWorking = true;
    } else {
      console.error('❌ Facebook Pixel not loaded');
    }
  }
  
  return { facebook: fbWorking };
};

// Legacy functions for backward compatibility - all redirect to trackLead
export const trackTritatuttoLead = (leadData: any) => {
  return trackLead({
    content_name: 'Tritatutto Elettrico 3-in-1',
    content_category: 'Kitchen & Dining',
    value: 54.99,
    ...leadData
  });
};

export const trackPiastraCapelliLead = (leadData: any) => {
  return trackLead({
    content_name: 'Piastra Capelli Crasts',
    content_category: 'Beauty & Personal Care',
    value: 34.99,
    ...leadData
  });
};

export const trackCarPlayLead = (leadData: any) => {
  return trackLead({
    content_name: 'CarPlay Android Auto Display',
    content_category: 'Electronics',
    value: 79.99,
    ...leadData
  });
};

export const trackPiastraCapelliSale = (saleData: any) => {
  return trackLead({
    content_name: 'Piastra Capelli Crasts',
    content_category: 'Beauty & Personal Care',
    value: 34.99,
    ...saleData
  });
};

export const trackTritatuttoSale = (saleData: any) => {
  return trackLead({
    content_name: 'Tritatutto Elettrico 3-in-1',
    content_category: 'Kitchen & Dining',
    value: 54.99,
    ...saleData
  });
};

export const trackSale = (saleData: any) => {
  return trackLead(saleData);
};

// Event tracking functions
export const trackTritatuttoEvent = (eventName: string, eventData?: any) => {
  const enhancedData = {
    content_name: 'Tritatutto Elettrico 3-in-1',
    content_category: 'Kitchen & Dining',
    value: 54.99,
    currency: 'EUR',
    ...eventData
  };
  
  return trackEvent(eventName, enhancedData);
};

export const trackPiastraCapelliEvent = (eventName: string, eventData?: any) => {
  const enhancedData = {
    content_name: 'Piastra Capelli Crasts',
    content_category: 'Beauty & Personal Care',
    value: 34.99,
    currency: 'EUR',
    ...eventData
  };
  
  return trackEvent(eventName, enhancedData);
};

export const trackCarPlayEvent = (eventName: string, eventData?: any) => {
  const enhancedData = {
    content_name: 'CarPlay Android Auto Display',
    content_category: 'Electronics',
    value: 79.99,
    currency: 'EUR',
    ...eventData
  };
  
  return trackEvent(eventName, enhancedData);
};

// Force functions - now just aliases
export const forceTritatuttoPixelEvent = (eventName: string, eventData?: any) => {
  return trackTritatuttoEvent(eventName, eventData);
};

export const forcePiastraCapelliPixelEvent = (eventName: string, eventData?: any) => {
  return trackPiastraCapelliEvent(eventName, eventData);
};