import React from 'react';
import { Star, Quote, CheckCircle, Users } from 'lucide-react';

const Testimonials: React.FC = () => {
  const testimonials = [
    {
      name: "Marco R.",
      location: "Milano",
      rating: 5,
      text: "Fantastica! La uso per lavare l'auto e pulire il terrazzo. La batteria dura tantissimo e la pressione è perfetta. Miglior acquisto dell'anno!",
      verified: true,
      date: "2 settimane fa"
    },
    {
      name: "Giulia M.",
      location: "Roma",
      rating: 5,
      text: "Acquisto eccellente. Molto più comoda delle idropulitrici con filo. Il kit è completo e la qualità è superiore alle aspettative. Consiglio vivamente!",
      verified: true,
      date: "1 mese fa"
    },
    {
      name: "Alessandro T.",
      location: "Torino",
      rating: 5,
      text: "Perfetta per la pulizia professionale. L'ho usata per pulire la facciata di casa e il risultato è stato impeccabile. Potenza incredibile per essere cordless!",
      verified: true,
      date: "3 settimane fa"
    },
    {
      name: "Francesca L.",
      location: "Napoli",
      rating: 5,
      text: "Spedizione velocissima e prodotto come descritto. La uso per il giardino e funziona benissimo. Ottimo rapporto qualità-prezzo, super soddisfatta!",
      verified: true,
      date: "1 settimana fa"
    }
  ];

  const stats = [
    { number: "2,847", label: "Clienti Soddisfatti", icon: Users },
    { number: "4.9/5", label: "Valutazione Media", icon: Star },
    { number: "98%", label: "Raccomandazioni", icon: CheckCircle }
  ];

  return (
    <section className="py-8 lg:py-16 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Users className="h-5 w-5 lg:h-6 lg:w-6 text-blue-600" />
            <span className="text-blue-600 font-bold text-sm lg:text-base">RECENSIONI VERIFICATE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Cosa Dicono i Nostri
            <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Clienti Soddisfatti
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            Oltre 2.800 clienti in tutta Italia hanno già scelto la nostra idropulitrice professionale
          </p>
        </div>

        {/* Stats - MUCH SMALLER */}
        <div className="grid sm:grid-cols-3 gap-3 lg:gap-4 mb-6 lg:mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white p-3 lg:p-4 rounded-xl shadow-md border border-gray-100 text-center group hover:shadow-lg transition-all duration-300">
              <div className="bg-gradient-to-r from-blue-500 to-indigo-500 w-8 h-8 lg:w-10 lg:h-10 rounded-lg flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform duration-300">
                <stat.icon className="h-4 w-4 lg:h-5 lg:w-5 text-white" />
              </div>
              <div className="text-lg lg:text-xl font-black text-gray-900 mb-1">{stat.number}</div>
              <div className="text-gray-600 font-semibold text-xs">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Testimonials Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-4 lg:p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100 group">
              {/* Quote Icon */}
              <div className="flex items-center justify-between mb-3 lg:mb-4">
                <Quote className="h-6 w-6 lg:h-8 lg:w-8 text-blue-600 opacity-60" />
                <div className="flex items-center space-x-1">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-3 w-3 lg:h-4 lg:w-4 text-yellow-400 fill-current" />
                  ))}
                </div>
              </div>
              
              {/* Review Text */}
              <p className="text-gray-700 mb-3 lg:mb-4 italic leading-relaxed text-sm lg:text-base">
                "{testimonial.text}"
              </p>
              
              {/* Customer Info */}
              <div className="border-t border-gray-100 pt-3 lg:pt-4">
                <div className="flex items-center justify-between mb-1">
                  <div>
                    <p className="font-bold text-gray-900 text-sm lg:text-base">{testimonial.name}</p>
                    <p className="text-gray-500 text-xs">{testimonial.location}</p>
                  </div>
                  {testimonial.verified && (
                    <div className="flex items-center space-x-1 bg-green-50 px-2 py-1 rounded-full">
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span className="text-green-700 text-xs font-semibold">Verificato</span>
                    </div>
                  )}
                </div>
                <p className="text-gray-400 text-xs">{testimonial.date}</p>
              </div>
              
              {/* Hover Effect */}
              <div className="mt-3 lg:mt-4 h-1 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500" />
            </div>
          ))}
        </div>

        {/* Trust Badge */}
        <div className="mt-8 lg:mt-12 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-6 lg:p-8 text-white text-center">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <CheckCircle className="h-6 w-6 lg:h-8 lg:w-8" />
            <span className="text-lg lg:text-xl font-black">SODDISFATTI O RIMBORSATI</span>
          </div>
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-black mb-3 lg:mb-4">
            Garanzia di Soddisfazione 100%
          </h3>
          <p className="text-base sm:text-lg lg:text-xl opacity-90 max-w-3xl mx-auto leading-relaxed mb-4 lg:mb-6">
            Se non sei completamente soddisfatto del tuo acquisto, 
            ti rimborsiamo integralmente entro 14 giorni.
          </p>
          <div className="flex flex-col sm:flex-row flex-wrap justify-center gap-3 lg:gap-4 text-sm lg:text-base">
            <span className="bg-white/20 px-3 py-2 lg:px-4 lg:py-2 rounded-xl font-semibold">✅ Assistenza Italiana</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;