import React, { useState } from 'react';
import { Sparkles, Phone, Mail, Shield, Menu, X } from 'lucide-react';

const HairStraightenerHeader: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white/95 backdrop-blur-md shadow-lg border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 lg:h-20">
          <div className="flex items-center">
            <div className="bg-gradient-to-r from-pink-600 to-pink-700 p-2 rounded-xl mr-3">
              <Sparkles className="h-6 w-6 lg:h-8 lg:w-8 text-white" />
            </div>
            <div>
              <span className="text-2xl lg:text-3xl font-bold bg-gradient-to-r from-pink-600 to-pink-800 bg-clip-text text-transparent">
                Tuttosconto
              </span>
              <div className="flex items-center mt-1">
                <Shield className="h-3 w-3 text-pink-500 mr-1" />
                <span className="text-xs text-pink-600 font-medium">Bellezza Professionale</span>
              </div>
            </div>
          </div>
          
          <div className="hidden lg:flex items-center space-x-8">
            <div className="flex items-center text-sm text-gray-700 hover:text-pink-600 transition-colors">
              <Phone className="h-4 w-4 mr-2 text-pink-600" />
              <span className="font-medium">+39 334 713 2255</span>
            </div>
            <div className="flex items-center text-sm text-gray-700 hover:text-pink-600 transition-colors">
              <Mail className="h-4 w-4 mr-2 text-pink-600" />
              <span className="font-medium">contact@tuttosconto.store</span>
            </div>
            <div className="bg-gradient-to-r from-pink-500 to-pink-600 text-white px-4 py-2 rounded-full text-sm font-semibold">
              Spedizione GRATUITA
            </div>
          </div>

          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6 text-gray-600" />
            ) : (
              <Menu className="h-6 w-6 text-gray-600" />
            )}
          </button>
        </div>

        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-gray-100 py-4 space-y-4">
            <div className="flex items-center text-sm text-gray-700">
              <Phone className="h-4 w-4 mr-3 text-pink-600" />
              <span className="font-medium">+39 334 713 2255</span>
            </div>
            <div className="flex items-center text-sm text-gray-700">
              <Mail className="h-4 w-4 mr-3 text-pink-600" />
              <span className="font-medium">contact@tuttosconto.store</span>
            </div>
            <div className="bg-gradient-to-r from-pink-500 to-pink-600 text-white px-4 py-2 rounded-full text-sm font-semibold text-center">
              Spedizione GRATUITA
            </div>
          </div>
        )}
      </div>
    </header>
  );
};

export default HairStraightenerHeader;