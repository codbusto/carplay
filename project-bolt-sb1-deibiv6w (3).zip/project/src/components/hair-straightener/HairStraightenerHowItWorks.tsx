import React from 'react';
import { Play, Zap, Sparkles, CheckCircle, ArrowRight } from 'lucide-react';

const HairStraightenerHowItWorks: React.FC = () => {
  const steps = [
    {
      number: "01",
      title: "Accendi e Riscalda",
      description: "Riscaldamento rapido in 30 secondi, temperatura regolabile",
      icon: Zap,
      color: "pink"
    },
    {
      number: "02", 
      title: "Seleziona Temperatura",
      description: "5 livelli di temperatura per ogni tipo di capello",
      icon: ArrowRight,
      color: "rose"
    },
    {
      number: "03",
      title: "Liscia Delicatamente",
      description: "Movimento fluido dalla radice alle punte",
      icon: Sparkles,
      color: "purple"
    },
    {
      number: "04",
      title: "Risultato Perfetto",
      description: "Capelli lisci, lucenti e senza danni",
      icon: CheckCircle,
      color: "orange"
    }
  ];

  return (
    <section className="py-8 lg:py-16 bg-gradient-to-b from-pink-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Play className="h-5 w-5 lg:h-6 lg:w-6 text-pink-600" />
            <span className="text-pink-600 font-bold text-sm lg:text-base">SEMPLICITÀ ESTREMA</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Come Usare la Tua
            <span className="block bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
              Piastra Professionale
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            Facilità d'uso incredibile per risultati da salone. 
            Bastano 4 semplici passaggi per capelli perfetti.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          <div className="order-2 lg:order-1">
            <div className="relative bg-white p-4 lg:p-6 rounded-3xl shadow-2xl border border-gray-100">
              <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-pink-50 to-rose-50">
                <img
                  src="/piastra-capelli/Immagine 2025-07-03 210207.jpg"
                  alt="Dimostrazione pratica della piastra capelli in azione"
                  className="w-full h-auto rounded-2xl"
                  style={{ maxHeight: '400px', objectFit: 'cover' }}
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
                
                <div className="absolute top-4 left-4 bg-pink-500 text-white px-3 py-2 rounded-full flex items-center space-x-2 shadow-lg">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  <span className="font-bold text-sm">PROFESSIONALE</span>
                </div>
                
                <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-sm px-3 py-2 rounded-xl shadow-lg">
                  <div className="flex items-center space-x-2">
                    <Sparkles className="h-4 w-4 text-pink-600" />
                    <span className="font-bold text-gray-900 text-sm">CERAMICA</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 lg:mt-6 text-center">
                <h3 className="text-lg lg:text-xl font-bold text-gray-900 mb-2">
                  Tecnologia Ceramica Avanzata
                </h3>
                <p className="text-gray-600 text-sm lg:text-base">
                  Guarda quanto è facile ottenere risultati professionali con la nostra piastra
                </p>
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-2 space-y-4 lg:space-y-6">
            {steps.map((step, index) => {
              const colorClasses = {
                pink: "from-pink-500 to-pink-600 bg-pink-50 text-pink-600",
                rose: "from-rose-500 to-rose-600 bg-rose-50 text-rose-600", 
                purple: "from-purple-500 to-purple-600 bg-purple-50 text-purple-600",
                orange: "from-orange-500 to-orange-600 bg-orange-50 text-orange-600"
              };
              
              const [gradient, bgColor, textColor] = colorClasses[step.color as keyof typeof colorClasses].split(' ');
              
              return (
                <div key={index} className="group flex items-start space-x-4 lg:space-x-6 p-4 lg:p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
                  <div className={`bg-gradient-to-r ${gradient} w-12 h-12 lg:w-16 lg:h-16 rounded-2xl flex items-center justify-center text-white font-black text-lg lg:text-xl shadow-lg group-hover:scale-110 transition-transform duration-300 flex-shrink-0`}>
                    {step.number}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2 lg:mb-3">
                      <step.icon className={`h-5 w-5 lg:h-6 lg:w-6 ${textColor}`} />
                      <h3 className="text-lg lg:text-xl font-bold text-gray-900 group-hover:text-gray-700 transition-colors">
                        {step.title}
                      </h3>
                    </div>
                    <p className="text-gray-600 leading-relaxed text-sm lg:text-base">
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
            
            <div className="bg-gradient-to-r from-pink-500 to-rose-500 p-4 lg:p-6 rounded-2xl text-white text-center shadow-xl">
              <div className="flex items-center justify-center space-x-2 mb-2 lg:mb-3">
                <CheckCircle className="h-6 w-6 lg:h-8 lg:w-8" />
                <span className="text-lg lg:text-xl font-black">PRONTA IN 30 SECONDI</span>
              </div>
              <p className="text-pink-100 text-sm lg:text-base">
                Dalla scatola al primo utilizzo in meno di mezzo minuto. 
                <strong className="text-white">Garanzia di semplicità!</strong>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HairStraightenerHowItWorks;