import React from 'react';
import { CheckCircle, Star, Package } from 'lucide-react';

const HairStraightenerGallery: React.FC = () => {
  return (
    <section className="py-8 lg:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-16">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-6">
            <Star className="h-5 w-5 lg:h-8 lg:w-8 text-yellow-500" />
            <span className="text-yellow-600 font-bold text-sm lg:text-xl">VERSATILITÀ PROFESSIONALE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-6xl font-black text-gray-900 mb-3 lg:mb-6">
            Una Soluzione per
            <span className="block bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
              Ogni Tipo di Capello
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-2xl text-gray-600 max-w-4xl mx-auto">
            Dai capelli ricci a quelli mossi, 
            scopri tutte le possibilità della tua nuova piastra professionale
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-6 lg:gap-16 items-center">
          <div className="space-y-4 lg:space-y-8 order-2 lg:order-1 lg:col-span-7">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-pink-500/20 to-rose-500/20 rounded-xl lg:rounded-2xl transform rotate-2 group-hover:rotate-1 transition-transform duration-300"></div>
              <img
                src="/piastra-capelli/Immagine 2025-07-03 210234.jpg"
                alt="Kit completo piastra capelli professionale con accessori"
                className="relative w-full rounded-xl lg:rounded-2xl shadow-xl group-hover:shadow-2xl transition-shadow duration-300"
              />
              <div className="absolute top-3 left-3 lg:top-6 lg:left-6 bg-white/95 backdrop-blur-sm px-2 py-1 lg:px-4 lg:py-3 rounded-xl shadow-lg">
                <span className="font-bold text-gray-900 text-xs lg:text-lg">Kit Completo</span>
              </div>
              <div className="absolute bottom-3 right-3 lg:bottom-6 lg:right-6 bg-pink-500/95 backdrop-blur-sm px-2 py-1 lg:px-4 lg:py-3 rounded-xl shadow-lg">
                <span className="font-bold text-white text-xs lg:text-lg">Professionale</span>
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-pink-50 to-rose-50 p-4 lg:p-10 rounded-xl lg:rounded-2xl border border-pink-100">
              <div className="flex items-center space-x-2 mb-3 lg:mb-6">
                <CheckCircle className="h-5 w-5 lg:h-8 lg:w-8 text-pink-600" />
                <h3 className="text-lg lg:text-3xl font-bold text-gray-900">
                  Styling Professionale Ovunque
                </h3>
              </div>
              <p className="text-sm lg:text-xl text-gray-700 leading-relaxed mb-3 lg:mb-6">
                Dalla lisciatura perfetta al volume naturale, 
                la nostra piastra garantisce risultati professionali con la 
                massima praticità d'uso. <strong>Ceramica avanzata</strong> per ogni tipo di capello.
              </p>
              <div className="flex flex-wrap gap-2 lg:gap-4">
                <span className="bg-pink-100 text-pink-800 px-2 py-1 lg:px-4 lg:py-2 rounded-full text-xs lg:text-base font-semibold">Capelli Ricci</span>
                <span className="bg-rose-100 text-rose-800 px-2 py-1 lg:px-4 lg:py-2 rounded-full text-xs lg:text-base font-semibold">Capelli Mossi</span>
                <span className="bg-purple-100 text-purple-800 px-2 py-1 lg:px-4 lg:py-2 rounded-full text-xs lg:text-base font-semibold">Capelli Lisci</span>
                <span className="bg-orange-100 text-orange-800 px-2 py-1 lg:px-4 lg:py-2 rounded-full text-xs lg:text-base font-semibold">Volume</span>
              </div>
            </div>
          </div>

          <div className="space-y-4 lg:space-y-8 order-1 lg:order-2 lg:col-span-5">
            <div className="bg-gradient-to-br from-rose-50 to-purple-50 p-4 lg:p-10 rounded-xl lg:rounded-2xl border border-rose-100">
              <div className="flex items-center space-x-2 mb-3 lg:mb-6">
                <Package className="h-5 w-5 lg:h-8 lg:w-8 text-rose-600" />
                <h3 className="text-lg lg:text-3xl font-bold text-gray-900">
                  Kit Completo Incluso
                </h3>
              </div>
              <div className="space-y-2 lg:space-y-6">
                {[
                  { item: "Piastra ceramica professionale", detail: "Tecnologia avanzata" },
                  { item: "Guanto termico protettivo", detail: "Sicurezza durante l'uso" },
                  { item: "Custodia da viaggio", detail: "Trasporto sicuro" },
                  { item: "Cavo extra lungo 3m", detail: "Massima libertà di movimento" },
                  { item: "Manuale in italiano", detail: "Istruzioni complete e consigli" },
                  { item: "Garanzia 1 anno", detail: "Assistenza clienti italiana" }
                ].map((feature, index) => (
                  <div key={index} className="flex items-start space-x-2 lg:space-x-4 p-2 lg:p-6 bg-white/80 rounded-xl">
                    <CheckCircle className="h-4 w-4 lg:h-6 lg:w-6 text-rose-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-bold text-gray-900 block text-xs lg:text-lg">{feature.item}</span>
                      <span className="text-gray-600 text-xs lg:text-base">{feature.detail}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 lg:mt-8 p-3 lg:p-6 bg-gradient-to-r from-pink-500 to-rose-600 rounded-xl text-white text-center">
                <p className="text-sm lg:text-xl font-bold">Valore del Kit: €99,99</p>
                <p className="text-pink-100 text-xs lg:text-lg">Oggi a soli €34,99 - Risparmia €65!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HairStraightenerGallery;