import React, { useState, useEffect } from 'react';
import { Star, Zap, Shield, Truck, Clock, Award, CreditCard, Sparkles, Package } from 'lucide-react';
import { trackInitiateCheckout, trackViewContent, trackPiastraCapelliEvent, forcePiastraCapelliPixelEvent } from '../../utils/facebookPixel';
import { trackButtonClick, trackSectionView } from '../../utils/clarityTracking';

interface HairStraightenerHeroProps {
  onOrderClick: () => void;
}

const HairStraightenerHero: React.FC<HairStraightenerHeroProps> = ({ onOrderClick }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const images = [
    {
      src: "/piastra-capelli/Immagine 2025-07-03 210207.jpg",
      alt: "Piastra Capelli Crasts Professionale - Risultati perfetti"
    },
    {
      src: "/piastra-capelli/Immagine 2025-07-03 210234.jpg",
      alt: "Piastra Capelli Crasts - Design elegante e funzionale"
    }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => 
        prevIndex === images.length - 1 ? 0 : prevIndex + 1
      );
    }, 4000);

    return () => clearInterval(interval);
  }, [images.length]);

  useEffect(() => {
    // Enhanced tracking for piastra capelli hero section
    trackViewContent('Hero Section - Piastra Capelli Crasts', 'hero');
    trackSectionView('hero');
    
    // ENHANCED PIASTRA CAPELLI PIXEL EVENTS with multiple methods
    const heroViewEventID = forcePiastraCapelliPixelEvent('ViewContent', {
      content_name: 'Piastra Capelli Hero Section',
      content_type: 'hero_section',
      section: 'hero',
      page_type: 'piastra_capelli_landing',
      hero_loaded_timestamp: new Date().toISOString()
    });
    
    // Also use the standard piastra capelli tracking
    const standardEventID = trackPiastraCapelliEvent('ViewContent', {
      content_name: 'Piastra Capelli Hero Section',
      content_type: 'hero_section'
    });
    
    // Additional page view tracking specifically for piastra capelli
    setTimeout(() => {
      const pageViewEventID = forcePiastraCapelliPixelEvent('PageView', {
        page_type: 'piastra_capelli_landing',
        section: 'hero_loaded',
        delay_loaded: true
      });
      console.log('🎯 Piastra Capelli Hero: Delayed PageView Event ID:', pageViewEventID);
    }, 2000);
    
    // Track hero engagement after 5 seconds
    setTimeout(() => {
      const engagementEventID = forcePiastraCapelliPixelEvent('ViewContent', {
        content_name: 'Piastra Capelli Hero Engagement',
        content_type: 'hero_engagement',
        engagement_time: '5_seconds',
        section: 'hero'
      });
      console.log('🎯 Piastra Capelli Hero: Engagement Event ID:', engagementEventID);
    }, 5000);
    
    console.log('🎯 Piastra Capelli Hero: Enhanced pixel tracking initialized');
    console.log('🎯 Hero View Event ID:', heroViewEventID);
    console.log('🎯 Standard Event ID:', standardEventID);
  }, []);

  const handleOrderClick = () => {
    // Standard tracking
    trackInitiateCheckout({
      content_name: 'Piastra Capelli Crasts',
      value: 34.99,
      currency: 'EUR'
    });
    
    // ENHANCED piastra capelli-specific tracking with multiple event IDs
    const checkoutEventID = forcePiastraCapelliPixelEvent('InitiateCheckout', {
      content_name: 'Piastra Capelli Crasts',
      value: 34.99,
      action: 'order_button_click',
      button_location: 'hero_section',
      click_timestamp: new Date().toISOString()
    });
    
    // Additional tracking methods
    const standardCheckoutEventID = trackPiastraCapelliEvent('InitiateCheckout', {
      content_name: 'Piastra Capelli Crasts',
      value: 34.99
    });
    
    // Track as AddToCart as well for better optimization
    const addToCartEventID = forcePiastraCapelliPixelEvent('AddToCart', {
      content_name: 'Piastra Capelli Crasts',
      value: 34.99,
      currency: 'EUR',
      num_items: 1,
      cart_action: 'hero_order_click'
    });
    
    // Track custom conversion event
    const conversionEventID = forcePiastraCapelliPixelEvent('PiastraCapelliHeroConversion', {
      content_name: 'Piastra Capelli Hero Order Click',
      value: 34.99,
      conversion_type: 'hero_cta_click'
    });
    
    trackButtonClick('order_now', 'hero_section');
    onOrderClick();
    
    console.log('🎯 Piastra Capelli Order Click: Multiple pixel events fired');
    console.log('🎯 Checkout Event ID:', checkoutEventID);
    console.log('🎯 Standard Checkout Event ID:', standardCheckoutEventID);
    console.log('🎯 AddToCart Event ID:', addToCartEventID);
    console.log('🎯 Conversion Event ID:', conversionEventID);
  };

  return (
    <section className="relative bg-gradient-to-br from-pink-50 via-rose-50 to-pink-100 py-8 lg:py-24 overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ec4899' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-8 lg:space-y-0 lg:grid lg:grid-cols-12 lg:gap-20 lg:items-center">
          
          {/* Product Image - Larger on PC */}
          <div className="relative order-1 lg:order-2 lg:col-span-7">
            <div className="absolute inset-0 bg-gradient-to-r from-pink-400/20 to-rose-600/20 rounded-3xl transform rotate-2 scale-105"></div>
            <div className="absolute inset-0 bg-gradient-to-l from-pink-400/10 to-rose-600/10 rounded-3xl transform -rotate-1 scale-110"></div>
            <div className="relative bg-white/95 backdrop-blur-sm rounded-3xl p-6 lg:p-12 shadow-2xl border border-white/50 overflow-hidden">
              
              <div className="absolute top-4 right-4 lg:top-8 lg:right-8 bg-gradient-to-r from-red-500 to-red-600 text-white px-4 py-2 lg:px-6 lg:py-4 rounded-2xl shadow-xl transform rotate-12 z-10">
                <span className="font-black text-sm lg:text-lg">60% SCONTO</span>
              </div>

              <div className="relative h-72 sm:h-80 lg:h-[600px]">
                {images.map((image, index) => (
                  <img
                    key={index}
                    src={image.src}
                    alt={image.alt}
                    className={`absolute inset-0 w-full h-full object-contain rounded-2xl transition-all duration-1000 ${
                      index === currentImageIndex 
                        ? 'opacity-100 scale-100' 
                        : 'opacity-0 scale-105'
                    }`}
                    onError={(e) => {
                      console.log(`Failed to load image: ${image.src}`);
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                ))}
              </div>
              
              <div className="flex justify-center space-x-3 mt-6">
                {images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-3 h-3 lg:w-4 lg:h-4 rounded-full transition-all duration-300 ${
                      index === currentImageIndex 
                        ? 'bg-pink-600 w-8 lg:w-12' 
                        : 'bg-gray-300 hover:bg-gray-400'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Content Section - Better spacing on PC */}
          <div className="space-y-6 lg:space-y-10 order-2 lg:order-1 lg:col-span-5">
            
            {/* Trust Indicators */}
            <div className="flex flex-col space-y-3 sm:flex-row sm:flex-wrap sm:items-center sm:space-y-0 sm:gap-4 lg:flex-col lg:space-y-4 lg:items-start">
              <div className="flex items-center justify-center sm:justify-start lg:justify-start space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 lg:h-6 lg:w-6 text-yellow-400 fill-current" />
                ))}
                <span className="text-sm lg:text-lg text-gray-600 ml-2 font-medium">(1,847 recensioni)</span>
              </div>
              <div className="flex items-center justify-center sm:justify-start lg:justify-start space-x-2 bg-white/80 backdrop-blur-sm px-3 py-2 lg:px-4 lg:py-3 rounded-full">
                <Award className="h-4 w-4 lg:h-5 lg:w-5 text-pink-600" />
                <span className="text-sm lg:text-base font-semibold text-gray-700">Bestseller Bellezza 2025</span>
              </div>
            </div>
            
            {/* Main Headline - Larger on PC */}
            <div className="space-y-4 lg:space-y-6 text-center lg:text-left">
              <h1 className="text-4xl sm:text-5xl lg:text-8xl font-black text-gray-900 leading-tight">
                <span className="bg-gradient-to-r from-pink-600 via-pink-700 to-rose-600 bg-clip-text text-transparent block">
                  Piastra Capelli
                </span>
                <span className="text-2xl sm:text-3xl lg:text-6xl text-gray-700 block mt-2">
                  Crasts Professionale
                </span>
              </h1>
              
              <p className="text-lg sm:text-xl lg:text-3xl text-gray-600 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                Tecnologia <span className="font-bold text-pink-600">ceramica avanzata</span>, 
                riscaldamento <span className="font-bold text-pink-600">istantaneo</span>, 
                capelli perfetti in minuti.
              </p>
            </div>

            {/* Feature Pills - Better layout on PC */}
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-2 lg:gap-6">
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-6 rounded-xl shadow-sm">
                <div className="bg-pink-100 p-2 lg:p-3 rounded-lg flex-shrink-0">
                  <Zap className="h-5 w-5 lg:h-8 lg:w-8 text-pink-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-xl">Ceramica</span>
                  <span className="text-xs lg:text-base text-gray-600">Avanzata</span>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-6 rounded-xl shadow-sm">
                <div className="bg-rose-100 p-2 lg:p-3 rounded-lg flex-shrink-0">
                  <Shield className="h-5 w-5 lg:h-8 lg:w-8 text-rose-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-xl">1 Anno</span>
                  <span className="text-xs lg:text-base text-gray-600">Garanzia</span>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-6 rounded-xl shadow-sm">
                <div className="bg-purple-100 p-2 lg:p-3 rounded-lg flex-shrink-0">
                  <Sparkles className="h-5 w-5 lg:h-8 lg:w-8 text-purple-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-xl">Professionale</span>
                  <span className="text-xs lg:text-base text-gray-600">Risultati</span>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-6 rounded-xl shadow-sm">
                <div className="bg-orange-100 p-2 lg:p-3 rounded-lg flex-shrink-0">
                  <Package className="h-5 w-5 lg:h-8 lg:w-8 text-orange-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-xl">Kit Completo</span>
                  <span className="text-xs lg:text-base text-gray-600">Incluso</span>
                </div>
              </div>
            </div>

            {/* Delivery Icons - Better spacing on PC */}
            <div className="flex flex-col space-y-3 sm:flex-row sm:flex-wrap sm:justify-center lg:justify-start sm:space-y-0 sm:gap-3 lg:gap-4">
              <div className="flex items-center justify-center space-x-2 bg-pink-50 px-4 py-3 lg:px-6 lg:py-4 rounded-full border border-pink-200">
                <Truck className="h-5 w-5 lg:h-6 lg:w-6 text-pink-600 flex-shrink-0" />
                <span className="text-sm lg:text-lg font-semibold text-pink-700">Consegna Gratuita</span>
              </div>
              <div className="flex items-center justify-center space-x-2 bg-rose-50 px-4 py-3 lg:px-6 lg:py-4 rounded-full border border-rose-200">
                <Clock className="h-5 w-5 lg:h-6 lg:w-6 text-rose-600 flex-shrink-0" />
                <span className="text-sm lg:text-lg font-semibold text-rose-700">24-48h a Casa</span>
              </div>
              <div className="flex items-center justify-center space-x-2 bg-purple-50 px-4 py-3 lg:px-6 lg:py-4 rounded-full border border-purple-200">
                <CreditCard className="h-5 w-5 lg:h-6 lg:w-6 text-purple-600 flex-shrink-0" />
                <span className="text-sm lg:text-lg font-semibold text-purple-700">Paga alla Consegna</span>
              </div>
            </div>

            {/* Pricing Section - Larger on PC */}
            <div className="bg-white/95 backdrop-blur-sm p-4 lg:p-8 rounded-2xl shadow-lg border border-white/50">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3 lg:space-x-6">
                  <span className="text-2xl lg:text-5xl font-black text-pink-600">€34,99</span>
                  <div className="flex flex-col">
                    <span className="text-base lg:text-2xl text-gray-500 line-through">€99,99</span>
                  </div>
                </div>
                <div className="text-center">
                  <div className="bg-red-100 text-red-800 px-3 py-2 lg:px-6 lg:py-4 rounded-xl">
                    <span className="font-bold text-xs lg:text-base">RISPARMIA</span>
                    <div className="font-black text-lg lg:text-3xl">€65</div>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA Button - Larger on PC */}
            <button
              onClick={handleOrderClick}
              className="w-full bg-gradient-to-r from-pink-600 via-pink-700 to-rose-600 hover:from-pink-700 hover:via-pink-800 hover:to-rose-700 text-white font-black py-4 lg:py-8 px-8 lg:px-12 rounded-2xl text-lg lg:text-3xl transition-all duration-300 transform active:scale-95 lg:hover:scale-105 shadow-2xl touch-manipulation"
            >
              ORDINA ORA
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HairStraightenerHero;