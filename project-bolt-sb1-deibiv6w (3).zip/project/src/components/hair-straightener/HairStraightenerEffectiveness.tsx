import React from 'react';
import { Zap, Target, Clock, Award, CheckCircle, Star, Sparkles, Shield } from 'lucide-react';

const HairStraightenerEffectiveness: React.FC = () => {
  const results = [
    {
      title: "Lisciatura Perfetta",
      description: "Elimina crespo e onde in una sola passata",
      icon: Target,
      color: "pink"
    },
    {
      title: "Protezione Capelli", 
      description: "Ceramica che protegge e nutre durante l'uso",
      icon: Shield,
      color: "rose"
    },
    {
      title: "Risultati Immediati",
      description: "Capelli lisci e lucenti in pochi minuti",
      icon: Clock,
      color: "purple"
    },
    {
      title: "Durata Prolungata",
      description: "Effetto liscio che dura tutto il giorno",
      icon: Sparkles,
      color: "orange"
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      pink: "from-pink-500 to-pink-600 text-pink-600 bg-pink-50",
      rose: "from-rose-500 to-rose-600 text-rose-600 bg-rose-50",
      purple: "from-purple-500 to-purple-600 text-purple-600 bg-purple-50",
      orange: "from-orange-500 to-orange-600 text-orange-600 bg-orange-50"
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section className="py-8 lg:py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-16">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-6">
            <Award className="h-5 w-5 lg:h-8 lg:w-8 text-orange-600" />
            <span className="text-orange-600 font-bold text-sm lg:text-xl">RISULTATI DIMOSTRATI</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-6xl font-black text-gray-900 mb-3 lg:mb-6">
            Il Motivo per Cui Scegliere
            <span className="block bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
              La Nostra Piastra
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-2xl text-gray-600 max-w-4xl mx-auto">
            Guarda la trasformazione reale della nostra piastra professionale. 
            Capelli perfettamente lisci e lucenti con risultati duraturi.
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-8 lg:gap-16 items-center">
          {/* Left Column - Results - Larger on PC */}
          <div className="order-1 lg:order-1 lg:col-span-5 space-y-4 lg:space-y-8">
            <div className="grid sm:grid-cols-2 lg:grid-cols-1 gap-3 lg:gap-6">
              {results.map((result, index) => {
                const colorClasses = getColorClasses(result.color);
                const [gradientFrom, gradientTo, textColor, bgColor] = colorClasses.split(' ');
                
                return (
                  <div key={index} className="group bg-white p-3 lg:p-8 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
                    <div className="flex items-start space-x-3 lg:space-x-6">
                      <div className={`bg-gradient-to-r ${gradientFrom} ${gradientTo} p-2 lg:p-4 rounded-xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                        <result.icon className="h-4 w-4 lg:h-8 lg:w-8 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-sm lg:text-2xl font-bold text-gray-900 mb-1 lg:mb-3">
                          {result.title}
                        </h3>
                        <p className="text-gray-600 text-xs lg:text-lg leading-relaxed">
                          {result.description}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Guarantee - Larger on PC */}
            <div className="bg-gradient-to-r from-pink-500 to-rose-500 p-4 lg:p-10 rounded-2xl text-white text-center shadow-xl">
              <div className="flex items-center justify-center space-x-2 mb-2 lg:mb-6">
                <Award className="h-6 w-6 lg:h-12 lg:w-12" />
                <span className="text-lg lg:text-3xl font-black">RISULTATI GARANTITI</span>
              </div>
              <h3 className="text-xl sm:text-2xl lg:text-4xl font-black mb-2 lg:mb-6">
                Trasformazione Professionale Certificata
              </h3>
              <p className="text-pink-100 text-sm lg:text-xl max-w-2xl mx-auto">
                Testata su oltre <strong className="text-white">500 tipi di capelli diversi</strong>. 
                Se non ottieni risultati come quelli mostrati, ti rimborsiamo tutto.
              </p>
            </div>
          </div>

          {/* Right Column - Before/After Image - Larger on PC */}
          <div className="order-2 lg:order-2 lg:col-span-7">
            <div className="bg-gradient-to-r from-red-50 to-pink-50 p-4 lg:p-10 rounded-2xl border border-red-100">
              <div className="relative bg-white p-3 lg:p-8 rounded-2xl shadow-lg border border-gray-100">
                <img
                  src="/Prima (1).jpg"
                  alt="Prima e Dopo - Trasformazione capelli con piastra professionale Crasts"
                  className="w-full h-auto rounded-xl"
                  style={{ maxHeight: '600px', objectFit: 'contain' }}
                />
                
                <div className="absolute bottom-6 right-6 lg:bottom-12 lg:right-12 bg-white/95 backdrop-blur-sm px-3 py-2 lg:px-6 lg:py-4 rounded-xl shadow-lg">
                  <div className="flex items-center space-x-2">
                    <Sparkles className="h-4 w-4 lg:h-6 lg:w-6 text-pink-600" />
                    <span className="font-bold text-gray-900 text-sm lg:text-lg">RISULTATO</span>
                  </div>
                </div>
              </div>
              
              {/* Comparison Details - Better spacing on PC */}
              <div className="mt-6 lg:mt-12">
                <h3 className="text-lg lg:text-3xl font-bold text-gray-900 mb-4 lg:mb-8 text-center">
                  Confronto Prima vs Dopo
                </h3>
                <div className="grid grid-cols-2 gap-4 lg:gap-8">
                  <div className="text-center">
                    <div className="bg-red-100 text-red-800 px-3 py-2 lg:px-6 lg:py-4 rounded-xl mb-3 lg:mb-6">
                      <span className="font-bold text-sm lg:text-xl">PRIMA</span>
                    </div>
                    <ul className="text-xs lg:text-lg text-gray-700 space-y-1 lg:space-y-3">
                      <li>• Capelli secchi e crespi</li>
                      <li>• Effetto crespo evidente</li>
                      <li>• Capelli danneggiati</li>
                      <li>• Aspetto spento</li>
                    </ul>
                  </div>
                  <div className="text-center">
                    <div className="bg-green-100 text-green-800 px-3 py-2 lg:px-6 lg:py-4 rounded-xl mb-3 lg:mb-6">
                      <span className="font-bold text-sm lg:text-xl">DOPO</span>
                    </div>
                    <ul className="text-xs lg:text-lg text-gray-700 space-y-1 lg:space-y-3">
                      <li>• Capelli perfettamente lisci</li>
                      <li>• Lucentezza naturale</li>
                      <li>• Elasticità e morbidezza</li>
                      <li>• Aspetto professionale</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Technical Specs - Better layout on PC */}
        <div className="mt-8 lg:mt-20 bg-white p-4 lg:p-12 rounded-2xl shadow-lg border border-gray-100">
          <div className="text-center mb-4 lg:mb-12">
            <h3 className="text-lg lg:text-3xl font-bold text-gray-900 mb-1 lg:mb-3">
              Specifiche Tecniche
            </h3>
            <p className="text-gray-600 text-xs lg:text-xl">
              Prestazioni certificate per uso professionale
            </p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-8">
            <div className="text-center p-3 lg:p-8 bg-gradient-to-br from-pink-50 to-rose-50 rounded-xl">
              <div className="text-lg lg:text-4xl font-black text-pink-600 mb-1 lg:mb-3">230°C</div>
              <div className="text-xs lg:text-xl font-semibold text-gray-900">Temperatura Max</div>
            </div>
            <div className="text-center p-3 lg:p-8 bg-gradient-to-br from-rose-50 to-purple-50 rounded-xl">
              <div className="text-lg lg:text-4xl font-black text-rose-600 mb-1 lg:mb-3">30 SEC</div>
              <div className="text-xs lg:text-xl font-semibold text-gray-900">Riscaldamento</div>
            </div>
            <div className="text-center p-3 lg:p-8 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl">
              <div className="text-lg lg:text-4xl font-black text-purple-600 mb-1 lg:mb-3">CERAMICA</div>
              <div className="text-xs lg:text-xl font-semibold text-gray-900">Piastre</div>
            </div>
            <div className="text-center p-3 lg:p-8 bg-gradient-to-br from-orange-50 to-red-50 rounded-xl">
              <div className="text-lg lg:text-4xl font-black text-orange-600 mb-1 lg:mb-3">5 LIVELLI</div>
              <div className="text-xs lg:text-xl font-semibold text-gray-900">Temperatura</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HairStraightenerEffectiveness;