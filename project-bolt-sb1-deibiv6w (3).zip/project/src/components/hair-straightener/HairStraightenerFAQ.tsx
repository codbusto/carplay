import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle, Shield, Truck, Sparkles, Wrench, CreditCard, Phone } from 'lucide-react';
import { trackContact, trackViewContent } from '../../utils/facebookPixel';
import { trackFAQInteraction, trackContactAttempt } from '../../utils/clarityTracking';

const HairStraightenerFAQ: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      icon: Sparkles,
      question: "Per che tipo di capelli è adatta?",
      answer: "La piastra è perfetta per tutti i tipi di capelli: ricci, mossi, crespi e lisci. Grazie ai 5 livelli di temperatura (140°C-230°C) si adatta perfettamente alle esigenze di ogni capello.",
      category: "Utilizzo"
    },
    {
      icon: Truck,
      question: "Quanto tempo ci vuole per ricevere l'ordine?",
      answer: "La spedizione è completamente gratuita in tutta Italia. Dopo la conferma telefonica, il prodotto viene spedito entro 24 ore e arriva a casa tua in 24-48 ore lavorative tramite corriere espresso.",
      category: "Spedizione"
    },
    {
      icon: CreditCard,
      question: "Come funziona il pagamento alla consegna?",
      answer: "Paghi solo quando ricevi il prodotto a casa tua. Il corriere accetta contanti o bancomat. Non viene addebitato nulla in anticipo - zero rischi per te. È il metodo di pagamento più sicuro disponibile.",
      category: "Pagamento"
    },
    {
      icon: Wrench,
      question: "Quanto tempo ci mette a riscaldarsi?",
      answer: "La piastra si riscalda in soli 30 secondi grazie alla tecnologia di riscaldamento rapido. Puoi iniziare subito a lisciare i capelli senza attese.",
      category: "Prestazioni"
    },
    {
      icon: Shield,
      question: "È sicura per i capelli?",
      answer: "Assolutamente sì! Le piastre in ceramica distribuiscono il calore uniformemente proteggendo i capelli dai danni. Include anche spegnimento automatico dopo 60 minuti per la massima sicurezza.",
      category: "Sicurezza"
    },
    {
      icon: Phone,
      question: "Quando mi chiamerete per confermare l'ordine?",
      answer: "Ti chiamiamo entro 24 ore dall'ordine per confermare i dati di spedizione e rispondere a eventuali domande. La chiamata dura circa 2-3 minuti ed è necessaria per garantire la consegna corretta.",
      category: "Processo"
    },
    {
      icon: HelpCircle,
      question: "Quanto durano i risultati?",
      answer: "I capelli rimangono perfettamente lisci per tutto il giorno. La qualità della ceramica garantisce risultati duraturi che resistono all'umidità e mantengono la piega.",
      category: "Risultati"
    },
    {
      icon: Truck,
      question: "Posso restituire il prodotto se non sono soddisfatta?",
      answer: "Sì, hai 14 giorni di tempo per restituire il prodotto se non sei completamente soddisfatta. Il reso è gratuito e ti rimborsiamo l'intero importo. Basta contattarci e organizziamo il ritiro.",
      category: "Reso"
    }
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
    trackViewContent(`FAQ: ${faqs[index].question}`, 'faq');
    trackFAQInteraction(faqs[index].question);
  };

  const handleContactClick = (method: 'phone' | 'email') => {
    trackContact();
    trackContactAttempt(method);
  };

  const getCategoryColor = (category: string) => {
    const colors = {
      'Utilizzo': 'text-pink-600 bg-pink-50',
      'Spedizione': 'text-rose-600 bg-rose-50',
      'Pagamento': 'text-purple-600 bg-purple-50',
      'Prestazioni': 'text-orange-600 bg-orange-50',
      'Sicurezza': 'text-green-600 bg-green-50',
      'Processo': 'text-cyan-600 bg-cyan-50',
      'Risultati': 'text-indigo-600 bg-indigo-50',
      'Reso': 'text-red-600 bg-red-50'
    };
    return colors[category as keyof typeof colors] || 'text-gray-600 bg-gray-50';
  };

  return (
    <section className="py-8 lg:py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <HelpCircle className="h-5 w-5 lg:h-6 lg:w-6 text-pink-600" />
            <span className="text-pink-600 font-bold text-sm lg:text-base">DOMANDE FREQUENTI</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Hai Qualche
            <span className="block bg-gradient-to-r from-pink-600 to-rose-600 bg-clip-text text-transparent">
              Domanda?
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            Trova le risposte alle domande più comuni sulla nostra piastra professionale, 
            spedizione e garanzie
          </p>
        </div>

        <div className="space-y-3 lg:space-y-4">
          {faqs.map((faq, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden transition-all duration-300 ${
                openIndex === index ? 'shadow-xl' : 'hover:shadow-xl'
              }`}
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full p-4 lg:p-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
              >
                <div className="flex items-center space-x-3 lg:space-x-4 flex-1">
                  <div className="bg-gradient-to-r from-pink-500 to-rose-500 p-2 lg:p-3 rounded-xl shadow-lg flex-shrink-0">
                    <faq.icon className="h-5 w-5 lg:h-6 lg:w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${getCategoryColor(faq.category)}`}>
                        {faq.category}
                      </span>
                    </div>
                    <h3 className="text-base lg:text-lg font-bold text-gray-900 leading-tight">
                      {faq.question}
                    </h3>
                  </div>
                </div>
                <div className="ml-4 flex-shrink-0">
                  {openIndex === index ? (
                    <ChevronUp className="h-5 w-5 lg:h-6 lg:w-6 text-pink-600" />
                  ) : (
                    <ChevronDown className="h-5 w-5 lg:h-6 lg:w-6 text-gray-400" />
                  )}
                </div>
              </button>
              
              {openIndex === index && (
                <div className="px-4 lg:px-6 pb-4 lg:pb-6">
                  <div className="pl-12 lg:pl-16">
                    <div className="bg-gradient-to-r from-pink-50 to-rose-50 p-4 lg:p-6 rounded-xl border border-pink-100">
                      <p className="text-gray-700 leading-relaxed text-sm lg:text-base">
                        {faq.answer}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-8 lg:mt-12 bg-gradient-to-r from-pink-600 via-rose-600 to-purple-600 rounded-2xl p-6 lg:p-8 text-white text-center">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Phone className="h-6 w-6 lg:h-8 lg:w-8" />
            <span className="text-lg lg:text-xl font-black">NON HAI TROVATO LA RISPOSTA?</span>
          </div>
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-black mb-3 lg:mb-4">
            Contattaci Direttamente
          </h3>
          <p className="text-base sm:text-lg lg:text-xl opacity-90 max-w-2xl mx-auto leading-relaxed mb-4 lg:mb-6">
            Il nostro team di assistenza clienti è sempre disponibile per rispondere 
            a tutte le tue domande in italiano
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-3 lg:gap-4">
            <a 
              href="tel:+393347132255"
              onClick={() => handleContactClick('phone')}
              className="bg-white/20 backdrop-blur-sm px-4 py-3 lg:px-6 lg:py-4 rounded-xl hover:bg-white/30 transition-colors"
            >
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 lg:h-5 lg:w-5" />
                <span className="font-bold text-sm lg:text-base">+39 334 713 2255</span>
              </div>
              <span className="text-pink-100 text-xs lg:text-sm">Lun-Ven 9:00-18:00</span>
            </a>
            <a 
              href="mailto:contact@tuttosconto.store"
              onClick={() => handleContactClick('email')}
              className="bg-white/20 backdrop-blur-sm px-4 py-3 lg:px-6 lg:py-4 rounded-xl hover:bg-white/30 transition-colors"
            >
              <div className="flex items-center space-x-2">
                <HelpCircle className="h-4 w-4 lg:h-5 lg:w-5" />
                <span className="font-bold text-sm lg:text-base">contact@tuttosconto.store</span>
              </div>
              <span className="text-pink-100 text-xs lg:text-sm">Risposta in 24h</span>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HairStraightenerFAQ;