import React, { useState } from 'react';
import { Star, Monitor, Shield, Truck, Clock, Award, CreditCard, Smartphone, Car, ChevronLeft, ChevronRight } from 'lucide-react';
import { trackInitiateCheckout, trackViewContent } from '../../utils/facebookPixel';
import { trackButtonClick, trackSectionView } from '../../utils/clarityTracking';

interface CarPlayHeroProps {
  onOrderClick: () => void;
}

const CarPlayHero: React.FC<CarPlayHeroProps> = ({ onOrderClick }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const images = [
    {
      src: "/Immagine 2025-07-08 221317 copy copy copy copy copy.jpg",
      alt: "CarPlay Android Auto Display - Schermo principale",
      thumb: "/Immagine 2025-07-08 221317 copy copy copy copy copy.jpg"
    },
    {
      src: "/71RucRhKCCL._AC_SL1500_-1024x1024 copy.jpg",
      alt: "CarPlay Display - Vista completa del prodotto",
      thumb: "/71RucRhKCCL._AC_SL1500_-1024x1024 copy.jpg"
    },
    {
      src: "/A-soli-49E-8-768x768 copy copy.jpg",
      alt: "Display CarPlay - Funzionalità avanzate",
      thumb: "/A-soli-49E-8-768x768 copy copy.jpg"
    },
    {
      src: "/A-soli-49E-12-1024x1024 copy.jpg",
      alt: "Kit completo CarPlay Android Auto",
      thumb: "/A-soli-49E-12-1024x1024 copy.jpg"
    }
  ];

  const nextImage = () => {
    setCurrentImageIndex((prevIndex) => 
      prevIndex === images.length - 1 ? 0 : prevIndex + 1
    );
  };

  const prevImage = () => {
    setCurrentImageIndex((prevIndex) => 
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  };

  const handleOrderClick = () => {
    trackInitiateCheckout({
      content_name: 'CarPlay Android Auto Display',
      value: 79.99,
      currency: 'EUR'
    });
    
    trackButtonClick('order_now', 'hero_section');
    onOrderClick();
  };

  const handleCardPayment = () => {
    // Redirect to Shopify checkout
    window.location.href = 'https://tuttosconto-store.myshopify.com/cart/51147658854743:1?checkout';
  };

  return (
    <section className="relative bg-gradient-to-br from-blue-50 via-indigo-50 to-blue-100 py-8 lg:py-16 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%232563eb' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-12 gap-6 lg:gap-8 items-center">
          
          {/* Product Image Section */}
          <div className="lg:col-span-7 order-1 lg:order-2">
            <div className="relative">
              {/* Product Image Container */}
              <div className="relative bg-white/95 backdrop-blur-sm rounded-3xl p-2 lg:p-4 shadow-2xl border border-white/50 group">
                <div className="relative h-80 sm:h-96 lg:h-[650px] w-full">
                  <img
                    src={images[currentImageIndex].src}
                    alt={images[currentImageIndex].alt}
                    className="w-full h-full object-contain rounded-2xl bg-white"
                    onError={(e) => {
                      console.log(`Failed to load image: ${images[currentImageIndex].src}`);
                      // Fallback to a default image if available
                      const target = e.currentTarget as HTMLImageElement;
                      target.src = '/A-soli-49E-14-1024x1024.jpg';
                    }}
                  />
                  
                  {/* Navigation Arrows */}
                  <button
                    onClick={prevImage}
                    className="absolute left-2 lg:left-4 top-1/2 transform -translate-y-1/2 bg-white/90 hover:bg-white text-gray-800 p-2 lg:p-3 rounded-full shadow-lg transition-all duration-300 opacity-0 group-hover:opacity-100 hover:scale-110"
                  >
                    <ChevronLeft className="h-5 w-5 lg:h-6 lg:w-6" />
                  </button>
                  
                  <button
                    onClick={nextImage}
                    className="absolute right-2 lg:right-4 top-1/2 transform -translate-y-1/2 bg-white/90 hover:bg-white text-gray-800 p-2 lg:p-3 rounded-full shadow-lg transition-all duration-300 opacity-0 group-hover:opacity-100 hover:scale-110"
                  >
                    <ChevronRight className="h-5 w-5 lg:h-6 lg:w-6" />
                  </button>
                  
                  {/* Image Counter */}
                  <div className="absolute top-2 lg:top-4 right-2 lg:right-4 bg-black/70 text-white px-2 py-1 lg:px-3 lg:py-2 rounded-full text-xs lg:text-sm font-semibold">
                    {currentImageIndex + 1} / {images.length}
                  </div>
                </div>
                
                {/* Thumbnail Navigation */}
                <div className="flex justify-center space-x-2 lg:space-x-3 mt-3 lg:mt-4 overflow-x-auto pb-2">
                  {images.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`flex-shrink-0 w-12 h-12 lg:w-16 lg:h-16 rounded-lg overflow-hidden border-2 transition-all duration-300 ${
                        index === currentImageIndex 
                          ? 'border-blue-600 ring-2 ring-blue-200 scale-110' 
                          : 'border-gray-300 hover:border-blue-400 hover:scale-105'
                      }`}
                    >
                      <img
                        src={images[index].thumb}
                        alt={`Thumbnail ${index + 1}`}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                    </button>
                  ))}
                </div>
                
                {/* Swipe Hint for Mobile */}
                <div className="lg:hidden text-center mt-2">
                  <p className="text-xs text-gray-500">Scorri o tocca le miniature per cambiare immagine</p>
                </div>
              </div>
            </div>
          </div>

          {/* Content Section */}
          <div className="lg:col-span-5 order-2 lg:order-1 space-y-4 lg:space-y-6">
            
            {/* Trust Indicators */}
            <div className="flex flex-col space-y-2 sm:flex-row sm:flex-wrap sm:items-center sm:space-y-0 sm:gap-3">
              <div className="flex items-center justify-center sm:justify-start space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 lg:h-5 lg:w-5 text-yellow-400 fill-current" />
                ))}
                <span className="text-sm lg:text-base text-gray-600 ml-2 font-medium">(1,021)</span>
              </div>
            </div>
            
            {/* Main Title */}
            <div className="text-center lg:text-left">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-gray-900 leading-tight mb-3">
                <span className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 bg-clip-text text-transparent">
                  Schermo™ CarPlay
                </span>
              </h1>
            </div>

            {/* Price Section */}
            <div className="bg-white/95 backdrop-blur-sm p-3 lg:p-4 rounded-2xl shadow-lg border border-white/50">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl lg:text-3xl font-black text-blue-600">€79,99</span>
                  <div className="flex flex-col">
                    <span className="text-base lg:text-lg text-gray-500 line-through">€159,98</span>
                  </div>
                </div>
                <div className="text-center">
                  <div className="bg-red-500 text-white px-3 py-2 rounded-xl">
                    <span className="font-bold text-xs">50% SCONTO</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Features */}
            <div className="space-y-2">
              <div className="flex items-center space-x-3 text-gray-700">
                <Car className="h-5 w-5 text-blue-600 flex-shrink-0" />
                <span className="font-medium text-sm lg:text-base">Compatibile con ogni auto</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-700">
                <Clock className="h-5 w-5 text-blue-600 flex-shrink-0" />
                <span className="font-medium text-sm lg:text-base">2 Telecamere HD GRATUITE incluse</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-700">
                <Shield className="h-5 w-5 text-blue-600 flex-shrink-0" />
                <span className="font-medium text-sm lg:text-base">Garanzia di rimborso entro 30 giorni</span>
              </div>
              <div className="flex items-center space-x-3 text-gray-700">
                <Truck className="h-5 w-5 text-blue-600 flex-shrink-0" />
                <span className="font-medium text-sm lg:text-base">Consegna GRATUITA in 24-48h</span>
              </div>
            </div>

            {/* Payment Buttons */}
            <div className="space-y-3">
              {/* Urgency Text */}
              <div className="bg-red-50 border border-red-200 rounded-xl p-2 lg:p-3 text-center">
                <span className="text-red-700 font-bold text-xs lg:text-sm flex items-center justify-center space-x-1">
                  <span>🔥 Disponibilità: solo 7 articoli rimasti - affrettati!</span>
                </span>
              </div>
              
              {/* Paga con Carta Button */}
              <button
                onClick={handleCardPayment}
                className="w-full bg-gradient-to-r from-green-600 via-green-700 to-emerald-600 hover:from-green-700 hover:via-green-800 hover:to-emerald-700 text-white font-black py-3 lg:py-4 px-6 rounded-xl text-base lg:text-lg transition-all duration-300 transform active:scale-95 shadow-xl touch-manipulation"
              >
                PAGA ORA
              </button>

              {/* Paga alla Consegna Button */}
              <button
                onClick={handleOrderClick}
                className="w-full bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 hover:from-blue-700 hover:via-blue-800 hover:to-indigo-700 text-white font-black py-3 lg:py-4 px-6 rounded-xl text-base lg:text-lg transition-all duration-300 transform active:scale-95 shadow-xl touch-manipulation border-2 border-blue-500"
              >
                PAGA ALLA CONSEGNA
              </button>
            </div>

            {/* Klarna Payment Option */}
            <div className="bg-gradient-to-r from-pink-50 to-purple-50 p-3 rounded-xl border border-pink-200">
              <div className="flex items-center space-x-3">
                <div className="bg-pink-500 text-white px-3 py-1 rounded-lg font-bold text-sm">
                  Klarna
                </div>
                <span className="text-gray-700 font-medium text-sm lg:text-base">
                  Paga in 3 Rate da €26,33
                </span>
              </div>
            </div>

            {/* Payment Methods */}
            <div className="flex justify-center">
              <img 
                src="/Immagine 2025-07-09 102714.jpg" 
                alt="Metodi di pagamento accettati - Visa, Mastercard, American Express, Apple Pay, PayPal, Klarna" 
                className="object-contain"
                onError={(e) => {
                  console.log('Failed to load payment methods image');
                  e.currentTarget.style.display = 'none';
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CarPlayHero;