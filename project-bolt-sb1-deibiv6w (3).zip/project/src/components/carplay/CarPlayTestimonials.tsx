import React from 'react';
import { Star, CheckCircle, Users, Quote } from 'lucide-react';

const CarPlayTestimonials: React.FC = () => {
  const testimonials = [
    {
      name: "Francesco R.",
      verified: true,
      rating: 5,
      text: "Si connette rapidamente al telefono e lo schermo è chiaro e luminoso. Un ottimo acquisto per migliorare l'esperienza di guida",
      image: "/reviews/IMG_5970.jpeg"
    },
    {
      name: "Alessandro R.",
      verified: true,
      rating: 5,
      text: "Tutto come in descrizione! Ottimo prodotto, facile da installare e usare. Consigliato a chi vuole aggiornare la propria auto senza spendere una fortuna",
      image: "/reviews/IMG_5971.jpeg"
    },
    {
      name: "Matteo E.",
      verified: true,
      rating: 5,
      text: "L'ho installato sulla mia auto datata e funziona bene. Lo schermo da 9'' di dimensioni generose e il touchscreen è reattivo. Le immagini si vedono nitide anche con molta luce. L'installazione è stata semplice e Android Auto è pronto per l'uso",
      image: "/reviews/IMG_5972.jpeg"
    },
    {
      name: "Giulia P.",
      verified: true,
      rating: 5,
      text: "Incredibile la qualità delle telecamere! La registrazione è nitidissima e l'assistenza parcheggio è perfetta. Installazione facilissima, lo consiglio a tutti",
      image: "/reviews/IMG_5974.jpeg"
    },
    {
      name: "Roberto C.",
      verified: true,
      rating: 5,
      text: "Finalmente posso usare le mappe senza dover tenere il telefono in mano. La connessione wireless funziona perfettamente e lo schermo è molto luminoso",
      image: "/reviews/IMG_5968.jpeg"
    },
    {
      name: "Elena V.",
      verified: true,
      rating: 5,
      text: "Le telecamere sono un valore aggiunto incredibile! Ora mi sento molto più sicura quando parcheggio. Prodotto top, spedizione velocissima",
      image: "/reviews/IMG_5969.jpeg"
    },
    {
      name: "Davide M.",
      verified: true,
      rating: 5,
      text: "Trasformazione totale della mia auto! Lo schermo è grande e luminoso, perfetto anche sotto il sole. Le funzionalità CarPlay sono tutte perfette",
      image: "/reviews/IMG_5967.jpeg"
    },
    {
      name: "Marco T.",
      location: "Firenze",
      verified: true,
      rating: 5,
      text: "Kit completo perfetto! Tutto incluso nella confezione, installazione semplicissima. Le telecamere funzionano benissimo e la qualità è superiore alle aspettative",
      image: "/reviews/61qmaVG1xGL-768x433 (1).jpg",
      date: "2 settimane fa"
    },
    {
      name: "Simone L.",
      location: "Bologna",
      verified: true,
      rating: 5,
      text: "Installato sulla mia auto e funziona alla perfezione! Lo schermo è nitido, le funzioni sono intuitive e la connessione Bluetooth è stabile. Ottimo rapporto qualità-prezzo",
      image: "/reviews/71Ow3IpESmL-768x576.jpg",
      date: "1 settimana fa"
    },
    {
      name: "Andrea F.",
      location: "Palermo",
      verified: true,
      rating: 5,
      text: "Perfetto per la mia auto! L'installazione è stata velocissima, si adatta perfettamente al cruscotto. CarPlay e Android Auto funzionano senza problemi. Consigliatissimo!",
      image: "/reviews/81TS7daI6SL-768x1708.jpg",
      date: "3 giorni fa"
    }
  ];

  const stats = [
    { number: "3,580", label: "Clienti Soddisfatti", icon: Users },
    { number: "4.9/5", label: "Valutazione Media", icon: Star },
    { number: "98%", label: "Raccomandazioni", icon: CheckCircle }
  ];

  return (
    <section className="py-8 lg:py-16 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Users className="h-5 w-5 lg:h-6 lg:w-6 text-blue-600" />
            <span className="text-blue-600 font-bold text-sm lg:text-base">RECENSIONI CON FOTO REALI</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Cosa Dicono i Nostri
            <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Clienti Soddisfatti
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            Oltre 3.500 automobilisti in tutta Italia hanno già trasformato la loro auto con foto reali delle installazioni
          </p>
        </div>

        <div className="grid sm:grid-cols-3 gap-3 lg:gap-4 mb-6 lg:mb-8">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white p-3 lg:p-4 rounded-xl shadow-md border border-gray-100 text-center group hover:shadow-lg transition-all duration-300">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-600 w-8 h-8 lg:w-10 lg:h-10 rounded-lg flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform duration-300">
                <stat.icon className="h-4 w-4 lg:h-5 lg:w-5 text-white" />
              </div>
              <div className="text-lg lg:text-xl font-black text-gray-900 mb-1">{stat.number}</div>
              <div className="text-gray-600 font-semibold text-xs">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Reviews Grid - Matching Reference Design */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-4 lg:p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100 group">
              <div className="flex items-center justify-between mb-3 lg:mb-4">
                <Quote className="h-6 w-6 lg:h-8 lg:w-8 text-blue-600 opacity-60" />
                <div className="flex items-center space-x-1">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-3 w-3 lg:h-4 lg:w-4 text-yellow-400 fill-current" />
                  ))}
                </div>
              </div>
              
              <p className="text-gray-700 mb-3 lg:mb-4 italic leading-relaxed text-sm lg:text-base">
                "{testimonial.text}"
              </p>
              
              {/* Customer Photo */}
              <div className="mb-3 lg:mb-4">
                <div className="h-32 lg:h-40 rounded-xl overflow-hidden">
                  <img
                    src={testimonial.image}
                    alt={`Installazione CarPlay di ${testimonial.name}`}
                    className="w-full h-full object-contain bg-gray-50"
                    onError={(e) => {
                      console.log(`Failed to load testimonial image: ${testimonial.image}`);
                      const target = e.currentTarget as HTMLImageElement;
                      target.src = '/A-soli-49E-14-1024x1024.jpg';
                    }}
                  />
                </div>
              </div>
              
              <div className="border-t border-gray-100 pt-3 lg:pt-4">
                <div className="flex items-center justify-between mb-1">
                  <div>
                    <p className="font-bold text-gray-900 text-sm lg:text-base">{testimonial.name}</p>
                    {testimonial.location && (
                      <p className="text-gray-500 text-xs">{testimonial.location}</p>
                    )}
                  </div>
                  {testimonial.verified && (
                    <div className="flex items-center space-x-1 bg-green-50 px-2 py-1 rounded-full">
                      <CheckCircle className="h-3 w-3 text-green-600" />
                      <span className="text-green-700 text-xs font-semibold">Verificato</span>
                    </div>
                  )}
                </div>
                {testimonial.date && (
                  <p className="text-gray-400 text-xs">{testimonial.date}</p>
                )}
              </div>
              
              <div className="mt-3 lg:mt-4 h-1 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-full transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500" />
            </div>
          ))}
        </div>


        <div className="mt-8 lg:mt-12 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 rounded-2xl p-6 lg:p-8 text-white text-center">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <CheckCircle className="h-6 w-6 lg:h-8 lg:w-8" />
            <span className="text-lg lg:text-xl font-black">SODDISFATTI O RIMBORSATI</span>
          </div>
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-black mb-3 lg:mb-4">
            Garanzia di Soddisfazione 100%
          </h3>
          <p className="text-base sm:text-lg lg:text-xl opacity-90 max-w-3xl mx-auto leading-relaxed mb-4 lg:mb-6">
            Se non sei completamente soddisfatto del tuo acquisto, 
            ti rimborsiamo integralmente entro 14 giorni.
          </p>
          <div className="flex flex-col sm:flex-row flex-wrap justify-center gap-3 lg:gap-4 text-sm lg:text-base">
            <span className="bg-white/20 px-3 py-2 lg:px-4 lg:py-2 rounded-xl font-semibold">✅ Assistenza Italiana</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CarPlayTestimonials;