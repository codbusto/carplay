import React, { useState, useEffect } from 'react';
import { X, Shield, Truck, CreditCard, CheckCircle, AlertCircle } from 'lucide-react';
import { sendToTelegram, OrderData } from '../../telegramService';
import { trackLead, trackAddToCart, testPixelConnection } from '../../utils/facebookPixel';
import { trackOrderFormOpen, trackOrderFormSubmit } from '../../utils/clarityTracking';
import { setCrispUserData, trackCrispEvent } from '../../utils/crispChat';
import CarPlayThankYouPage from './CarPlayThankYouPage';

interface CarPlayOrderFormProps {
  isOpen: boolean;
  onClose: () => void;
}

const CarPlayOrderForm: React.FC<CarPlayOrderFormProps> = ({ isOpen, onClose }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    province: '',
    quantity: 1,
    notes: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');
  const [submitType, setSubmitType] = useState<'success' | 'error' | ''>('');
  const [showThankYou, setShowThankYou] = useState(false);
  const [orderDetails, setOrderDetails] = useState<{
    orderNumber: string;
    customerName: string;
    totalAmount: number;
  } | null>(null);

  useEffect(() => {
    if (isOpen) {
      const pixelWorking = testPixelConnection();
      console.log('📊 CarPlay Pixel connection test result:', pixelWorking);
      
      trackAddToCart(formData.quantity);
      trackOrderFormOpen();
      trackCrispEvent('order_form_viewed', {
        product: 'carplay_android_auto',
        quantity: formData.quantity,
        pixel_working: pixelWorking
      });
    }
  }, [isOpen, formData.quantity]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const generateOrderNumber = () => {
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `CP${timestamp}${random}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitMessage('');
    setSubmitType('');

    try {
      const totalPrice = 79.99 * formData.quantity;
      const orderNumber = generateOrderNumber();
      const orderDate = new Date().toLocaleString('it-IT');
      const customerName = `${formData.firstName} ${formData.lastName}`;

      const orderData: OrderData = {
        name: customerName,
        email: formData.email || 'noemail@tuttosconto.store',
        phone: formData.phone,
        address: formData.address,
        city: formData.city,
        province: formData.province || 'XX',
        cap: formData.postalCode,
        quantity: formData.quantity,
        totalPrice,
        orderDate,
        orderNumber
      };

      console.log('📋 Processing CarPlay order:', orderData);

      const telegramSuccess = await sendToTelegram(orderData);

      // Track the CARPLAY LEAD regardless of Telegram status - CRITICAL FOR PIXEL TRACKING
      const leadEventIDs = trackLead({
        content_name: 'CarPlay Android Auto Display',
        content_category: 'Electronics',
        value: totalPrice,
        currency: 'EUR',
        lead_type: 'order_form',
        customer_name: customerName,
        customer_email: formData.email,
        customer_phone: formData.phone,
        quantity: formData.quantity,
        order_number: orderNumber,
        telegram_success: telegramSuccess
      });

      trackOrderFormSubmit({
        orderNumber,
        totalAmount: totalPrice,
        quantity: formData.quantity
      });

      setCrispUserData({
        email: formData.email,
        name: customerName,
        phone: formData.phone,
        city: formData.city,
        order_number: orderNumber,
        product: 'carplay_android_auto'
      });

      trackCrispEvent('order_completed', {
        order_number: orderNumber,
        customer_name: customerName,
        total_amount: totalPrice,
        quantity: formData.quantity,
        product: 'carplay_android_auto',
        lead_event_ids: leadEventIDs
      });

      // Always show success page
      setOrderDetails({
        orderNumber,
        customerName,
        totalAmount: totalPrice
      });
      
      setShowThankYou(true);
      
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        address: '',
        city: '',
        postalCode: '',
        province: '',
        quantity: 1,
        notes: ''
      });

    } catch (error) {
      console.error('Order submission error:', error);
      
      const orderNumber = generateOrderNumber();
      const customerName = `${formData.firstName} ${formData.lastName}`;
      const totalPrice = 79.99 * formData.quantity;
      
      // Still track the CARPLAY LEAD even on error - IMPORTANT FOR PIXEL DATA
      const errorLeadEventIDs = trackLead({
        content_name: 'CarPlay Android Auto Display',
        content_category: 'Electronics',
        value: totalPrice,
        currency: 'EUR',
        lead_type: 'order_form_error',
        customer_name: customerName,
        customer_email: formData.email,
        customer_phone: formData.phone,
        quantity: formData.quantity,
        order_number: orderNumber,
        error_occurred: true
      });
      
      trackCrispEvent('order_error', {
        customer_name: customerName,
        product: 'carplay_android_auto',
        order_number: orderNumber,
        error_occurred: true,
        error_lead_event_ids: errorLeadEventIDs
      });
      
      setOrderDetails({
        orderNumber,
        customerName,
        totalAmount: totalPrice
      });
      
      setShowThankYou(true);
      
      setFormData({
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        address: '',
        city: '',
        postalCode: '',
        province: '',
        quantity: 1,
        notes: ''
      });

      console.log('🎯 CarPlay Order Error: Still tracked LEAD for data capture');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCloseThankYou = () => {
    setShowThankYou(false);
    setOrderDetails(null);
    onClose();
  };

  if (!isOpen) return null;

  if (showThankYou && orderDetails) {
    return (
      <div className="fixed inset-0 bg-white z-50 overflow-y-auto">
        <CarPlayThankYouPage
          orderNumber={orderDetails.orderNumber}
          customerName={orderDetails.customerName}
          totalAmount={orderDetails.totalAmount}
          onClose={handleCloseThankYou}
        />
      </div>
    );
  }

  const totalPrice = 79.99 * formData.quantity;
  const originalPrice = 159.98 * formData.quantity;
  const savings = originalPrice - totalPrice;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-2">
      <div className="bg-white rounded-2xl max-w-md w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-4 rounded-t-2xl">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-black">Ordina Ora</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-full transition-colors touch-manipulation"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-3 space-y-3">
          {submitMessage && (
            <div className={`p-4 rounded-xl flex items-start space-x-3 ${
              submitType === 'success' 
                ? 'bg-green-50 border border-green-200' 
                : 'bg-red-50 border border-red-200'
            }`}>
              {submitType === 'success' ? (
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
              )}
              <p className={`font-medium leading-relaxed text-sm ${
                submitType === 'success' ? 'text-green-800' : 'text-red-800'
              }`}>
                {submitMessage}
              </p>
            </div>
          )}

          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-3 rounded-xl border border-blue-100">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <img 
                  src="/A-soli-49E-14-1024x1024.jpg" 
                  alt="CarPlay Display" 
                  className="w-12 h-12 object-cover rounded-lg"
                  onError={(e) => {
                    console.log('Failed to load order form image');
                    const target = e.currentTarget as HTMLImageElement;
                    target.src = '/A-soli-49E-14-1024x1024.jpg';
                  }}
                />
                <div>
                  <h3 className="font-bold text-xs text-gray-900">CarPlay Display + 2 Telecamere</h3>
                  <div className="flex items-center space-x-2">
                    <p className="text-blue-600 font-black text-xs">€79,99</p>
                    <span className="bg-red-100 text-red-800 px-1 py-0.5 rounded text-xs font-bold">-50%</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-lg font-black text-blue-600">€{totalPrice.toFixed(2)}</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <label className="font-medium text-gray-700 text-xs">Qtà:</label>
                <select
                  name="quantity"
                  value={formData.quantity}
                  onChange={handleInputChange}
                  className="border border-blue-200 rounded px-2 py-1 font-semibold focus:border-blue-500 text-xs touch-manipulation"
                >
                  {[1, 2, 3, 4, 5].map(num => (
                    <option key={num} value={num}>{num}</option>
                  ))}
                </select>
              </div>
              <div className="bg-green-100 text-green-800 px-2 py-1 rounded font-semibold text-xs">
                Spedizione GRATIS
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Nome *</label>
                <input
                  type="text"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleInputChange}
                  required
                  className="w-full border border-gray-200 rounded px-2 py-1.5 focus:border-blue-500 text-xs touch-manipulation"
                  placeholder="Nome"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Cognome *</label>
                <input
                  type="text"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleInputChange}
                  required
                  className="w-full border border-gray-200 rounded px-2 py-1.5 focus:border-blue-500 text-xs touch-manipulation"
                  placeholder="Cognome"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Email *</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                className="w-full border border-gray-200 rounded px-2 py-1.5 focus:border-blue-500 text-xs touch-manipulation"
                placeholder="email@esempio.it"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Telefono *</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                required
                className="w-full border border-gray-200 rounded px-2 py-1.5 focus:border-blue-500 text-xs touch-manipulation"
                placeholder="+39 123 456 7890"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">Indirizzo *</label>
              <input
                type="text"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                required
                className="w-full border border-gray-200 rounded px-2 py-1.5 focus:border-blue-500 text-xs touch-manipulation"
                placeholder="Via Roma 123"
              />
            </div>

            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Città *</label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleInputChange}
                  required
                  className="w-full border border-gray-200 rounded px-2 py-1.5 focus:border-blue-500 text-xs touch-manipulation"
                  placeholder="Milano"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">CAP *</label>
                <input
                  type="text"
                  name="postalCode"
                  value={formData.postalCode}
                  onChange={handleInputChange}
                  required
                  pattern="[0-9]{5}"
                  className="w-full border-2 border-gray-200 rounded-lg px-3 py-2 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-colors text-sm touch-manipulation"
                  className="w-full border border-gray-200 rounded px-2 py-1.5 focus:border-blue-500 text-xs touch-manipulation"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">Prov *</label>
                <input
                  type="text"
                  name="province"
                  value={formData.province}
                  onChange={handleInputChange}
                  required
                  maxLength={2}
                  className="w-full border border-gray-200 rounded px-2 py-1.5 focus:border-blue-500 text-xs touch-manipulation"
                  placeholder="MI"
                />
              </div>
            </div>

          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 hover:from-blue-700 hover:via-blue-800 hover:to-indigo-700 disabled:from-gray-400 disabled:to-gray-500 text-white font-black py-3 px-4 rounded-xl text-sm transition-all duration-300 transform active:scale-95 shadow-xl disabled:transform-none disabled:shadow-lg touch-manipulation"
          >
            {isSubmitting ? (
              <span className="flex items-center justify-center space-x-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                <span>Invio...</span>
              </span>
            ) : (
              `CONFERMA ORDINE - €${totalPrice.toFixed(2)}`
            )}
          </button>

          <p className="text-xs text-gray-500 text-center">
            Pagamento alla consegna - Nessun addebito anticipato
          </p>

        </form>
      </div>
    </div>
  );
};

export default CarPlayOrderForm;