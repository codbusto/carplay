import React from 'react';
import { Navigation, Phone, Music, MessageCircle, Car, Smartphone } from 'lucide-react';

const CarPlayBenefits: React.FC = () => {
  const benefits = [
    {
      title: "Navigazione e Controllo Vocale",
      subtitle: "Garantisce un'esperienza senza mani per un viaggio sicuro verso casa",
      image: "/A-soli-49E-8-768x768.jpg",
      features: ["Navigazione", "Chiamata", "Messaggistica", "Musica"],
      icons: [Navigation, Phone, MessageCircle, Music]
    }
  ];

  return (
    <section className="py-8 lg:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-12 lg:space-y-20">
          {benefits.map((benefit, index) => (
            <div key={index} className={`grid lg:grid-cols-2 gap-8 lg:gap-16 items-center ${
              index % 2 === 1 ? 'lg:grid-flow-col-dense' : ''
            }`}>
              
              {/* Image Section */}
              <div className={`relative ${index % 2 === 1 ? 'lg:col-start-2' : ''}`}>
                <div className="relative bg-white p-4 lg:p-6 rounded-3xl shadow-2xl border border-gray-100">
                  <div className="relative rounded-2xl overflow-hidden">
                    <img
                      src={benefit.image}
                      alt={benefit.title}
                      className="w-full h-64 lg:h-80 object-contain rounded-2xl bg-white"
                      onError={(e) => {
                        console.log(`Failed to load benefit image: ${benefit.image}`);
                        const target = e.currentTarget as HTMLImageElement;
                        target.src = '/A-soli-49E-14-1024x1024.jpg';
                      }}
                    />
                    
                    {/* Overlay with voice commands */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent rounded-2xl"></div>
                    
                    {/* Voice command bubbles */}
                    {index === 0 && (
                      <>
                        <div className="absolute top-4 left-4 bg-gray-900/90 backdrop-blur-sm text-white px-3 py-2 rounded-full text-sm font-medium">
                          Hey Siri, Chiama il cellulare di Eliza.
                        </div>
                        <div className="absolute top-16 right-4 bg-blue-600/90 backdrop-blur-sm text-white px-3 py-2 rounded-full text-sm font-medium">
                          Hey Google, Riproduci musica.
                        </div>
                        <div className="absolute bottom-4 right-4 bg-blue-600/90 backdrop-blur-sm text-white px-3 py-2 rounded-full text-sm font-medium">
                          Hey Google, Invia un messaggio a Liam.
                        </div>
                      </>
                    )}
                    
                    {index === 1 && (
                      <>
                        <div className="absolute top-4 left-4 bg-blue-600/90 backdrop-blur-sm text-white px-3 py-2 rounded-full text-sm font-medium flex items-center space-x-2">
                          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                          <span>Siri, qual è il mio ETA?</span>
                        </div>
                        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-xl shadow-lg">
                          <div className="flex items-center space-x-2">
                            <Car className="h-4 w-4 text-green-600" />
                            <span className="font-bold text-gray-900 text-sm">Lavora con il wireless</span>
                          </div>
                        </div>
                        <div className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-sm px-3 py-2 rounded-xl shadow-lg">
                          <div className="flex items-center space-x-2">
                            <Smartphone className="h-4 w-4 text-blue-600" />
                            <span className="font-bold text-gray-900 text-sm">Lavora con il wireless</span>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>

              {/* Content Section */}
              <div className={`space-y-4 lg:space-y-6 ${index % 2 === 1 ? 'lg:col-start-1' : ''}`}>
                <div>
                  <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-gray-900 mb-3 lg:mb-4 leading-tight">
                    {benefit.title}
                  </h2>
                  <p className="text-base sm:text-lg lg:text-xl text-gray-600 leading-relaxed">
                    {benefit.subtitle}
                  </p>
                </div>

                {/* Feature Icons */}
                <div className="flex flex-wrap gap-3 lg:gap-4">
                  {benefit.icons.map((Icon, iconIndex) => (
                    <div key={iconIndex} className="flex items-center space-x-2 bg-gray-50 px-3 py-2 lg:px-4 lg:py-3 rounded-xl border border-gray-200">
                      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-1.5 lg:p-2 rounded-lg">
                        <Icon className="h-4 w-4 lg:h-5 lg:w-5 text-white" />
                      </div>
                      <span className="font-semibold text-gray-900 text-sm lg:text-base">
                        {benefit.features[iconIndex] || benefit.features[0]}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Special content for specific benefits */}
                {index === 2 && (
                  <div className="bg-gradient-to-r from-gray-50 to-gray-100 p-4 lg:p-6 rounded-2xl border border-gray-200">
                    <div className="text-center mb-4">
                      <h3 className="text-lg lg:text-xl font-bold text-gray-900 mb-2">
                        Compatibile con qualsiasi auto e cellulare
                      </h3>
                      <p className="text-gray-600 text-sm lg:text-base">Connessione Tramite Bluetooth</p>
                    </div>
                    
                    <div className="flex justify-center">
                      <img
                        src="/A-soli-49E-13-1024x1024.jpg"
                        alt="Bluetooth Connection"
                        className="w-32 h-32 lg:w-40 lg:h-40 object-cover rounded-2xl shadow-lg"
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 gap-2 lg:gap-3 mt-4">
                      {[
                        "/A-soli-49E-8-768x768.jpg",
                        "/A-soli-49E-11-768x768.jpg",
                        "/A-soli-49E-14-1024x1024.jpg",
                        "/A-soli-49E-13-1024x1024.jpg"
                      ].map((img, imgIndex) => (
                        <div key={imgIndex} className="w-full h-16 lg:h-20 rounded-xl overflow-hidden">
                          <img
                            src={img}
                            alt={`Compatible device ${imgIndex + 1}`}
                            className="w-full h-full object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CarPlayBenefits;