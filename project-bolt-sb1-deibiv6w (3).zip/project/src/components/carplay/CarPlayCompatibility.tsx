import React from 'react';
import { Car, Smartphone, Bluetooth, Star } from 'lucide-react';

const CarPlayCompatibility: React.FC = () => {
  return (
    <section className="py-8 lg:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Star className="h-5 w-5 lg:h-6 lg:w-6 text-yellow-500" />
            <span className="text-yellow-600 font-bold text-sm lg:text-base">COMPATIBILITÀ UNIVERSALE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Compatibile con
            <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              qualsiasi auto e cellulare
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            Connessione Tramite Bluetooth - Funziona con ogni veicolo e smartphone
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Left Column - Main Product */}
          <div className="space-y-4 lg:space-y-6 order-2 lg:order-1">
            <div className="relative bg-white p-4 lg:p-6 rounded-3xl shadow-2xl border border-gray-100">
              <div className="absolute top-4 left-4 bg-yellow-500 text-white px-3 py-2 rounded-full text-sm font-bold">
                €79,99
              </div>
              
              <div className="relative rounded-2xl overflow-hidden">
                <img
                  src="/Immagine 2025-07-08 221317 copy copy copy.jpg"
                  alt="CarPlay Android Auto Display - Compatibile con qualsiasi auto e cellulare"
                  className="w-full h-80 lg:h-96 object-cover rounded-2xl bg-white"
                  onError={(e) => {
                    console.log('Failed to load compatibility image');
                    const target = e.currentTarget as HTMLImageElement;
                    target.src = '/Immagine 2025-07-08 221317 copy copy copy.jpg';
                  }}
                />
                
                <div className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-sm p-3 rounded-xl shadow-lg">
                  <h3 className="font-bold text-gray-900 text-center mb-2">
                    Compatibile con qualsiasi auto e cellulare
                  </h3>
                  <div className="flex justify-center space-x-4">
                    <div className="flex items-center space-x-2">
                      <Car className="h-4 w-4 text-blue-600" />
                      <span className="text-sm font-medium text-gray-700">Ogni Auto</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Smartphone className="h-4 w-4 text-blue-600" />
                      <span className="text-sm font-medium text-gray-700">iOS & Android</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-gray-50 to-gray-100 p-4 lg:p-6 rounded-xl lg:rounded-2xl border border-gray-200">
              <div className="flex items-center space-x-2 mb-3 lg:mb-4">
                <Star className="h-5 w-5 lg:h-6 lg:w-6 text-yellow-500" />
                <h3 className="text-lg lg:text-xl font-bold text-gray-900">
                  Kit Completo Incluso
                </h3>
              </div>
              <div className="space-y-2 lg:space-y-3">
                {[
                  { item: "Display 4K Ultra HD", detail: "Schermo ad alta risoluzione" },
                  { item: "Supporto universale", detail: "Si adatta a ogni cruscotto" },
                  { item: "Camera frontale HD", detail: "Registrazione strada anteriore" },
                  { item: "Camera posteriore HD", detail: "Assistenza parcheggio e retromarcia" },
                  { item: "Cavi di alimentazione", detail: "12V compatibile con ogni auto" },
                  { item: "Telecomando wireless", detail: "Controllo a distanza" },
                  { item: "Manuale in italiano", detail: "Istruzioni complete" },
                  { item: "Garanzia 1 anno", detail: "Assistenza clienti italiana" }
                ].map((feature, index) => (
                  <div key={index} className="flex items-start space-x-2 p-2 lg:p-3 bg-white/80 rounded-xl">
                    <div className="w-2 h-2 bg-gray-900 rounded-full mt-2 flex-shrink-0"></div>
                    <div>
                      <span className="font-bold text-gray-900 block text-xs lg:text-sm">{feature.item}</span>
                      <span className="text-gray-600 text-xs">{feature.detail}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 lg:mt-6 p-3 lg:p-4 bg-gradient-to-r from-gray-900 to-black rounded-xl text-white text-center">
                <div className="mt-4 lg:mt-6 p-3 lg:p-4 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl text-white text-center">
                  <p className="text-sm lg:text-base font-bold">Valore del Kit: €199,98</p>
                  <p className="text-blue-100 text-xs lg:text-sm">Oggi a soli €79,99 - Risparmia €120!</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Accessories and Features */}
          <div className="space-y-4 lg:space-y-6 order-1 lg:order-2">
            <div className="bg-gradient-to-br from-gray-50 to-gray-100 p-4 lg:p-6 rounded-xl lg:rounded-2xl border border-gray-200">
              <div className="flex items-center space-x-2 mb-3 lg:mb-4">
                <Bluetooth className="h-5 w-5 lg:h-6 lg:w-6 text-blue-600" />
                <h3 className="text-lg lg:text-xl font-bold text-gray-900">
                  Connessione Bluetooth Universale
                </h3>
              </div>
              <p className="text-sm lg:text-base text-gray-700 leading-relaxed mb-3 lg:mb-4">
                Il nostro display si collega a qualsiasi auto tramite Bluetooth e supporta 
                sia iPhone che smartphone Android. <strong>Nessun cablaggio necessario</strong> - 
                funziona immediatamente con ogni veicolo.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-blue-100 text-blue-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">iPhone</span>
                <span className="bg-green-100 text-green-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">Android</span>
                <span className="bg-purple-100 text-purple-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">CarPlay</span>
                <span className="bg-orange-100 text-orange-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">Android Auto</span>
              </div>
            </div>

            {/* Compatibility Grid */}
            <div className="grid grid-cols-2 gap-3 lg:gap-4">
              <div className="bg-white p-3 lg:p-4 rounded-xl shadow-md border border-gray-100 text-center">
                <Car className="h-8 w-8 lg:h-10 lg:w-10 text-blue-600 mx-auto mb-2" />
                <div className="text-sm lg:text-base font-bold text-gray-900">Ogni Auto</div>
                <div className="text-xs text-gray-600">Universale</div>
              </div>
              <div className="bg-white p-3 lg:p-4 rounded-xl shadow-md border border-gray-100 text-center">
                <Smartphone className="h-8 w-8 lg:h-10 lg:w-10 text-blue-600 mx-auto mb-2" />
                <div className="text-sm lg:text-base font-bold text-gray-900">Ogni Phone</div>
                <div className="text-xs text-gray-600">iOS & Android</div>
              </div>
              <div className="bg-white p-3 lg:p-4 rounded-xl shadow-md border border-gray-100 text-center">
                <Bluetooth className="h-8 w-8 lg:h-10 lg:w-10 text-blue-600 mx-auto mb-2" />
                <div className="text-sm lg:text-base font-bold text-gray-900">Bluetooth</div>
                <div className="text-xs text-gray-600">Wireless</div>
              </div>
              <div className="bg-white p-3 lg:p-4 rounded-xl shadow-md border border-gray-100 text-center">
                <Star className="h-8 w-8 lg:h-10 lg:w-10 text-blue-600 mx-auto mb-2" />
                <div className="text-sm lg:text-base font-bold text-gray-900">4K HD</div>
                <div className="text-xs text-gray-600">Ultra HD</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CarPlayCompatibility;