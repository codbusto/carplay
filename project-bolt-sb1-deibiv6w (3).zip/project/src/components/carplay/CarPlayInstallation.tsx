import React from 'react';
import { Play, Zap, Settings, CheckCircle, ArrowRight, Monitor, Star, Smartphone, Car, Wifi } from 'lucide-react';

const CarPlayInstallation: React.FC = () => {
  const steps = [
    {
      number: "01",
      title: "Posiziona il Display",
      description: "Posiziona il display sul cruscotto nella posizione desiderata",
      icon: Monitor,
      color: "blue"
    },
    {
      number: "02", 
      title: "Collega l'Alimentazione",
      description: "Collega il cavo di alimentazione alla presa 12V dell'auto",
      icon: Zap,
      color: "green"
    },
    {
      number: "03",
      title: "Connetti il Telefono",
      description: "Attiva il Bluetooth e connetti il tuo smartphone",
      icon: Settings,
      color: "purple"
    },
    {
      number: "04",
      title: "Inizia ad Usare",
      description: "CarPlay/Android Auto si attiva automaticamente",
      icon: CheckCircle,
      color: "orange"
    }
  ];

  return (
    <section className="py-8 lg:py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Play className="h-5 w-5 lg:h-6 lg:w-6 text-blue-600" />
            <span className="text-blue-600 font-bold text-sm lg:text-base">INSTALLAZIONE FACILE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Si monta in
            <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              un attimo!
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            <strong>Non è necessario smontare niente!</strong><br />
            Basta posizionarlo e collegarlo per iniziare a usarlo <strong>immediatamente</strong>. 
            La base è durevole, non lascia tracce e lo schermo può essere rimosso dal 
            supporto in qualsiasi momento.
          </p>
          
          {/* Installation Demo GIF - Right after the text */}
          <div className="mt-8 lg:mt-12 max-w-2xl mx-auto">
            <div className="relative bg-white p-4 lg:p-6 rounded-3xl shadow-2xl border border-gray-100">
              <div className="relative rounded-2xl overflow-hidden">
                <img
                  src="/How.gif"
                  alt="Dimostrazione installazione CarPlay - collegamento semplice e veloce"
                  className="w-full h-auto rounded-2xl bg-white"
                  style={{ maxHeight: '400px', objectFit: 'cover' }}
                  onError={(e) => {
                    console.log('Failed to load installation GIF');
                    const target = e.currentTarget as HTMLImageElement;
                    target.src = '/How copy.gif';
                    target.onerror = () => {
                      target.src = '/A-soli-49E-14-1024x1024.jpg';
                    };
                  }}
                />
                
                <div className="absolute bottom-4 left-4 bg-green-500/95 backdrop-blur-sm px-3 py-2 rounded-xl shadow-lg">
                  <span className="font-bold text-white text-sm">FACILE!</span>
                </div>
                
                <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-sm px-3 py-2 rounded-xl shadow-lg">
                  <div className="flex items-center space-x-2">
                    <Zap className="h-4 w-4 text-blue-600" />
                    <span className="font-bold text-gray-900 text-sm">2 MINUTI</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 lg:mt-6 text-center">
                <h3 className="text-lg lg:text-xl font-bold text-gray-900 mb-2">
                  Guarda Quanto è Semplice!
                </h3>
                <p className="text-gray-600 text-sm lg:text-base">
                  Collegamento rapido e installazione immediata
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Installation Steps - Now Full Width */}
          <div className="lg:col-span-2 space-y-4 lg:space-y-6">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {steps.map((step, index) => {
              const colorClasses = {
                blue: "from-blue-500 to-blue-600 bg-blue-50 text-blue-600",
                green: "from-green-500 to-green-600 bg-green-50 text-green-600", 
                purple: "from-purple-500 to-purple-600 bg-purple-50 text-purple-600",
                orange: "from-orange-500 to-orange-600 bg-orange-50 text-orange-600"
              };
              
              const [gradient, bgColor, textColor] = colorClasses[step.color as keyof typeof colorClasses].split(' ');
              
              return (
                <div key={index} className="group flex flex-col items-center text-center space-y-3 p-4 lg:p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
                  <div className={`bg-gradient-to-r ${gradient} w-12 h-12 lg:w-16 lg:h-16 rounded-2xl flex items-center justify-center text-white font-black text-lg lg:text-xl shadow-lg group-hover:scale-110 transition-transform duration-300 flex-shrink-0`}>
                    {step.number}
                  </div>
                  
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center justify-center space-x-2 mb-2">
                      <step.icon className={`h-5 w-5 lg:h-6 lg:w-6 ${textColor}`} />
                      <h3 className="text-base lg:text-lg font-bold text-gray-900 group-hover:text-gray-700 transition-colors">
                        {step.title}
                      </h3>
                    </div>
                    <p className="text-gray-600 leading-relaxed text-sm lg:text-base">
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
            </div>
            
            {/* Quick Installation Guarantee */}
            <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-4 lg:p-6 rounded-2xl text-white text-center shadow-xl mt-6">
              <div className="flex items-center justify-center space-x-2 mb-2 lg:mb-3">
                <CheckCircle className="h-6 w-6 lg:h-8 lg:w-8" />
                <span className="text-lg lg:text-xl font-black">INSTALLAZIONE IN 2 MINUTI</span>
              </div>
              <p className="text-green-100 text-sm lg:text-base">
                Nessuna modifica permanente alla tua auto. 
                <strong className="text-white">Base removibile e riutilizzabile!</strong>
              </p>
            </div>
            
            {/* Advanced Benefits Section - Right after installation guarantee */}
            <div className="mt-8 lg:mt-12">
              <div className="text-center mb-6 lg:mb-8">
                <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
                  <Star className="h-5 w-5 lg:h-6 lg:w-6 text-blue-600" />
                  <span className="text-blue-600 font-bold text-sm lg:text-base">ESPERIENZA PREMIUM</span>
                </div>
                <h3 className="text-xl sm:text-2xl lg:text-3xl font-black text-gray-900 mb-3 lg:mb-4">
                  Trasforma la Tua Auto in un
                  <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                    Centro Multimediale Intelligente
                  </span>
                </h3>
              </div>

              <div className="grid lg:grid-cols-2 gap-6 lg:gap-8 items-center">
                {/* Left Column - GIF Demo - Now First */}
                <div className="order-1 lg:order-1">
                  <div className="relative bg-white p-3 lg:p-4 rounded-2xl shadow-lg border border-gray-100">
                    <div className="relative rounded-xl overflow-hidden">
                      <img
                        src="/222222 copy.gif"
                        alt="Dimostrazione avanzata CarPlay - controllo completo delle app e funzionalità"
                        className="w-full h-auto rounded-xl bg-black"
                        style={{ maxHeight: '300px', objectFit: 'cover' }}
                        onError={(e) => {
                          console.log('Failed to load 222222 copy.gif, trying fallbacks');
                          const target = e.currentTarget as HTMLImageElement;
                          target.src = '/222222.gif';
                          target.onerror = () => {
                            target.src = '/How.gif';
                            target.onerror = () => {
                              target.src = '/A-soli-49E-14-1024x1024.jpg';
                            };
                          };
                        }}
                      />
                      
                      <div className="absolute bottom-3 left-3 bg-blue-500/95 backdrop-blur-sm px-2 py-1 rounded-lg shadow-lg">
                        <span className="font-bold text-white text-xs">CONTROLLO TOTALE</span>
                      </div>
                      
                      <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-sm px-2 py-1 rounded-lg shadow-lg">
                        <div className="flex items-center space-x-1">
                          <Smartphone className="h-3 w-3 text-blue-600" />
                          <span className="font-bold text-gray-900 text-xs">WIRELESS</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-3 text-center">
                      <h4 className="text-base lg:text-lg font-bold text-gray-900 mb-1">
                        Controllo Completo delle App
                      </h4>
                      <p className="text-gray-600 text-xs lg:text-sm">
                        Accedi a tutte le funzionalità del tuo smartphone
                      </p>
                    </div>
                  </div>
                </div>

                {/* Right Column - Quick Benefits */}
                <div className="order-2 lg:order-2 space-y-3 lg:space-y-4">
                  {[
                    {
                      icon: Smartphone,
                      title: "Telecamere HD",
                      description: "Camera frontale e posteriore per sicurezza totale",
                      color: "blue"
                    },
                    {
                      icon: Car,
                      title: "Registrazione Continua",
                      description: "Registra automaticamente durante la guida",
                      color: "green"
                    },
                    {
                      icon: Wifi,
                      title: "Assistenza Parcheggio",
                      description: "Camera posteriore per manovre sicure",
                      color: "purple"
                    }
                  ].map((benefit, index) => {
                    const colorClasses = {
                      blue: "from-blue-500 to-blue-600 text-blue-600",
                      green: "from-green-500 to-green-600 text-green-600",
                      purple: "from-purple-500 to-purple-600 text-purple-600"
                    };
                    
                    const [gradient, textColor] = colorClasses[benefit.color as keyof typeof colorClasses].split(' ');
                    
                    return (
                      <div key={index} className="flex items-start space-x-3 p-3 lg:p-4 bg-white rounded-xl shadow-md border border-gray-100">
                        <div className={`bg-gradient-to-r ${gradient} p-2 rounded-lg shadow-lg`}>
                          <benefit.icon className="h-4 w-4 lg:h-5 lg:w-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <h5 className="text-sm lg:text-base font-bold text-gray-900 mb-1">
                            {benefit.title}
                          </h5>
                          <p className="text-gray-600 text-xs lg:text-sm leading-relaxed">
                            {benefit.description}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CarPlayInstallation;