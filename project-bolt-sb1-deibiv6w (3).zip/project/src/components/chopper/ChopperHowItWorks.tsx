import React from 'react';
import { Play, Zap, ChefHat, CheckCircle, ArrowRight } from 'lucide-react';

const ChopperHowItWorks: React.FC = () => {
  const steps = [
    {
      number: "01",
      title: "Scegli la Lama",
      description: "3 lame intercambiabili per ogni tipo di taglio",
      icon: ChefHat,
      color: "green"
    },
    {
      number: "02", 
      title: "Aggiungi Verdure",
      description: "Inserisci verdure, frutta o formaggio nel contenitore",
      icon: ArrowRight,
      color: "blue"
    },
    {
      number: "03",
      title: "Premi il Pulsante",
      description: "Un semplice click per tritare tutto perfettamente",
      icon: Zap,
      color: "purple"
    },
    {
      number: "04",
      title: "Risultato Perfetto",
      description: "Verdure tritate uniformemente in pochi secondi",
      icon: CheckCircle,
      color: "orange"
    }
  ];

  return (
    <section className="py-8 lg:py-16 bg-gradient-to-b from-green-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Play className="h-5 w-5 lg:h-6 lg:w-6 text-green-600" />
            <span className="text-green-600 font-bold text-sm lg:text-base">SEMPLICITÀ ESTREMA</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Come Funziona il Tuo
            <span className="block bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Tritatutto Professionale
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            Facilità d'uso incredibile per risultati da chef. 
            Bastano 4 semplici passaggi per tritare come un professionista.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          <div className="order-2 lg:order-1">
            <div className="relative bg-white p-4 lg:p-6 rounded-3xl shadow-2xl border border-gray-100">
              <div className="relative rounded-2xl overflow-hidden bg-gray-100">
                <img
                  src="/0F7CD39E-3DC2-48A9-AB3E-D46F61C26BED (1).gif"
                  alt="Dimostrazione pratica del tritatutto elettrico in azione - come usare facilmente"
                  className="w-full h-auto rounded-2xl"
                  style={{ maxHeight: '400px', objectFit: 'cover' }}
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
                
                <div className="absolute top-4 left-4 bg-green-500 text-white px-3 py-2 rounded-full flex items-center space-x-2 shadow-lg">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  <span className="font-bold text-sm">DEMO LIVE</span>
                </div>
                
                <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-sm px-3 py-2 rounded-xl shadow-lg">
                  <div className="flex items-center space-x-2">
                    <Zap className="h-4 w-4 text-green-600" />
                    <span className="font-bold text-gray-900 text-sm">USB</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 lg:mt-6 text-center">
                <h3 className="text-lg lg:text-xl font-bold text-gray-900 mb-2">
                  Potenza Elettrica, Semplicità d'Uso
                </h3>
                <p className="text-gray-600 text-sm lg:text-base">
                  Guarda quanto è facile ottenere risultati perfetti con il nostro tritatutto USB
                </p>
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-2 space-y-4 lg:space-y-6">
            {steps.map((step, index) => {
              const colorClasses = {
                green: "from-green-500 to-green-600 bg-green-50 text-green-600",
                blue: "from-blue-500 to-blue-600 bg-blue-50 text-blue-600", 
                purple: "from-purple-500 to-purple-600 bg-purple-50 text-purple-600",
                orange: "from-orange-500 to-orange-600 bg-orange-50 text-orange-600"
              };
              
              const [gradient, bgColor, textColor] = colorClasses[step.color as keyof typeof colorClasses].split(' ');
              
              return (
                <div key={index} className="group flex items-start space-x-4 lg:space-x-6 p-4 lg:p-6 bg-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
                  <div className={`bg-gradient-to-r ${gradient} w-12 h-12 lg:w-16 lg:h-16 rounded-2xl flex items-center justify-center text-white font-black text-lg lg:text-xl shadow-lg group-hover:scale-110 transition-transform duration-300 flex-shrink-0`}>
                    {step.number}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2 lg:mb-3">
                      <step.icon className={`h-5 w-5 lg:h-6 lg:w-6 ${textColor}`} />
                      <h3 className="text-lg lg:text-xl font-bold text-gray-900 group-hover:text-gray-700 transition-colors">
                        {step.title}
                      </h3>
                    </div>
                    <p className="text-gray-600 leading-relaxed text-sm lg:text-base">
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
            
            <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-4 lg:p-6 rounded-2xl text-white text-center shadow-xl">
              <div className="flex items-center justify-center space-x-2 mb-2 lg:mb-3">
                <CheckCircle className="h-6 w-6 lg:h-8 lg:w-8" />
                <span className="text-lg lg:text-xl font-black">PRONTO IN 30 SECONDI</span>
              </div>
              <p className="text-green-100 text-sm lg:text-base">
                Dalla scatola al primo utilizzo in meno di mezzo minuto. 
                <strong className="text-white">Garanzia di semplicità!</strong>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChopperHowItWorks;