import React from 'react';
import { ChefHat, Zap, Settings, Utensils, Home, Leaf, Shield, Droplets } from 'lucide-react';

const ChopperFeatures: React.FC = () => {
  const features = [
    {
      icon: ChefHat,
      title: "3 Lame Intercambiabili",
      description: "Lama fine, media e grossa per ogni tipo di taglio. Acciaio inox di qualità professionale.",
      color: "green"
    },
    {
      icon: Zap,
      title: "Ricarica USB",
      description: "Batteria ricaricabile tramite USB. Autonomia fino a 50 utilizzi con una sola carica.",
      color: "blue"
    },
    {
      icon: Settings,
      title: "Controllo Preciso",
      description: "Pulsante di controllo per regolare la velocità e ottenere il taglio perfetto.",
      color: "purple"
    },
    {
      icon: Utensils,
      title: "Perfetto per Cucina",
      description: "Ideale per cipolle, aglio, verdure, frutta, noci e formaggio. Risultati uniformi sempre.",
      color: "orange"
    },
    {
      icon: Home,
      title: "Compatto e Pratico",
      description: "Design compatto che occupa poco spazio. Perfetto per ogni cucina, anche la più piccola.",
      color: "cyan"
    },
    {
      icon: Droplets,
      title: "Facile da Pulire",
      description: "Lavabile in lavastoviglie. Smontaggio facile per una pulizia completa e igienica.",
      color: "indigo"
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      green: "from-green-500 to-green-600 text-green-600 bg-green-50",
      blue: "from-blue-500 to-blue-600 text-blue-600 bg-blue-50",
      purple: "from-purple-500 to-purple-600 text-purple-600 bg-purple-50",
      orange: "from-orange-500 to-orange-600 text-orange-600 bg-orange-50",
      cyan: "from-cyan-500 to-cyan-600 text-cyan-600 bg-cyan-50",
      indigo: "from-indigo-500 to-indigo-600 text-indigo-600 bg-indigo-50"
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section className="py-8 lg:py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Leaf className="h-5 w-5 lg:h-6 lg:w-6 text-green-600" />
            <span className="text-green-600 font-bold text-sm lg:text-base">TECNOLOGIA AVANZATA</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Perché Scegliere il Nostro
            <span className="block bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Tritatutto Professionale?
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Tecnologia all'avanguardia, design ergonomico italiano e prestazioni professionali 
            per risultati impeccabili in ogni preparazione culinaria.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
          {features.map((feature, index) => {
            const colorClasses = getColorClasses(feature.color);
            const [gradientFrom, gradientTo, textColor, bgColor] = colorClasses.split(' ');
            
            return (
              <div 
                key={index} 
                className="group bg-white p-4 lg:p-6 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 border border-gray-100"
              >
                <div className="flex items-start space-x-3 mb-3 lg:mb-4">
                  <div className={`bg-gradient-to-r ${gradientFrom} ${gradientTo} p-2 lg:p-3 rounded-xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                    <feature.icon className="h-5 w-5 lg:h-6 lg:w-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-base lg:text-lg font-bold text-gray-900 mb-2 group-hover:text-gray-700 transition-colors">
                      {feature.title}
                    </h3>
                  </div>
                </div>
                <p className="text-gray-600 leading-relaxed text-sm lg:text-base">
                  {feature.description}
                </p>
                <div className={`mt-3 lg:mt-4 h-1 bg-gradient-to-r ${gradientFrom} ${gradientTo} rounded-full transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500`} />
              </div>
            );
          })}
        </div>

        <div className="mt-8 lg:mt-12 bg-gradient-to-r from-green-600 to-emerald-600 rounded-2xl p-6 lg:p-8 text-white text-center">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Shield className="h-6 w-6 lg:h-8 lg:w-8" />
            <span className="text-lg lg:text-xl font-bold">ACQUISTO PROTETTO</span>
          </div>
          <h3 className="text-xl sm:text-2xl lg:text-3xl font-black mb-3">
            Sicurezza e Garanzie Totali
          </h3>
          <p className="text-base lg:text-lg opacity-90 max-w-2xl mx-auto">
            1 anno di garanzia italiana, reso gratuito entro 14 giorni, 
            assistenza clienti dedicata e zero rischi per te.
          </p>
        </div>
      </div>
    </section>
  );
};

export default ChopperFeatures;