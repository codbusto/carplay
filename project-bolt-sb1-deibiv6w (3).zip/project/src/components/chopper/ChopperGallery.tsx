import React from 'react';
import { CheckCircle, Star, Package } from 'lucide-react';

const ChopperGallery: React.FC = () => {
  return (
    <section className="py-8 lg:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Star className="h-5 w-5 lg:h-6 lg:w-6 text-yellow-500" />
            <span className="text-yellow-600 font-bold text-sm lg:text-base">VERSATILITÀ CULINARIA</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Una Soluzione per
            <span className="block bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Ogni Preparazione
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            Dal taglio di verdure alla preparazione di salse, 
            scopri tutte le possibilità del tuo nuovo tritatutto elettrico
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 lg:gap-12 items-center">
          <div className="space-y-4 lg:space-y-6 order-2 lg:order-1">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-emerald-500/20 rounded-xl lg:rounded-2xl transform rotate-2 group-hover:rotate-1 transition-transform duration-300"></div>
              <img
                src="/Immagine 2025-07-01 222310 copy.jpg"
                alt="Kit completo tritatutto elettrico con 3 lame intercambiabili e risultati di taglio perfetti"
                className="relative w-full rounded-xl lg:rounded-2xl shadow-xl group-hover:shadow-2xl transition-shadow duration-300"
              />
              <div className="absolute top-3 left-3 lg:top-4 lg:left-4 bg-white/95 backdrop-blur-sm px-2 py-1 lg:px-3 lg:py-2 rounded-xl shadow-lg">
                <span className="font-bold text-gray-900 text-xs lg:text-sm">Kit Completo</span>
              </div>
              <div className="absolute bottom-3 right-3 lg:bottom-4 lg:right-4 bg-green-500/95 backdrop-blur-sm px-2 py-1 lg:px-3 lg:py-2 rounded-xl shadow-lg">
                <span className="font-bold text-white text-xs lg:text-sm">3 Lame Incluse</span>
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 lg:p-6 rounded-xl lg:rounded-2xl border border-green-100">
              <div className="flex items-center space-x-2 mb-3 lg:mb-4">
                <CheckCircle className="h-5 w-5 lg:h-6 lg:w-6 text-green-600" />
                <h3 className="text-lg lg:text-xl font-bold text-gray-900">
                  Preparazione Professionale Ovunque
                </h3>
              </div>
              <p className="text-sm lg:text-base text-gray-700 leading-relaxed mb-3 lg:mb-4">
                Dal taglio di verdure per insalate alla preparazione di salse e condimenti, 
                il nostro tritatutto garantisce risultati professionali con la 
                massima praticità d'uso. <strong>3 lame intercambiabili</strong> per ogni esigenza culinaria.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-green-100 text-green-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">Verdure</span>
                <span className="bg-blue-100 text-blue-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">Frutta</span>
                <span className="bg-purple-100 text-purple-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">Formaggio</span>
                <span className="bg-orange-100 text-orange-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">Noci</span>
              </div>
            </div>
          </div>

          <div className="space-y-4 lg:space-y-6 order-1 lg:order-2">
            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 p-4 lg:p-6 rounded-xl lg:rounded-2xl border border-blue-100">
              <div className="flex items-center space-x-2 mb-3 lg:mb-4">
                <Package className="h-5 w-5 lg:h-6 lg:w-6 text-blue-600" />
                <h3 className="text-lg lg:text-xl font-bold text-gray-900">
                  Kit Completo Incluso
                </h3>
              </div>
              <div className="space-y-2 lg:space-y-3">
                {[
                  { item: "Tritatutto elettrico USB", detail: "Motore potente e silenzioso" },
                  { item: "3 Lame intercambiabili", detail: "Fine, media e grossa" },
                  { item: "Contenitore 250ml", detail: "Materiale alimentare sicuro" },
                  { item: "Cavo USB ricarica", detail: "Compatibile con ogni caricatore" },
                  { item: "Manuale in italiano", detail: "Istruzioni complete e ricette" },
                  { item: "Garanzia 1 anno", detail: "Assistenza clienti italiana" }
                ].map((feature, index) => (
                  <div key={index} className="flex items-start space-x-2 p-2 lg:p-3 bg-white/80 rounded-xl">
                    <CheckCircle className="h-4 w-4 lg:h-5 lg:w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-bold text-gray-900 block text-xs lg:text-sm">{feature.item}</span>
                      <span className="text-gray-600 text-xs">{feature.detail}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 lg:mt-6 p-3 lg:p-4 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl text-white text-center">
                <p className="text-sm lg:text-base font-bold">Valore del Kit: €119,00</p>
                <p className="text-blue-100 text-xs lg:text-sm">Oggi a soli €34,99 - Risparmia €64!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChopperGallery;