import React, { useState, useEffect } from 'react';
import { Star, Zap, Shield, Truck, Clock, Award, CreditCard, ChefHat, Package, Check } from 'lucide-react';
import { trackInitiateCheckout, trackViewContent, trackTritatuttoEvent } from '../../utils/facebookPixel';
import { trackButtonClick, trackSectionView } from '../../utils/clarityTracking';

interface ChopperHeroProps {
  onOrderClick: (colorId?: string) => void;
  onColorChange?: (colorId: string) => void;
}

const ChopperHero: React.FC<ChopperHeroProps> = ({ onOrderClick, onColorChange }) => {
  const [selectedColor, setSelectedColor] = useState<string | null>(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const colorOptions = [
    {
      id: 'purple',
      name: 'Viola Elegante',
      hex: '#9333ea',
      mainImage: "/Immagine 2025-07-01 230807 copy.jpg"
    },
    {
      id: 'white',
      name: 'Bianco Classico',
      hex: '#f8fafc',
      border: '#e2e8f0',
      mainImage: "/Immagine 2025-07-01 230842.jpg"
    },
    {
      id: 'black',
      name: 'Nero Professionale',
      hex: '#1f2937',
      mainImage: "/Immagine 2025-07-01 230930.jpg"
    }
  ];

  const images = [
    {
      src: "/0F7CD39E-3DC2-48A9-AB3E-D46F61C26BED (1) copy.gif",
      alt: "Tritatutto Elettrico 3-in-1 in azione - dimostrazione pratica",
      isGif: true
    }
  ];

  useEffect(() => {
    // Single hero view tracking
    trackViewContent('Hero Section - Tritatutto Elettrico 3-in-1', 'hero');
    trackSectionView('hero');
    
    console.log('🎯 Tritatutto Hero: Tracking initialized (single event)');
  }, []);

  const handleOrderClick = () => {
    // Single checkout tracking
    trackInitiateCheckout({
      content_name: 'Tritatutto Elettrico 3-in-1',
      value: 54.99,
      currency: 'EUR',
      selected_color: selectedColor || 'no_color_selected'
    });
    
    trackButtonClick('order_now', 'hero_section');
    onOrderClick(selectedColor || undefined);
    
    console.log('🎯 Tritatutto Order Click: Single pixel event fired');
  };

  const handleColorChange = (colorId: string) => {
    setSelectedColor(colorId);
    
    const selectedColorOption = colorOptions.find(color => color.id === colorId);
    if (selectedColorOption) {
      setCurrentImageIndex(1);
    }
    
    // Single color selection tracking
    trackTritatuttoEvent('CustomizeProduct', {
      customization_type: 'color',
      selected_color: colorId,
      color_name: selectedColorOption?.name
    });
    
    if (onColorChange) {
      onColorChange(colorId);
    }
    
    console.log('🎯 Tritatutto Color Selection: Single pixel event fired for', colorId);
  };

  const getCurrentImage = () => {
    if (selectedColor && currentImageIndex === 1) {
      const selectedColorOption = colorOptions.find(color => color.id === selectedColor);
      return selectedColorOption?.mainImage || images[0].src;
    }
    return images[0].src;
  };

  const getCurrentImageAlt = () => {
    if (selectedColor && currentImageIndex === 1) {
      const selectedColorOption = colorOptions.find(color => color.id === selectedColor);
      return `Tritatutto Elettrico 3-in-1 - ${selectedColorOption?.name}`;
    }
    return images[0].alt;
  };

  return (
    <section className="relative bg-gradient-to-br from-slate-50 via-green-50 to-emerald-100 py-8 lg:py-20 overflow-hidden">
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-8 lg:space-y-0 lg:grid lg:grid-cols-2 lg:gap-16 lg:items-center">
          
          <div className="relative order-1 lg:order-2">
            <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 to-emerald-600/20 rounded-3xl transform rotate-2 scale-105"></div>
            <div className="absolute inset-0 bg-gradient-to-l from-lime-400/10 to-green-600/10 rounded-3xl transform -rotate-1 scale-110"></div>
            <div className="relative bg-white/95 backdrop-blur-sm rounded-3xl p-6 lg:p-8 shadow-2xl border border-white/50 overflow-hidden">
              
              <div className="absolute top-4 right-4 lg:top-6 lg:right-6 bg-gradient-to-r from-red-500 to-red-600 text-white px-4 py-2 lg:px-5 lg:py-3 rounded-2xl shadow-xl transform rotate-12 z-10">
                <span className="font-black text-sm lg:text-base">54% SCONTO</span>
              </div>

              <div className="relative h-72 sm:h-80 lg:h-[500px] mb-6">
                <img
                  src={getCurrentImage()}
                  alt={getCurrentImageAlt()}
                  className="w-full h-full object-contain rounded-2xl"
                  onError={(e) => {
                    console.log(`Failed to load image: ${getCurrentImage()}`);
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
              
              <div className="mb-4">
                <h3 className="text-sm font-bold text-gray-900 mb-3 text-center">Scegli il Colore</h3>
                <div className="flex justify-center space-x-4">
                  {colorOptions.map((color) => (
                    <button
                      key={color.id}
                      onClick={() => handleColorChange(color.id)}
                      className={`relative w-12 h-12 rounded-full border-4 transition-all duration-300 ${
                        selectedColor === color.id 
                          ? 'border-green-500 scale-110 shadow-lg' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      style={{ 
                        backgroundColor: color.hex,
                        borderColor: color.border || (selectedColor === color.id ? '#10b981' : '#e5e7eb')
                      }}
                      title={color.name}
                    >
                      {selectedColor === color.id && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Check className="h-5 w-5 text-white drop-shadow-lg" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>
                {selectedColor && (
                  <p className="text-center text-sm text-gray-600 mt-2 font-medium">
                    {colorOptions.find(c => c.id === selectedColor)?.name}
                  </p>
                )}
                {!selectedColor && (
                  <p className="text-center text-sm text-gray-500 mt-2">
                    Clicca per vedere i colori disponibili
                  </p>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-6 lg:space-y-8 order-2 lg:order-1">
            
            <div className="flex flex-col space-y-3 sm:flex-row sm:flex-wrap sm:items-center sm:space-y-0 sm:gap-4">
              <div className="flex items-center justify-center sm:justify-start space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 lg:h-5 lg:w-5 text-yellow-400 fill-current" />
                ))}
                <span className="text-sm lg:text-base text-gray-600 ml-2 font-medium">(1,247 recensioni)</span>
              </div>
              <div className="flex items-center justify-center sm:justify-start space-x-2 bg-white/80 backdrop-blur-sm px-3 py-2 rounded-full">
                <Award className="h-4 w-4 lg:h-5 lg:w-5 text-green-600" />
                <span className="text-sm font-semibold text-gray-700">Bestseller Cucina 2025</span>
              </div>
            </div>
            
            <div className="space-y-4 text-center lg:text-left">
              <h1 className="text-4xl sm:text-5xl lg:text-7xl font-black text-gray-900 leading-tight">
                <span className="bg-gradient-to-r from-green-600 via-green-700 to-emerald-600 bg-clip-text text-transparent block">
                  Tritatutto 3-in-1
                </span>
                <span className="text-2xl sm:text-3xl lg:text-5xl text-gray-700 block mt-2">
                  USB Ricaricabile
                </span>
              </h1>
              
              <p className="text-lg sm:text-xl lg:text-2xl text-gray-600 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                <span className="font-bold text-green-600">3 lame intercambiabili</span>, 
                ricarica <span className="font-bold text-green-600">USB</span>, 
                trita tutto in secondi.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-4 rounded-xl shadow-sm">
                <div className="bg-green-100 p-2 rounded-lg flex-shrink-0">
                  <Zap className="h-5 w-5 lg:h-6 lg:w-6 text-green-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-base">USB</span>
                  <span className="text-xs lg:text-sm text-gray-600">Ricaricabile</span>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-4 rounded-xl shadow-sm">
                <div className="bg-blue-100 p-2 rounded-lg flex-shrink-0">
                  <Shield className="h-5 w-5 lg:h-6 lg:w-6 text-blue-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-base">1 Anno</span>
                  <span className="text-xs lg:text-sm text-gray-600">Garanzia</span>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-4 rounded-xl shadow-sm">
                <div className="bg-purple-100 p-2 rounded-lg flex-shrink-0">
                  <ChefHat className="h-5 w-5 lg:h-6 lg:w-6 text-purple-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-base">3 Lame</span>
                  <span className="text-xs lg:text-sm text-gray-600">Incluse</span>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-4 rounded-xl shadow-sm">
                <div className="bg-orange-100 p-2 rounded-lg flex-shrink-0">
                  <Package className="h-5 w-5 lg:h-6 lg:w-6 text-orange-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-base">Lavabile</span>
                  <span className="text-xs lg:text-sm text-gray-600">Lavastoviglie</span>
                </div>
              </div>
            </div>

            <div className="flex flex-col space-y-3 sm:flex-row sm:flex-wrap sm:justify-center lg:justify-start sm:space-y-0 sm:gap-3">
              <div className="flex items-center justify-center space-x-2 bg-green-50 px-4 py-3 rounded-full border border-green-200">
                <Truck className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm lg:text-base font-semibold text-green-700">Consegna Gratuita</span>
              </div>
              <div className="flex items-center justify-center space-x-2 bg-blue-50 px-4 py-3 rounded-full border border-blue-200">
                <Clock className="h-5 w-5 text-blue-600 flex-shrink-0" />
                <span className="text-sm lg:text-base font-semibold text-blue-700">24-48h a Casa</span>
              </div>
              <div className="flex items-center justify-center space-x-2 bg-purple-50 px-4 py-3 rounded-full border border-purple-200">
                <CreditCard className="h-5 w-5 text-purple-600 flex-shrink-0" />
                <span className="text-sm lg:text-base font-semibold text-purple-700">Paga alla Consegna</span>
              </div>
            </div>

            <div className="bg-white/95 backdrop-blur-sm p-4 lg:p-6 rounded-2xl shadow-lg border border-white/50">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl lg:text-3xl font-black text-green-600">€54,99</span>
                  <div className="flex flex-col">
                    <span className="text-base lg:text-lg text-gray-500 line-through">€119,00</span>
                  </div>
                </div>
                <div className="text-center">
                  <div className="bg-red-100 text-red-800 px-3 py-2 rounded-xl">
                    <span className="font-bold text-xs">RISPARMIA</span>
                    <div className="font-black text-lg">€64</div>
                  </div>
                </div>
              </div>
            </div>

            <button
              onClick={handleOrderClick}
              className="w-full bg-gradient-to-r from-green-600 via-green-700 to-emerald-600 hover:from-green-700 hover:via-green-800 hover:to-emerald-700 text-white font-black py-4 lg:py-5 px-8 rounded-2xl text-lg lg:text-xl transition-all duration-300 transform active:scale-95 lg:hover:scale-105 shadow-2xl touch-manipulation"
            >
              ORDINA ORA
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChopperHero;