import React, { useState, useEffect } from 'react';
import { X, Shield, Truck, CreditCard, CheckCircle, AlertCircle, Check } from 'lucide-react';
import { sendToTelegram, OrderData } from '../../telegramService';
import { trackTritatuttoLead, trackAddToCart, testPixelConnection } from '../../utils/facebookPixel';
import { trackOrderFormOpen, trackOrderFormSubmit } from '../../utils/clarityTracking';
import { setCrispUserData, trackCrispEvent } from '../../utils/crispChat';
import ChopperThankYouPage from './ChopperThankYouPage';

interface ChopperOrderFormProps {
  isOpen: boolean;
  onClose: () => void;
  selectedColor?: string | null;
}

const ChopperOrderForm: React.FC<ChopperOrderFormProps> = ({ isOpen, onClose, selectedColor = null }) => {
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    address: '',
    city: '',
    postalCode: '',
    quantity: 1,
    color: selectedColor || 'purple'
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState('');
  const [submitType, setSubmitType] = useState<'success' | 'error' | ''>('');
  const [showThankYou, setShowThankYou] = useState(false);
  const [orderDetails, setOrderDetails] = useState<{
    orderNumber: string;
    customerName: string;
    totalAmount: number;
  } | null>(null);

  const colorOptions = [
    {
      id: 'purple',
      name: 'Viola Elegante',
      hex: '#9333ea',
      mainImage: "/Immagine 2025-07-01 230807 copy.jpg"
    },
    {
      id: 'white',
      name: 'Bianco Classico',
      hex: '#ffffff',
      border: '#d1d5db',
      mainImage: "/Immagine 2025-07-01 230842.jpg"
    },
    {
      id: 'black',
      name: 'Nero Professionale',
      hex: '#1f2937',
      mainImage: "/Immagine 2025-07-01 230930.jpg"
    }
  ];

  useEffect(() => {
    if (selectedColor) {
      setFormData(prev => ({
        ...prev,
        color: selectedColor
      }));
    }
  }, [selectedColor]);

  useEffect(() => {
    if (isOpen) {
      // Test pixel connection when form opens
      const pixelWorking = testPixelConnection();
      console.log('📊 Tritatutto Pixel connection test result:', pixelWorking);
      
      trackAddToCart(formData.quantity);
      trackOrderFormOpen();
      
      trackCrispEvent('order_form_viewed', {
        product: 'tritatutto_3in1',
        quantity: formData.quantity,
        selected_color: formData.color,
        pixel_working: pixelWorking
      });
    }
  }, [isOpen, formData.quantity, formData.color]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleColorChange = (colorId: string) => {
    setFormData(prev => ({
      ...prev,
      color: colorId
    }));
  };

  const generateOrderNumber = () => {
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    return `TC${timestamp}${random}`;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitMessage('');
    setSubmitType('');

    try {
      const totalPrice = 54.99 * formData.quantity;
      const orderNumber = generateOrderNumber();
      const orderDate = new Date().toLocaleString('it-IT');
      const customerName = formData.fullName;
      const selectedColorName = colorOptions.find(c => c.id === formData.color)?.name || 'Viola Elegante';

      const orderData: OrderData = {
        name: customerName,
        email: 'noemail@tuttosconto.store',
        phone: formData.phone,
        address: formData.address,
        city: formData.city,
        province: 'IT',
        cap: formData.postalCode,
        quantity: formData.quantity,
        totalPrice,
        orderDate,
        orderNumber
      };

      console.log('📋 Processing tritatutto order:', orderData);

      // Always proceed with order processing, even if Telegram fails
      const telegramSuccess = await sendToTelegram(orderData);

      // Track the lead - SINGLE EVENT
      const leadData = {
        content_name: `Tritatutto Elettrico 3-in-1 - ${selectedColorName}`,
        content_category: 'Kitchen & Dining',
        value: totalPrice,
        currency: 'EUR',
        lead_type: 'order_form',
        customer_name: customerName,
        customer_phone: formData.phone,
        quantity: formData.quantity,
        order_number: orderNumber,
        selected_color: formData.color,
        color_name: selectedColorName,
        telegram_success: telegramSuccess,
        order_timestamp: new Date().toISOString()
      };

      // Single lead tracking
      const leadEventIDs = trackTritatuttoLead(leadData);
      
      trackOrderFormSubmit({
        orderNumber,
        totalAmount: totalPrice,
        quantity: formData.quantity
      });

      setCrispUserData({
        name: customerName,
        phone: formData.phone,
        city: formData.city,
        order_number: orderNumber,
        product: 'tritatutto_3in1',
        selected_color: selectedColorName
      });

      trackCrispEvent('order_completed', {
        order_number: orderNumber,
        customer_name: customerName,
        total_amount: totalPrice,
        quantity: formData.quantity,
        product: 'tritatutto_3in1',
        selected_color: formData.color,
        lead_event_ids: leadEventIDs
      });

      // Always show success page
      setOrderDetails({
        orderNumber,
        customerName,
        totalAmount: totalPrice
      });
      
      setShowThankYou(true);
      
      setFormData({
        fullName: '',
        phone: '',
        address: '',
        city: '',
        postalCode: '',
        quantity: 1,
        color: selectedColor || 'purple'
      });

      console.log('🎯 Tritatutto Order Success: Lead tracked successfully');

    } catch (error) {
      console.error('Order submission error:', error);
      
      // Even on error, we'll show a success message since the order data is captured
      const orderNumber = generateOrderNumber();
      const customerName = formData.fullName;
      const totalPrice = 54.99 * formData.quantity;
      const selectedColorName = colorOptions.find(c => c.id === formData.color)?.name || 'Viola Elegante';
      
      // Still track the lead even on error - IMPORTANT FOR PIXEL DATA
      const errorLeadData = {
        content_name: `Tritatutto Elettrico 3-in-1 - ${selectedColorName}`,
        content_category: 'Kitchen & Dining',
        value: totalPrice,
        currency: 'EUR',
        lead_type: 'order_form_error',
        customer_name: customerName,
        customer_phone: formData.phone,
        quantity: formData.quantity,
        order_number: orderNumber,
        selected_color: formData.color,
        error_occurred: true,
        error_message: error instanceof Error ? error.message : 'Unknown error'
      };

      // Track error conversion events
      const errorLeadEventIDs = trackTritatuttoLead(errorLeadData);
      
      setOrderDetails({
        orderNumber,
        customerName,
        totalAmount: totalPrice
      });
      
      setShowThankYou(true);
      
      trackCrispEvent('order_error_but_processed', {
        error_message: error instanceof Error ? error.message : 'Unknown error',
        customer_name: formData.fullName,
        product: 'tritatutto_3in1',
        order_number: orderNumber,
        error_lead_event_ids: errorLeadEventIDs
      });
      
      setFormData({
        fullName: '',
        phone: '',
        address: '',
        city: '',
        postalCode: '',
        quantity: 1,
        color: selectedColor || 'purple'
      });

      console.log('🎯 Tritatutto Order Error: Still tracked lead for data capture');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCloseThankYou = () => {
    setShowThankYou(false);
    setOrderDetails(null);
    onClose();
  };

  if (!isOpen) return null;

  if (showThankYou && orderDetails) {
    return (
      <div className="fixed inset-0 bg-white z-50 overflow-y-auto">
        <ChopperThankYouPage
          orderNumber={orderDetails.orderNumber}
          customerName={orderDetails.customerName}
          totalAmount={orderDetails.totalAmount}
          onClose={handleCloseThankYou}
        />
      </div>
    );
  }

  const totalPrice = 54.99 * formData.quantity;
  const originalPrice = 119.00 * formData.quantity;
  const savings = originalPrice - totalPrice;
  const selectedColorOption = colorOptions.find(c => c.id === formData.color);

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[95vh] overflow-y-auto shadow-2xl">
        <div className="sticky top-0 bg-gradient-to-r from-green-600 to-emerald-600 text-white p-4 rounded-t-2xl">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-xl font-black mb-1">Completa il tuo Ordine</h2>
              <p className="text-green-100 text-sm">Pagamento sicuro alla consegna</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-full transition-colors touch-manipulation"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {submitMessage && (
            <div className={`p-4 rounded-xl flex items-start space-x-3 ${
              submitType === 'success' 
                ? 'bg-green-50 border border-green-200' 
                : 'bg-red-50 border border-red-200'
            }`}>
              {submitType === 'success' ? (
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="h-5 w-5 text-red-600 flex-shrink-0 mt-0.5" />
              )}
              <p className={`font-medium leading-relaxed text-sm ${
                submitType === 'success' ? 'text-green-800' : 'text-red-800'
              }`}>
                {submitMessage}
              </p>
            </div>
          )}

          <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl border border-green-100">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                <img 
                  src={selectedColorOption?.mainImage || "/Immagine 2025-07-01 230807 copy.jpg"} 
                  alt="Tritatutto" 
                  className="w-12 h-12 object-cover rounded-lg"
                />
                <div>
                  <h3 className="font-bold text-sm text-gray-900">Tritatutto Elettrico 3-in-1</h3>
                  <p className="text-xs text-gray-600">{selectedColorOption?.name}</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-green-600 font-black text-sm">€54,99</p>
                    <p className="text-gray-500 line-through text-xs">€119,00</p>
                    <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-bold">-54%</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xl font-black text-green-600">€{totalPrice.toFixed(2)}</span>
                <div className="text-xs text-gray-500">Risparmi €{savings.toFixed(2)}</div>
              </div>
            </div>

            <div className="mb-3">
              <h4 className="text-sm font-bold text-gray-900 mb-2">Scegli il Colore:</h4>
              <div className="flex items-center space-x-4">
                {colorOptions.map((color) => (
                  <button
                    key={color.id}
                    type="button"
                    onClick={() => handleColorChange(color.id)}
                    className={`relative w-10 h-10 rounded-full border-3 transition-all duration-300 shadow-md ${
                      formData.color === color.id 
                        ? 'border-green-500 scale-110 shadow-lg ring-2 ring-green-200' 
                        : 'border-gray-300 hover:border-gray-400'
                    }`}
                    style={{ 
                      backgroundColor: color.hex,
                      borderWidth: '3px',
                      borderColor: color.border || (formData.color === color.id ? '#10b981' : '#e5e7eb')
                    }}
                    title={color.name}
                  >
                    {color.id === 'white' && (
                      <div className="absolute inset-1 rounded-full border border-gray-200"></div>
                    )}
                    
                    {formData.color === color.id && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="bg-green-500 rounded-full p-1">
                          <Check className="h-3 w-3 text-white" />
                        </div>
                      </div>
                    )}
                  </button>
                ))}
                <div className="ml-2">
                  <p className="text-sm font-semibold text-gray-900">
                    {selectedColorOption?.name}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <label className="font-medium text-gray-700 text-sm">Quantità:</label>
                <select
                  name="quantity"
                  value={formData.quantity}
                  onChange={handleInputChange}
                  className="border-2 border-green-200 rounded-lg px-3 py-1 font-semibold focus:border-green-500 focus:ring-2 focus:ring-green-200 text-sm touch-manipulation"
                >
                  {[1, 2, 3, 4, 5].map(num => (
                    <option key={num} value={num}>{num}</option>
                  ))}
                </select>
              </div>
              <div className="bg-green-100 text-green-800 px-3 py-1 rounded-lg font-semibold text-xs">
                Consegna Gratuita
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-base font-bold text-gray-900 border-b border-gray-200 pb-2">
              Dati per la Consegna
            </h3>
            
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Nome Completo *</label>
              <input
                type="text"
                name="fullName"
                value={formData.fullName}
                onChange={handleInputChange}
                required
                className="w-full border-2 border-gray-200 rounded-lg px-4 py-3 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-colors text-base touch-manipulation"
                placeholder="Mario Rossi"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Numero di Telefono *</label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                required
                className="w-full border-2 border-gray-200 rounded-lg px-4 py-3 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-colors text-base touch-manipulation"
                placeholder="+39 123 456 7890"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Indirizzo *</label>
              <input
                type="text"
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                required
                className="w-full border-2 border-gray-200 rounded-lg px-4 py-3 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-colors text-base touch-manipulation"
                placeholder="Via Roma 123"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Città *</label>
                <input
                  type="text"
                  name="city"
                  value={formData.city}
                  onChange={handleInputChange}
                  required
                  className="w-full border-2 border-gray-200 rounded-lg px-4 py-3 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-colors text-base touch-manipulation"
                  placeholder="Milano"
                />
              </div>
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">CAP *</label>
                <input
                  type="text"
                  name="postalCode"
                  value={formData.postalCode}
                  onChange={handleInputChange}
                  required
                  pattern="[0-9]{5}"
                  maxLength={5}
                  className="w-full border-2 border-gray-200 rounded-lg px-4 py-3 focus:border-green-500 focus:ring-2 focus:ring-green-200 transition-colors text-base touch-manipulation"
                  placeholder="20100"
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-gradient-to-r from-green-600 via-green-700 to-emerald-600 hover:from-green-700 hover:via-green-800 hover:to-emerald-700 disabled:from-gray-400 disabled:to-gray-500 text-white font-black py-4 px-6 rounded-xl text-lg transition-all duration-300 transform active:scale-95 shadow-xl disabled:transform-none disabled:shadow-lg touch-manipulation"
          >
            {isSubmitting ? (
              <span className="flex items-center justify-center space-x-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                <span>Invio ordine...</span>
              </span>
            ) : (
              "CONFERMA ORDINE"
            )}
          </button>

          <p className="text-xs text-gray-500 text-center leading-relaxed">
            Cliccando "Conferma Ordine" accetti i nostri termini e condizioni. 
            Il pagamento avverrà solo alla consegna del prodotto. 
            <br />
            <strong>Nessun addebito anticipato.</strong>
          </p>

        </form>
      </div>
    </div>
  );
};

export default ChopperOrderForm;