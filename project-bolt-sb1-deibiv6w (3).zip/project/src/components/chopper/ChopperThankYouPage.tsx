import React from 'react';
import { CheckCircle, Package, Clock, Phone, Mail, Star, Gift, Truck, Shield, Heart } from 'lucide-react';

interface ChopperThankYouPageProps {
  orderNumber?: string;
  customerName?: string;
  totalAmount?: number;
  onClose?: () => void;
}

const ChopperThankYouPage: React.FC<ChopperThankYouPageProps> = ({ 
  orderNumber = "TC123456789", 
  customerName = "Cliente",
  totalAmount = 54.99,
  onClose 
}) => {
  const nextSteps = [
    {
      icon: Phone,
      title: "Conferma Telefonica",
      description: "Ti chiameremo entro 24 ore per confermare l'ordine e l'indirizzo di consegna",
      time: "Entro 24 ore",
      color: "green"
    },
    {
      icon: Package,
      title: "Preparazione Ordine",
      description: "Il tuo tritatutto verrà preparato e imballato con cura nel nostro magazzino",
      time: "Entro 24 ore",
      color: "blue"
    },
    {
      icon: Truck,
      title: "Spedizione Express",
      description: "Consegna gratuita direttamente a casa tua con corriere espresso",
      time: "24-48 ore",
      color: "purple"
    }
  ];

  const benefits = [
    "Tritatutto elettrico USB ricaricabile",
    "3 lame intercambiabili incluse",
    "Contenitore 250ml lavabile",
    "Cavo USB per ricarica",
    "Garanzia italiana di 1 anno",
    "Assistenza clienti dedicata"
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      green: "from-green-500 to-green-600 bg-green-50",
      blue: "from-blue-500 to-blue-600 bg-blue-50",
      purple: "from-purple-500 to-purple-600 bg-purple-50"
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-cyan-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8 lg:mb-12">
          <div className="relative inline-block mb-6">
            <div className="absolute inset-0 bg-green-400 rounded-full animate-ping opacity-75"></div>
            <div className="relative bg-gradient-to-r from-green-500 to-emerald-500 w-20 h-20 lg:w-24 lg:h-24 rounded-full flex items-center justify-center shadow-2xl">
              <CheckCircle className="h-10 w-10 lg:h-12 lg:w-12 text-white" />
            </div>
          </div>
          
          <h1 className="text-3xl sm:text-4xl lg:text-6xl font-black text-gray-900 mb-4">
            <span className="bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Grazie {customerName}!
            </span>
          </h1>
          
          <p className="text-xl sm:text-2xl lg:text-3xl text-gray-700 font-bold mb-2">
            Il Tuo Ordine è Stato Ricevuto
          </p>
          
          <div className="bg-white/80 backdrop-blur-sm inline-block px-6 py-3 lg:px-8 lg:py-4 rounded-2xl shadow-lg border border-white/50">
            <p className="text-gray-600 text-sm lg:text-base">
              Numero Ordine: <span className="font-black text-green-600 text-lg lg:text-xl">#{orderNumber}</span>
            </p>
          </div>
        </div>

        <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 lg:p-8 shadow-2xl border border-white/50 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <img 
                src="/Immagine 2025-07-01 230807 copy.jpg" 
                alt="Tritatutto Elettrico" 
                className="w-16 h-16 lg:w-20 lg:h-20 object-cover rounded-2xl shadow-lg"
              />
              <div>
                <h3 className="text-lg lg:text-xl font-bold text-gray-900">
                  Tritatutto Elettrico 3-in-1
                </h3>
                <p className="text-gray-600 text-sm lg:text-base">USB Ricaricabile</p>
                <div className="flex items-center space-x-2 mt-1">
                  <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-bold">54% SCONTO</span>
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-bold">SPEDIZIONE GRATUITA</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-2xl lg:text-3xl font-black text-green-600">€{totalAmount.toFixed(2)}</div>
              <div className="text-gray-500 line-through text-sm">€119,00</div>
              <div className="text-green-600 font-bold text-sm">Risparmi €{(119.00 - totalAmount).toFixed(2)}</div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 lg:p-6 rounded-2xl border border-green-100">
            <div className="flex items-center space-x-3 mb-3">
              <div className="bg-green-100 p-2 rounded-xl">
                <Shield className="h-5 w-5 lg:h-6 lg:w-6 text-green-600" />
              </div>
              <h4 className="text-lg lg:text-xl font-bold text-gray-900">Pagamento Sicuro</h4>
            </div>
            <p className="text-gray-700 text-sm lg:text-base leading-relaxed">
              <strong>Pagamento alla Consegna (Contrassegno)</strong><br />
              Pagherai solo quando riceverai il prodotto a casa tua. 
              Nessun addebito anticipato, massima sicurezza per te.
            </p>
          </div>
        </div>

        <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 lg:p-8 shadow-2xl border border-white/50 mb-8">
          <div className="text-center mb-6 lg:mb-8">
            <h2 className="text-2xl lg:text-3xl font-black text-gray-900 mb-2">
              Cosa Succede Ora?
            </h2>
            <p className="text-gray-600 text-sm lg:text-base">
              Ecco i prossimi passi per ricevere il tuo tritatutto elettrico
            </p>
          </div>

          <div className="space-y-4 lg:space-y-6">
            {nextSteps.map((step, index) => {
              const colorClasses = getColorClasses(step.color);
              const [gradient, bgColor] = colorClasses.split(' ');
              
              return (
                <div key={index} className="flex items-start space-x-4 lg:space-x-6 p-4 lg:p-6 bg-white rounded-2xl shadow-lg border border-gray-100">
                  <div className={`bg-gradient-to-r ${gradient} w-12 h-12 lg:w-16 lg:h-16 rounded-2xl flex items-center justify-center shadow-lg flex-shrink-0`}>
                    <step.icon className="h-6 w-6 lg:h-8 lg:w-8 text-white" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-lg lg:text-xl font-bold text-gray-900">{step.title}</h3>
                      <span className={`${bgColor} text-gray-700 px-3 py-1 rounded-full text-xs lg:text-sm font-semibold`}>
                        {step.time}
                      </span>
                    </div>
                    <p className="text-gray-600 leading-relaxed text-sm lg:text-base">
                      {step.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white/95 backdrop-blur-sm rounded-3xl p-6 lg:p-8 shadow-2xl border border-white/50 mb-8">
          <div className="text-center mb-6">
            <div className="flex items-center justify-center space-x-2 mb-3">
              <Gift className="h-6 w-6 lg:h-8 lg:w-8 text-green-600" />
              <h2 className="text-2xl lg:text-3xl font-black text-gray-900">
                Il Tuo Kit Completo Include
              </h2>
            </div>
            <p className="text-gray-600 text-sm lg:text-base">
              Tutto quello che ti serve per iniziare subito a tritare come un professionista
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3 lg:gap-4">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-center space-x-3 p-3 lg:p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-100">
                <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="font-semibold text-gray-900 text-sm lg:text-base">{benefit}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-600 via-emerald-600 to-cyan-600 rounded-3xl p-6 lg:p-8 text-white text-center shadow-2xl mb-8">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Heart className="h-6 w-6 lg:h-8 lg:w-8" />
            <h2 className="text-2xl lg:text-3xl font-black">Siamo Qui Per Te</h2>
          </div>
          
          <p className="text-lg lg:text-xl mb-6 opacity-90">
            Hai domande o hai bisogno di assistenza? Il nostro team è sempre disponibile
          </p>
          
          <div className="grid sm:grid-cols-2 gap-4 lg:gap-6 max-w-2xl mx-auto">
            <div className="bg-white/20 backdrop-blur-sm p-4 lg:p-6 rounded-2xl">
              <Phone className="h-6 w-6 lg:h-8 lg:w-8 mx-auto mb-3" />
              <h3 className="font-bold text-lg lg:text-xl mb-2">Chiamaci</h3>
              <p className="text-green-100 text-sm lg:text-base mb-2">+39 334 713 2255</p>
              <p className="text-green-200 text-xs lg:text-sm">Lun-Ven 9:00-18:00</p>
            </div>
            
            <div className="bg-white/20 backdrop-blur-sm p-4 lg:p-6 rounded-2xl">
              <Mail className="h-6 w-6 lg:h-8 lg:w-8 mx-auto mb-3" />
              <h3 className="font-bold text-lg lg:text-xl mb-2">Scrivici</h3>
              <p className="text-green-100 text-sm lg:text-base mb-2">contact@tuttosconto.store</p>
              <p className="text-green-200 text-xs lg:text-sm">Risposta in 24h</p>
            </div>
          </div>
        </div>

        <div className="text-center">
          <div className="bg-white/80 backdrop-blur-sm inline-block px-6 py-4 lg:px-8 lg:py-6 rounded-2xl shadow-lg border border-white/50">
            <div className="flex items-center justify-center space-x-2 mb-3">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 lg:h-6 lg:w-6 text-yellow-400 fill-current" />
              ))}
            </div>
            <p className="text-gray-700 font-semibold text-sm lg:text-base leading-relaxed">
              Grazie per aver scelto <strong className="text-green-600">Tuttosconto</strong>!<br />
              Ti unirai a oltre <strong>1.200 chef di casa soddisfatti</strong> in tutta Italia.
            </p>
          </div>
        </div>

        {onClose && (
          <div className="text-center mt-8">
            <button
              onClick={onClose}
              className="bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white font-bold py-3 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Chiudi
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ChopperThankYouPage;