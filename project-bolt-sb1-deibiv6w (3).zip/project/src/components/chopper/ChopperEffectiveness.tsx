import React from 'react';
import { Zap, Target, Clock, Award, CheckCircle, Star, ChefHat, Shield } from 'lucide-react';

const ChopperEffectiveness: React.FC = () => {
  const results = [
    {
      title: "Taglio Uniforme",
      description: "Taglia verdure in pezzi perfettamente uniformi",
      icon: Target,
      color: "green"
    },
    {
      title: "Lame Affilate", 
      description: "3 lame in acciaio inox per ogni tipo di verdura",
      icon: Shield,
      color: "blue"
    },
    {
      title: "Velocità Estrema",
      description: "Trita un'intera cipolla in meno di 10 secondi",
      icon: Clock,
      color: "purple"
    },
    {
      title: "Controllo Totale",
      description: "Scegli la consistenza perfetta per ogni ricetta",
      icon: ChefHat,
      color: "orange"
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      green: "from-green-500 to-green-600 text-green-600 bg-green-50",
      blue: "from-blue-500 to-blue-600 text-blue-600 bg-blue-50",
      purple: "from-purple-500 to-purple-600 text-purple-600 bg-purple-50",
      orange: "from-orange-500 to-orange-600 text-orange-600 bg-orange-50"
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section className="py-8 lg:py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Award className="h-5 w-5 lg:h-6 lg:w-6 text-orange-600" />
            <span className="text-orange-600 font-bold text-sm lg:text-base">PRESTAZIONI DIMOSTRATE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Risultati Che Parlano
            <span className="block bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
              Chiaro e Forte
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            Guarda la precisione reale del nostro tritatutto elettrico. 
            Verdure perfettamente tagliate in pochi secondi senza sforzo.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          <div className="order-2 lg:order-1">
            <div className="relative bg-white p-4 lg:p-6 rounded-3xl shadow-2xl border border-gray-100">
              <div className="relative rounded-2xl overflow-hidden bg-gray-100">
                <img
                  src="/C0380654-E9AB-4BAE-AA64-EFD772911C85 (1).gif"
                  alt="Dimostrazione precisione tritatutto - taglio perfetto di verdure con risultati uniformi"
                  className="w-full h-auto rounded-2xl"
                  style={{ maxHeight: '400px', objectFit: 'cover' }}
                />
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
                
                <div className="absolute top-4 left-4 bg-orange-500 text-white px-3 py-2 rounded-full flex items-center space-x-2 shadow-lg">
                  <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                  <span className="font-bold text-sm">PRECISIONE</span>
                </div>
                
                <div className="absolute bottom-4 right-4 bg-white/95 backdrop-blur-sm px-3 py-2 rounded-xl shadow-lg">
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-orange-600" />
                    <span className="font-bold text-gray-900 text-sm">PERFETTO</span>
                  </div>
                </div>
              </div>
              
              <div className="mt-4 lg:mt-6 text-center">
                <h3 className="text-lg lg:text-xl font-bold text-gray-900 mb-2">
                  Precisione Professionale in Azione
                </h3>
                <p className="text-gray-600 text-sm lg:text-base">
                  Guarda come taglia perfettamente ogni verdura con precisione millimetrica
                </p>
              </div>
            </div>
          </div>

          <div className="order-1 lg:order-2 space-y-4 lg:space-y-6">
            <div className="grid sm:grid-cols-2 gap-3 lg:gap-4">
              {results.map((result, index) => {
                const colorClasses = getColorClasses(result.color);
                const [gradientFrom, gradientTo, textColor, bgColor] = colorClasses.split(' ');
                
                return (
                  <div key={index} className="group bg-white p-3 lg:p-4 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
                    <div className="flex items-start space-x-3">
                      <div className={`bg-gradient-to-r ${gradientFrom} ${gradientTo} p-2 rounded-xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                        <result.icon className="h-4 w-4 lg:h-5 lg:w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-sm lg:text-base font-bold text-gray-900 mb-1">
                          {result.title}
                        </h3>
                        <p className="text-gray-600 text-xs lg:text-sm leading-relaxed">
                          {result.description}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="bg-gradient-to-r from-green-500 to-emerald-500 p-4 lg:p-6 rounded-2xl text-white text-center shadow-xl">
              <div className="flex items-center justify-center space-x-2 mb-2 lg:mb-3">
                <Award className="h-6 w-6 lg:h-8 lg:w-8" />
                <span className="text-lg lg:text-xl font-black">PRESTAZIONI GARANTITE</span>
              </div>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-black mb-2 lg:mb-3">
                Precisione Professionale Certificata
              </h3>
              <p className="text-green-100 text-sm lg:text-base max-w-2xl mx-auto">
                Testato su oltre <strong className="text-white">500 ricette diverse</strong>. 
                Se non taglia perfettamente, ti rimborsiamo tutto.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-8 lg:mt-12 bg-white p-4 lg:p-6 rounded-2xl shadow-lg border border-gray-100">
          <div className="text-center mb-4 lg:mb-6">
            <h3 className="text-lg lg:text-xl font-bold text-gray-900 mb-1">
              Specifiche Tecniche
            </h3>
            <p className="text-gray-600 text-xs lg:text-sm">
              Prestazioni certificate per uso professionale
            </p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
            <div className="text-center p-3 lg:p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl">
              <div className="text-lg lg:text-xl font-black text-green-600 mb-1">3 LAME</div>
              <div className="text-xs lg:text-sm font-semibold text-gray-900">Intercambiabili</div>
            </div>
            <div className="text-center p-3 lg:p-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
              <div className="text-lg lg:text-xl font-black text-blue-600 mb-1">USB</div>
              <div className="text-xs lg:text-sm font-semibold text-gray-900">Ricaricabile</div>
            </div>
            <div className="text-center p-3 lg:p-4 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl">
              <div className="text-lg lg:text-xl font-black text-purple-600 mb-1">250ML</div>
              <div className="text-xs lg:text-sm font-semibold text-gray-900">Contenitore</div>
            </div>
            <div className="text-center p-3 lg:p-4 bg-gradient-to-br from-orange-50 to-red-50 rounded-xl">
              <div className="text-lg lg:text-xl font-black text-orange-600 mb-1">INOX</div>
              <div className="text-xs lg:text-sm font-semibold text-gray-900">Lame Acciaio</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChopperEffectiveness;