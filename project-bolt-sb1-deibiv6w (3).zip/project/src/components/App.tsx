import React, { useState, useEffect } from 'react';
import { trackViewContent } from '../utils/facebookPixel';
import Header from './components/Header';
import Hero from './components/Hero';
import HowItWorks from './components/HowItWorks';
import ProductEffectiveness from './components/ProductEffectiveness';
import Features from './components/Features';
import Gallery from './components/Gallery';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import OrderForm from './components/OrderForm';
import Footer from './components/Footer';

function App() {
  const [isOrderFormOpen, setIsOrderFormOpen] = useState(false);
  const [showFixedButton, setShowFixedButton] = useState(false);

  const handleOrderClick = () => {
    setIsOrderFormOpen(true);
  };

  const handleCloseOrderForm = () => {
    setIsOrderFormOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      // Show fixed button when user scrolls down 300px
      setShowFixedButton(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Track page view on app load
  useEffect(() => {
    trackViewContent('Landing Page - Idropulitrice Professionale 21V', 'landing_page');
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero onOrderClick={handleOrderClick} />
      <HowItWorks />
      <ProductEffectiveness />
      <Features />
      <Gallery />
      <Testimonials />
      <FAQ />
      <Footer />
      <OrderForm isOpen={isOrderFormOpen} onClose={handleCloseOrderForm} />
      
      {/* Fixed Bottom Order Button - SIMPLE TEXT */}
      {showFixedButton && !isOrderFormOpen && (
        <div className="fixed bottom-0 left-0 right-0 z-40 p-4 bg-gradient-to-t from-white via-white to-transparent">
          <button
            onClick={handleOrderClick}
            className="w-full bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 hover:from-blue-700 hover:via-blue-800 hover:to-indigo-700 text-white font-black py-4 px-6 rounded-xl text-base transition-all duration-300 transform active:scale-95 shadow-2xl touch-manipulation"
          >
            ORDINA ORA
          </button>
        </div>
      )}
    </div>
  );
}

export default App;