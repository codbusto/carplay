import React from 'react';
import { CheckCircle, Star, Package } from 'lucide-react';

const Gallery: React.FC = () => {
  return (
    <section className="py-8 lg:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Star className="h-5 w-5 lg:h-6 lg:w-6 text-yellow-500" />
            <span className="text-yellow-600 font-bold text-sm lg:text-base">VERSATILITÀ PROFESSIONALE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Una Soluzione per
            <span className="block bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              Ogni Esigenza di Pulizia
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            Dalla pulizia dell'auto al lavaggio di superfici esterne, 
            scopri tutte le possibilità della tua nuova idropulitrice professionale
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 lg:gap-12 items-center">
          {/* Left Column - Images */}
          <div className="space-y-4 lg:space-y-6 order-2 lg:order-1">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-xl lg:rounded-2xl transform rotate-2 group-hover:rotate-1 transition-transform duration-300"></div>
              <img
                src="/558704a1-9f5b-44c4-b615-137783667cee_1188x1188.jpeg.format.webp"
                alt="Utilizzi versatili dell'idropulitrice professionale"
                className="relative w-full rounded-xl lg:rounded-2xl shadow-xl group-hover:shadow-2xl transition-shadow duration-300"
              />
              <div className="absolute top-3 left-3 lg:top-4 lg:left-4 bg-white/95 backdrop-blur-sm px-2 py-1 lg:px-3 lg:py-2 rounded-xl shadow-lg">
                <span className="font-bold text-gray-900 text-xs lg:text-sm">Risultati Professionali</span>
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-4 lg:p-6 rounded-xl lg:rounded-2xl border border-blue-100">
              <div className="flex items-center space-x-2 mb-3 lg:mb-4">
                <CheckCircle className="h-5 w-5 lg:h-6 lg:w-6 text-blue-600" />
                <h3 className="text-lg lg:text-xl font-bold text-gray-900">
                  Pulizia Professionale Ovunque
                </h3>
              </div>
              <p className="text-sm lg:text-base text-gray-700 leading-relaxed mb-3 lg:mb-4">
                Dalla pulizia dell'auto al lavaggio di terrazzi e superfici esterne, 
                la nostra idropulitrice garantisce risultati professionali con la 
                massima praticità d'uso. <strong>Potenza da 25 bar</strong> per rimuovere 
                anche lo sporco più ostinato.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="bg-blue-100 text-blue-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">Auto & Moto</span>
                <span className="bg-green-100 text-green-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">Casa & Giardino</span>
                <span className="bg-purple-100 text-purple-800 px-2 py-1 lg:px-3 lg:py-1 rounded-full text-xs font-semibold">Superfici Esterne</span>
              </div>
            </div>
          </div>

          {/* Right Column - Kit Details */}
          <div className="space-y-4 lg:space-y-6 order-1 lg:order-2">
            <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 lg:p-6 rounded-xl lg:rounded-2xl border border-green-100">
              <div className="flex items-center space-x-2 mb-3 lg:mb-4">
                <Package className="h-5 w-5 lg:h-6 lg:w-6 text-green-600" />
                <h3 className="text-lg lg:text-xl font-bold text-gray-900">
                  Kit Completo Premium Incluso
                </h3>
              </div>
              <div className="space-y-2 lg:space-y-3">
                {[
                  { item: "2 Batterie al litio 21V", detail: "Autonomia totale 90 minuti" },
                  { item: "Caricatore rapido intelligente", detail: "Ricarica completa in 1 ora" },
                  { item: "5 Ugelli intercambiabili", detail: "Per ogni tipo di superficie" },
                  { item: "Tubo flessibile 5 metri", detail: "Massima libertà di movimento" },
                  { item: "Valigetta professionale", detail: "Trasporto e stoccaggio sicuro" },
                  { item: "Manuale in italiano", detail: "Istruzioni complete e garanzia" }
                ].map((feature, index) => (
                  <div key={index} className="flex items-start space-x-2 p-2 lg:p-3 bg-white/80 rounded-xl">
                    <CheckCircle className="h-4 w-4 lg:h-5 lg:w-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-bold text-gray-900 block text-xs lg:text-sm">{feature.item}</span>
                      <span className="text-gray-600 text-xs">{feature.detail}</span>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 lg:mt-6 p-3 lg:p-4 bg-gradient-to-r from-green-500 to-green-600 rounded-xl text-white text-center">
                <p className="text-sm lg:text-base font-bold">Valore del Kit: €99,99</p>
                <p className="text-green-100 text-xs lg:text-sm">Oggi a soli €34,99 - Risparmia €65!</p>
              </div>
            </div>
            
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-xl lg:rounded-2xl transform -rotate-2 group-hover:-rotate-1 transition-transform duration-300"></div>
              <img
                src="/3b126687-186f-4566-90f0-c9aebe6bd962.webp"
                alt="Kit completo idropulitrice professionale"
                className="relative w-full rounded-xl lg:rounded-2xl shadow-xl group-hover:shadow-2xl transition-shadow duration-300"
              />
              <div className="absolute bottom-3 right-3 lg:bottom-4 lg:right-4 bg-white/95 backdrop-blur-sm px-2 py-1 lg:px-3 lg:py-2 rounded-xl shadow-lg">
                <span className="font-bold text-gray-900 text-xs lg:text-sm">Kit Completo</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Gallery;