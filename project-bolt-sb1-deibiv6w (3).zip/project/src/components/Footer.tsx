import React from 'react';
import { ShoppingCart, Phone, Mail, MapPin, Award, CheckCircle } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gradient-to-b from-gray-900 to-black text-white">
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Brand Section */}
          <div className="space-y-4 lg:space-y-6 sm:col-span-2 lg:col-span-1">
            <div className="flex items-center">
              <div className="bg-gradient-to-r from-blue-500 to-indigo-500 p-2 lg:p-3 rounded-2xl mr-3">
                <ShoppingCart className="h-6 w-6 lg:h-8 lg:w-8 text-white" />
              </div>
              <div>
                <span className="text-2xl lg:text-3xl font-black bg-gradient-to-r from-blue-400 to-indigo-400 bg-clip-text text-transparent">
                  Tuttosconto
                </span>
                <div className="flex items-center mt-1">
                  <Award className="h-3 w-3 lg:h-4 lg:w-4 text-yellow-400 mr-1" />
                  <span className="text-xs text-yellow-400 font-medium">Eccellenza Italiana</span>
                </div>
              </div>
            </div>
            <p className="text-gray-300 leading-relaxed text-base lg:text-lg">
              La tua destinazione per prodotti di qualità professionale a prezzi imbattibili. 
              Spedizione gratuita in tutta Italia e pagamento sicuro alla consegna.
            </p>
            <div className="flex items-center space-x-2 bg-green-900/50 p-3 lg:p-4 rounded-2xl">
              <CheckCircle className="h-5 w-5 lg:h-6 lg:w-6 text-green-400 flex-shrink-0" />
              <span className="font-semibold text-green-300 text-sm lg:text-base">Oltre 2.800 clienti soddisfatti</span>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-4 lg:space-y-6">
            <h3 className="text-xl lg:text-2xl font-bold text-white">Contatti</h3>
            <div className="space-y-3 lg:space-y-4">
              <div className="flex items-center group hover:text-blue-400 transition-colors">
                <div className="bg-blue-900/50 p-2 lg:p-3 rounded-xl mr-3 lg:mr-4 group-hover:bg-blue-800/50 transition-colors">
                  <Phone className="h-4 w-4 lg:h-5 lg:w-5 text-blue-400" />
                </div>
                <div>
                  <span className="font-semibold block text-sm lg:text-base">+39 334 713 2255</span>
                  <span className="text-gray-400 text-xs lg:text-sm">Lun-Ven 9:00-18:00</span>
                </div>
              </div>
              <div className="flex items-center group hover:text-blue-400 transition-colors">
                <div className="bg-blue-900/50 p-2 lg:p-3 rounded-xl mr-3 lg:mr-4 group-hover:bg-blue-800/50 transition-colors">
                  <Mail className="h-4 w-4 lg:h-5 lg:w-5 text-blue-400" />
                </div>
                <div>
                  <span className="font-semibold block text-sm lg:text-base">contact@tuttosconto.store</span>
                  <span className="text-gray-400 text-xs lg:text-sm">Risposta in 24h</span>
                </div>
              </div>
              <div className="flex items-center group hover:text-blue-400 transition-colors">
                <div className="bg-blue-900/50 p-2 lg:p-3 rounded-xl mr-3 lg:mr-4 group-hover:bg-blue-800/50 transition-colors">
                  <MapPin className="h-4 w-4 lg:h-5 lg:w-5 text-blue-400" />
                </div>
                <div>
                  <span className="font-semibold block text-sm lg:text-base">Milano, Italia</span>
                  <span className="text-gray-400 text-xs lg:text-sm">Sede operativa</span>
                </div>
              </div>
            </div>
          </div>

          {/* Legal Info */}
          <div className="space-y-4 lg:space-y-6">
            <h3 className="text-xl lg:text-2xl font-bold text-white">Informazioni Legali</h3>
            <div className="space-y-2 lg:space-y-3">
              <a href="#" className="block text-gray-300 hover:text-white transition-colors font-medium text-sm lg:text-base">
                Privacy Policy
              </a>
              <a href="#" className="block text-gray-300 hover:text-white transition-colors font-medium text-sm lg:text-base">
                Termini e Condizioni
              </a>
              <a href="#" className="block text-gray-300 hover:text-white transition-colors font-medium text-sm lg:text-base">
                Spedizioni e Resi
              </a>
              <a href="#" className="block text-gray-300 hover:text-white transition-colors font-medium text-sm lg:text-base">
                FAQ
              </a>
              <a href="#" className="block text-gray-300 hover:text-white transition-colors font-medium text-sm lg:text-base">
                Diritto di Recesso
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-8">
          <div className="flex flex-col lg:flex-row justify-between items-center space-y-4 lg:space-y-0">
            <p className="text-gray-400 text-center lg:text-left text-sm lg:text-base">
              &copy; 2025 Tuttosconto S.r.l. Tutti i diritti riservati.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;