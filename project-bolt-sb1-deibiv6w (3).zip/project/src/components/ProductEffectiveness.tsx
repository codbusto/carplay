import React from 'react';
import { Zap, Target, Clock, Award, CheckCircle, Star, Droplets, Shield } from 'lucide-react';

const ProductEffectiveness: React.FC = () => {
  const results = [
    {
      title: "Sporco Ostinato",
      description: "Rimuove fango, grasso e residui in secondi",
      icon: Target,
      color: "red"
    },
    {
      title: "Superfici Delicate", 
      description: "Pulisce senza danneggiare vernici o materiali",
      icon: Shield,
      color: "green"
    },
    {
      title: "Risultati Immediati",
      description: "Pulizia professionale visibile istantaneamente",
      icon: Clock,
      color: "blue"
    },
    {
      title: "Precisione Totale",
      description: "Controllo perfetto su ogni angolo e dettaglio",
      icon: Droplets,
      color: "cyan"
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      red: "from-red-500 to-red-600 text-red-600 bg-red-50",
      green: "from-green-500 to-green-600 text-green-600 bg-green-50",
      blue: "from-blue-500 to-blue-600 text-blue-600 bg-blue-50",
      cyan: "from-cyan-500 to-cyan-600 text-cyan-600 bg-cyan-50"
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section className="py-8 lg:py-16 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8 lg:mb-12">
          <div className="flex items-center justify-center space-x-2 mb-3 lg:mb-4">
            <Award className="h-5 w-5 lg:h-6 lg:w-6 text-orange-600" />
            <span className="text-orange-600 font-bold text-sm lg:text-base">POTENZA DIMOSTRATA</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-5xl font-black text-gray-900 mb-3 lg:mb-4">
            Risultati Che Parlano
            <span className="block bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
              Chiaro e Forte
            </span>
          </h2>
          <p className="text-base sm:text-lg lg:text-xl text-gray-600 max-w-3xl mx-auto">
            Guarda la potenza reale della nostra idropulitrice professionale. 
            Sporco ostinato rimosso in pochi secondi senza sforzo.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
          {/* Left Column - Demo Video */}
          <div className="order-2 lg:order-1">
            <div className="relative bg-white p-4 lg:p-6 rounded-3xl shadow-2xl border border-gray-100">
              {/* Video Container - CLEAN GIF WITHOUT ANY OVERLAYS */}
              <div className="relative rounded-2xl overflow-hidden bg-gray-100">
                <img
                  src="/gif-1-min.gif"
                  alt="Dimostrazione potenza idropulitrice - rimozione sporco ostinato da cerchi auto"
                  className="w-full h-auto rounded-2xl"
                  style={{ maxHeight: '400px', objectFit: 'cover' }}
                />
              </div>
              
              {/* Demo Description */}
              <div className="mt-4 lg:mt-6 text-center">
                <h3 className="text-lg lg:text-xl font-bold text-gray-900 mb-2">
                  Potenza Professionale in Azione
                </h3>
                <p className="text-gray-600 text-sm lg:text-base">
                  Guarda come rimuove facilmente lo sporco più ostinato senza sforzo
                </p>
              </div>
            </div>
          </div>

          {/* Right Column - Results Only */}
          <div className="order-1 lg:order-2 space-y-4 lg:space-y-6">
            {/* Results Grid */}
            <div className="grid sm:grid-cols-2 gap-3 lg:gap-4">
              {results.map((result, index) => {
                const colorClasses = getColorClasses(result.color);
                const [gradientFrom, gradientTo, textColor, bgColor] = colorClasses.split(' ');
                
                return (
                  <div key={index} className="group bg-white p-3 lg:p-4 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
                    <div className="flex items-start space-x-3">
                      <div className={`bg-gradient-to-r ${gradientFrom} ${gradientTo} p-2 rounded-xl shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                        <result.icon className="h-4 w-4 lg:h-5 lg:w-5 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-sm lg:text-base font-bold text-gray-900 mb-1">
                          {result.title}
                        </h3>
                        <p className="text-gray-600 text-xs lg:text-sm leading-relaxed">
                          {result.description}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Performance Guarantee */}
            <div className="bg-gradient-to-r from-orange-500 to-red-500 p-4 lg:p-6 rounded-2xl text-white text-center shadow-xl">
              <div className="flex items-center justify-center space-x-2 mb-2 lg:mb-3">
                <Award className="h-6 w-6 lg:h-8 lg:w-8" />
                <span className="text-lg lg:text-xl font-black">PRESTAZIONI GARANTITE</span>
              </div>
              <h3 className="text-xl sm:text-2xl lg:text-3xl font-black mb-2 lg:mb-3">
                Potenza Professionale Certificata
              </h3>
              <p className="text-orange-100 text-sm lg:text-base max-w-2xl mx-auto">
                Testata su oltre <strong className="text-white">1000 superfici diverse</strong>. 
                Se non rimuove lo sporco più ostinato, ti rimborsiamo tutto.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Technical Specs - MUCH SMALLER */}
        <div className="mt-8 lg:mt-12 bg-white p-4 lg:p-6 rounded-2xl shadow-lg border border-gray-100">
          <div className="text-center mb-4 lg:mb-6">
            <h3 className="text-lg lg:text-xl font-bold text-gray-900 mb-1">
              Specifiche Tecniche
            </h3>
            <p className="text-gray-600 text-xs lg:text-sm">
              Prestazioni certificate per uso professionale
            </p>
          </div>
          
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
            <div className="text-center p-3 lg:p-4 bg-gradient-to-br from-red-50 to-orange-50 rounded-xl">
              <div className="text-lg lg:text-xl font-black text-red-600 mb-1">25 BAR</div>
              <div className="text-xs lg:text-sm font-semibold text-gray-900">Pressione Max</div>
            </div>
            <div className="text-center p-3 lg:p-4 bg-gradient-to-br from-blue-50 to-cyan-50 rounded-xl">
              <div className="text-lg lg:text-xl font-black text-blue-600 mb-1">21V</div>
              <div className="text-xs lg:text-sm font-semibold text-gray-900">Batteria Litio</div>
            </div>
            <div className="text-center p-3 lg:p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl">
              <div className="text-lg lg:text-xl font-black text-green-600 mb-1">45 MIN</div>
              <div className="text-xs lg:text-sm font-semibold text-gray-900">Autonomia</div>
            </div>
            <div className="text-center p-3 lg:p-4 bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl">
              <div className="text-lg lg:text-xl font-black text-purple-600 mb-1">5M</div>
              <div className="text-xs lg:text-sm font-semibold text-gray-900">Tubo Flessibile</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProductEffectiveness;