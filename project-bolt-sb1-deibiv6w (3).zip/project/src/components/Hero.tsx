import React, { useState, useEffect } from 'react';
import { Star, Zap, Shield, Truck, Clock, Award, CreditCard, Battery, Package } from 'lucide-react';
import { trackInitiateCheckout, trackViewContent } from '../utils/facebookPixel';
import { trackButtonClick, trackSectionView } from '../utils/clarityTracking';

interface HeroProps {
  onOrderClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onOrderClick }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const images = [
    {
      src: "/71XZ+Px62ML._UF894,1000_QL80_.jpg",
      alt: "Idropulitrice Professionale 21V Tuttosconto"
    },
    {
      src: "/3b126687-186f-4566-90f0-c9aebe6bd962.webp",
      alt: "Kit completo idropulitrice professionale con accessori"
    },
    {
      src: "/558704a1-9f5b-44c4-b615-137783667cee_1188x1188.jpeg.format.webp",
      alt: "Idropulitrice in uso per pulizia terrazzi e superfici"
    }
  ];

  // Auto-rotate images every 4 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => 
        prevIndex === images.length - 1 ? 0 : prevIndex + 1
      );
    }, 4000);

    return () => clearInterval(interval);
  }, [images.length]);

  // Track hero view on component mount
  useEffect(() => {
    trackViewContent('Hero Section - Idropulitrice Professionale 21V', 'hero');
    trackSectionView('hero');
  }, []);

  const handleOrderClick = () => {
    // Track checkout initiation
    trackInitiateCheckout({
      content_name: 'Idropulitrice Professionale 21V',
      value: 54.99,
      currency: 'EUR'
    });
    
    // Track button click in Clarity
    trackButtonClick('order_now', 'hero_section');
    
    onOrderClick();
  };

  return (
    <section className="relative bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 py-8 lg:py-20 overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23000000' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`,
        }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="space-y-8 lg:space-y-0 lg:grid lg:grid-cols-2 lg:gap-16 lg:items-center">
          
          {/* Product Image - Mobile First - BIGGER IMAGES */}
          <div className="relative order-1 lg:order-2">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 to-indigo-600/20 rounded-3xl transform rotate-2 scale-105"></div>
            <div className="absolute inset-0 bg-gradient-to-l from-purple-400/10 to-pink-600/10 rounded-3xl transform -rotate-1 scale-110"></div>
            <div className="relative bg-white/95 backdrop-blur-sm rounded-3xl p-6 lg:p-8 shadow-2xl border border-white/50 overflow-hidden">
              {/* Image Container - MUCH BIGGER */}
              <div className="relative h-72 sm:h-80 lg:h-[500px]">
                {images.map((image, index) => (
                  <img
                    key={index}
                    src={image.src}
                    alt={image.alt}
                    className={`absolute inset-0 w-full h-full object-contain rounded-2xl transition-all duration-1000 ${
                      index === currentImageIndex 
                        ? 'opacity-100 scale-100' 
                        : 'opacity-0 scale-105'
                    }`}
                    onError={(e) => {
                      console.log(`Failed to load image: ${image.src}`);
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                ))}
              </div>
              
              {/* Image Indicators */}
              <div className="flex justify-center space-x-3 mt-4">
                {images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentImageIndex 
                        ? 'bg-blue-600 w-8' 
                        : 'bg-gray-300 hover:bg-gray-400'
                    }`}
                  />
                ))}
              </div>
              
              {/* FIXED BADGE - 58% SCONTO - BETTER POSITIONING */}
              <div className="absolute top-4 right-4 lg:top-6 lg:right-6 bg-gradient-to-r from-red-500 to-red-600 text-white px-4 py-2 lg:px-5 lg:py-3 rounded-2xl shadow-xl transform rotate-12 z-10">
                <span className="font-black text-sm lg:text-base">58% SCONTO</span>
              </div>
            </div>
          </div>

          {/* Content Section */}
          <div className="space-y-6 lg:space-y-8 order-2 lg:order-1">
            
            {/* Trust Indicators - Compact Mobile */}
            <div className="flex flex-col space-y-3 sm:flex-row sm:flex-wrap sm:items-center sm:space-y-0 sm:gap-4">
              <div className="flex items-center justify-center sm:justify-start space-x-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 lg:h-5 lg:w-5 text-yellow-400 fill-current" />
                ))}
                <span className="text-sm lg:text-base text-gray-600 ml-2 font-medium">(2,847 recensioni)</span>
              </div>
              <div className="flex items-center justify-center sm:justify-start space-x-2 bg-white/80 backdrop-blur-sm px-3 py-2 rounded-full">
                <Award className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-semibold text-gray-700">Prodotto dell'Anno 2025</span>
              </div>
            </div>
            
            {/* Main Headline - Mobile Optimized */}
            <div className="space-y-4 text-center lg:text-left">
              <h1 className="text-4xl sm:text-5xl lg:text-7xl font-black text-gray-900 leading-tight">
                <span className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 bg-clip-text text-transparent block">
                  Idropulitrice Pro 21V
                </span>
                <span className="text-2xl sm:text-3xl lg:text-5xl text-gray-700 block mt-2">
                  Cordless Premium
                </span>
              </h1>
              
              <p className="text-lg sm:text-xl lg:text-2xl text-gray-600 leading-relaxed max-w-2xl mx-auto lg:mx-0">
                Potenza professionale da <span className="font-bold text-blue-600">25 bar</span>, 
                autonomia <span className="font-bold text-blue-600">45 minuti</span>, 
                risultati impeccabili ovunque.
              </p>
            </div>

            {/* Feature Pills - Mobile Grid - UPDATED WITH 4 BENEFITS */}
            <div className="grid grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-4 rounded-xl shadow-sm">
                <div className="bg-blue-100 p-2 rounded-lg flex-shrink-0">
                  <Zap className="h-5 w-5 lg:h-6 lg:w-6 text-blue-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-base">21V Potente</span>
                  <span className="text-xs lg:text-sm text-gray-600">Batteria Litio</span>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-4 rounded-xl shadow-sm">
                <div className="bg-green-100 p-2 rounded-lg flex-shrink-0">
                  <Shield className="h-5 w-5 lg:h-6 lg:w-6 text-green-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-base">1 Anno</span>
                  <span className="text-xs lg:text-sm text-gray-600">Garanzia</span>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-4 rounded-xl shadow-sm">
                <div className="bg-purple-100 p-2 rounded-lg flex-shrink-0">
                  <Battery className="h-5 w-5 lg:h-6 lg:w-6 text-purple-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-base">2 Batterie</span>
                  <span className="text-xs lg:text-sm text-gray-600">Incluse</span>
                </div>
              </div>
              <div className="flex items-center space-x-3 bg-white/90 backdrop-blur-sm p-3 lg:p-4 rounded-xl shadow-sm">
                <div className="bg-orange-100 p-2 rounded-lg flex-shrink-0">
                  <Package className="h-5 w-5 lg:h-6 lg:w-6 text-orange-600" />
                </div>
                <div className="min-w-0">
                  <span className="font-bold text-gray-900 block text-sm lg:text-base">Kit Completo</span>
                  <span className="text-xs lg:text-sm text-gray-600">5 Accessori</span>
                </div>
              </div>
            </div>

            {/* Delivery Icons - Mobile Stack */}
            <div className="flex flex-col space-y-3 sm:flex-row sm:flex-wrap sm:justify-center lg:justify-start sm:space-y-0 sm:gap-3">
              <div className="flex items-center justify-center space-x-2 bg-green-50 px-4 py-3 rounded-full border border-green-200">
                <Truck className="h-5 w-5 text-green-600 flex-shrink-0" />
                <span className="text-sm lg:text-base font-semibold text-green-700">Consegna Gratuita</span>
              </div>
              <div className="flex items-center justify-center space-x-2 bg-blue-50 px-4 py-3 rounded-full border border-blue-200">
                <Clock className="h-5 w-5 text-blue-600 flex-shrink-0" />
                <span className="text-sm lg:text-base font-semibold text-blue-700">24-48h a Casa</span>
              </div>
              <div className="flex items-center justify-center space-x-2 bg-purple-50 px-4 py-3 rounded-full border border-purple-200">
                <CreditCard className="h-5 w-5 text-purple-600 flex-shrink-0" />
                <span className="text-sm lg:text-base font-semibold text-purple-700">Paga alla Consegna</span>
              </div>
            </div>

            {/* Pricing Section - UPDATED PRICE */}
            <div className="bg-white/95 backdrop-blur-sm p-4 lg:p-6 rounded-2xl shadow-lg border border-white/50">
              {/* Price Row - UPDATED PRICE */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl lg:text-3xl font-black text-blue-600">€54,99</span>
                  <div className="flex flex-col">
                    <span className="text-base lg:text-lg text-gray-500 line-through">€130,00</span>
                  </div>
                </div>
                <div className="text-center">
                  <div className="bg-red-100 text-red-800 px-3 py-2 rounded-xl">
                    <span className="font-bold text-xs">RISPARMIA</span>
                    <div className="font-black text-lg">€65</div>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA Button - SIMPLE TEXT "ORDINA ORA" */}
            <button
              onClick={handleOrderClick}
              className="w-full bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 hover:from-blue-700 hover:via-blue-800 hover:to-indigo-700 text-white font-black py-4 lg:py-5 px-8 rounded-2xl text-lg lg:text-xl transition-all duration-300 transform active:scale-95 lg:hover:scale-105 shadow-2xl touch-manipulation"
            >
              ORDINA ORA
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;