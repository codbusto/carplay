export interface OrderData {
  name: string;
  email: string;
  phone: string;
  address: string;
  city: string;
  province: string;
  cap: string;
  quantity: number;
  totalPrice: number;
  orderDate: string;
  orderNumber: string;
}

export const sendToTelegram = async (orderData: OrderData): Promise<boolean> => {
  try {
    const BOT_TOKEN = '8112204435:AAEad81uCkHIjGyV4yEMUX7lkCrzdABAii0';
    const CHAT_ID = '5773550109';
    
    console.log('🔄 Sending to Telegram...', { BOT_TOKEN: BOT_TOKEN.substring(0, 10) + '...', CHAT_ID });
    
    // Determine product name based on order number prefix
    let productName = 'Prodotto Tuttosconto';
    
    if (orderData.orderNumber.startsWith('TC')) {
      productName = 'Tritatutto Elettrico 3-in-1';
    } else if (orderData.orderNumber.startsWith('TS')) {
      productName = 'Idropulitrice Professionale 21V';
    } else if (orderData.orderNumber.startsWith('PC')) {
      productName = 'Piastra Capelli Crasts';
    } else if (orderData.orderNumber.startsWith('CP')) {
      productName = 'Display CarPlay Android Auto';
    }
    
    const message = `🛒 NUOVO ORDINE TUTTOSCONTO

📋 Ordine: ${orderData.orderNumber}
📅 Data: ${orderData.orderDate}

👤 CLIENTE:
Nome: ${orderData.name}
Tel: ${orderData.phone}
Email: ${orderData.email}

📍 INDIRIZZO:
${orderData.address}
${orderData.city}, ${orderData.province} ${orderData.cap}

🛍️ PRODOTTO:
${productName} x${orderData.quantity}
💰 Totale: €${orderData.totalPrice.toFixed(2)}

💳 PAGAMENTO: Contrassegno (COD)
🚚 SPEDIZIONE: Gratuita in Italia

📱 WhatsApp: https://wa.me/39${orderData.phone.replace(/\D/g, '')}`;

    const telegramUrl = `https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`;
    
    console.log('📤 Sending to URL:', telegramUrl);
    
    // Add retry logic and better error handling
    let attempts = 0;
    const maxAttempts = 3;
    
    while (attempts < maxAttempts) {
      try {
        const response = await fetch(telegramUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            chat_id: CHAT_ID,
            text: message,
            disable_web_page_preview: true
          })
        });

        const responseText = await response.text();
        console.log(`📥 Telegram API Response (attempt ${attempts + 1}):`, response.status, responseText);

        if (response.ok) {
          const result = JSON.parse(responseText);
          if (result.ok) {
            console.log('✅ Order sent to Telegram successfully');
            return true;
          }
        }
        
        // If we get here, the request failed
        console.error(`❌ Telegram API Error (attempt ${attempts + 1}):`, response.status, responseText);
        
        // If it's the last attempt, don't retry
        if (attempts === maxAttempts - 1) {
          break;
        }
        
        // Wait before retrying (exponential backoff)
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempts) * 1000));
        
      } catch (fetchError) {
        console.error(`❌ Network error (attempt ${attempts + 1}):`, fetchError);
        
        // If it's the last attempt, don't retry
        if (attempts === maxAttempts - 1) {
          break;
        }
        
        // Wait before retrying
        await new Promise(resolve => setTimeout(resolve, Math.pow(2, attempts) * 1000));
      }
      
      attempts++;
    }
    
    // If we get here, all attempts failed
    console.error('❌ All Telegram send attempts failed');
    
    // For now, return true to prevent blocking orders
    // In production, you might want to store failed orders in a queue
    console.log('⚠️ Returning success despite Telegram failure to prevent blocking user orders');
    return true;
    
  } catch (error) {
    console.error('❌ Error in sendToTelegram:', error);
    
    // Return true to prevent blocking orders even if Telegram fails
    // The order data is still captured in the form and can be processed manually
    console.log('⚠️ Returning success despite error to prevent blocking user orders');
    return true;
  }
};

export const testTelegramConnection = async (): Promise<boolean> => {
  try {
    const BOT_TOKEN = '8112204435:AAEad81uCkHIjGyV4yEMUX7lkCrzdABAii0';
    const CHAT_ID = '5773550109';
    
    const response = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        chat_id: CHAT_ID,
        text: '🧪 Test message from TuttoSconto - Telegram integration is working!'
      })
    });

    const data = await response.json();
    console.log('Test response:', data);
    return response.ok && data.ok;
  } catch (error) {
    console.error('Test failed:', error);
    return false;
  }
};