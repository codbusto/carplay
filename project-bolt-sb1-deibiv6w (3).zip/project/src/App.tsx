import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { initFacebookPixel, trackViewContent } from './utils/facebookPixel';
import { trackSectionView, setClarityUserProperties } from './utils/clarityTracking';
import { initCrispChat, setCrispUserData, trackCrispEvent } from './utils/crispChat';
import { updateMetaTags, getMetaDataForPage } from './utils/metaUtils';
import Header from './components/Header';
import Hero from './components/Hero';
import HowItWorks from './components/HowItWorks';
import ProductEffectiveness from './components/ProductEffectiveness';
import Features from './components/Features';
import Gallery from './components/Gallery';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import OrderForm from './components/OrderForm';
import Footer from './components/Footer';
import VegetableChopperPage from './pages/VegetableChopperPage';
import HairStraightenerPage from './pages/HairStraightenerPage';
import CarPlayPage from './pages/CarPlayPage';

function IdropulitricePage() {
  const [isOrderFormOpen, setIsOrderFormOpen] = useState(false);
  const [showFixedButton, setShowFixedButton] = useState(false);

  const handleOrderClick = () => {
    setIsOrderFormOpen(true);
    trackCrispEvent('order_form_opened', {
      product: 'idropulitrice_21v',
      page: 'landing_page'
    });
  };

  const handleCloseOrderForm = () => {
    setIsOrderFormOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      setShowFixedButton(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Update meta tags for idropulitrice page
    const metaData = getMetaDataForPage('idropulitrice');
    updateMetaTags(metaData);
    
    initFacebookPixel();
    initCrispChat();
    
    setTimeout(() => {
      trackViewContent('Landing Page - Idropulitrice Professionale 21V', 'landing_page');
      trackSectionView('landing_page');
      
      setCrispUserData({
        page_type: 'idropulitrice_landing',
        product_interest: 'idropulitrice_21v',
        visit_timestamp: new Date().toISOString()
      });
      
      trackCrispEvent('page_view', {
        page: 'idropulitrice_landing',
        product: 'idropulitrice_21v'
      });
    }, 1000);

    setClarityUserProperties({
      page_type: 'landing_page',
      product: 'idropulitrice_21v',
      visit_timestamp: new Date().toISOString(),
      user_agent: navigator.userAgent,
      screen_resolution: `${screen.width}x${screen.height}`,
      viewport_size: `${window.innerWidth}x${window.innerHeight}`
    });
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero onOrderClick={handleOrderClick} />
      <HowItWorks />
      <ProductEffectiveness />
      <Features />
      <Gallery />
      <Testimonials />
      <FAQ />
      <Footer />
      <OrderForm isOpen={isOrderFormOpen} onClose={handleCloseOrderForm} />
      
      {showFixedButton && !isOrderFormOpen && (
        <div className="fixed bottom-0 left-0 right-0 z-40 flex justify-center p-4 bg-gradient-to-t from-white via-white to-transparent">
          <button
            onClick={handleOrderClick}
            className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 hover:from-blue-700 hover:via-blue-800 hover:to-indigo-700 text-white font-black py-4 px-8 rounded-xl text-base transition-all duration-300 transform active:scale-95 shadow-2xl touch-manipulation max-w-xs"
          >
            ORDINA ORA
          </button>
        </div>
      )}
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<IdropulitricePage />} />
        <Route path="/tritatutto" element={<VegetableChopperPage />} />
        <Route path="/piastra-capelli" element={<HairStraightenerPage />} />
        <Route path="/carplay" element={<CarPlayPage />} />
      </Routes>
    </Router>
  );
}

export default App;