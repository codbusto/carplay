import React, { useState, useEffect } from 'react';
import { ArrowUp } from 'lucide-react';
import { initFacebookPixel, trackViewContent } from '../utils/facebookPixel';
import { trackSectionView, setClarityUserProperties } from '../utils/clarityTracking';
import { initCrispChat, setCrispUserData, trackCrispEvent } from '../utils/crispChat';
import { updateMetaTags, getMetaDataForPage } from '../utils/metaUtils';
import CarPlayHeader from '../components/carplay/CarPlayHeader';
import CarPlayHero from '../components/carplay/CarPlayHero';
import CarPlayFeatures from '../components/carplay/CarPlayFeatures';
import CarPlayBenefits from '../components/carplay/CarPlayBenefits';
import CarPlayCompatibility from '../components/carplay/CarPlayCompatibility';
import CarPlayTestimonials from '../components/carplay/CarPlayTestimonials';
import CarPlayFAQ from '../components/carplay/CarPlayFAQ';
import CarPlayOrderForm from '../components/carplay/CarPlayOrderForm';
import CarPlayInstallation from '../components/carplay/CarPlayInstallation';
import CarPlayAdvancedBenefits from '../components/carplay/CarPlayAdvancedBenefits';
import Footer from '../components/Footer';

// Moving Benefits Banner Component
const MovingBenefitsBanner: React.FC = () => {
  const benefits = [
    "🚚 SPEDIZIONE GRATUITA",
    "✅ GARANZIA RIMBORSO",
    "💳 PAGA ALLA CONSEGNA",
    "🎯 INSTALLAZIONE 2 MIN",
    "📞 ASSISTENZA 24/7",
    "💰 PAGA IN 3 RATE CON KLARNA",
    "🔒 ACQUISTO SICURO",
    "⚡ PRONTO ALL'USO"
  ];

  return (
    <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 overflow-hidden relative">
      <div className="flex animate-scroll whitespace-nowrap">
        {/* Duplicate the benefits array to create seamless loop */}
        {[...benefits, ...benefits].map((benefit, index) => (
          <span key={index} className="inline-flex items-center mx-8 text-sm lg:text-base font-semibold">
            {benefit}
          </span>
        ))}
      </div>
    </div>
  );
};

function CarPlayPage() {
  const [isOrderFormOpen, setIsOrderFormOpen] = useState(false);
  const [showFixedButton, setShowFixedButton] = useState(false);
  const [showBackToTop, setShowBackToTop] = useState(false);

  const handleOrderClick = () => {
    setIsOrderFormOpen(true);
    trackCrispEvent('order_form_opened', {
      product: 'carplay_android_auto',
      page: 'carplay_landing'
    });
  };

  const handleCloseOrderForm = () => {
    setIsOrderFormOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      setShowFixedButton(window.scrollY > 300);
      setShowBackToTop(window.scrollY > 500);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Update meta tags for CarPlay page
    const metaData = getMetaDataForPage('carplay');
    updateMetaTags(metaData);
    
    initFacebookPixel();
    initCrispChat();
    
    setTimeout(() => {
      trackViewContent('Landing Page - CarPlay Android Auto', 'landing_page');
      trackSectionView('landing_page');
      
      setCrispUserData({
        page_type: 'carplay_landing',
        product_interest: 'carplay_android_auto',
        visit_timestamp: new Date().toISOString()
      });
      
      trackCrispEvent('page_view', {
        page: 'carplay_landing',
        product: 'carplay_android_auto'
      });
    }, 1000);

    setClarityUserProperties({
      page_type: 'landing_page',
      product: 'carplay_android_auto',
      visit_timestamp: new Date().toISOString(),
      user_agent: navigator.userAgent,
      screen_resolution: `${screen.width}x${screen.height}`,
      viewport_size: `${window.innerWidth}x${window.innerHeight}`
    });
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <div className="min-h-screen bg-white">
      <CarPlayHeader />
      <CarPlayHero onOrderClick={handleOrderClick} />
      <MovingBenefitsBanner />
      <CarPlayInstallation />
      <CarPlayBenefits />
      <CarPlayCompatibility />
      <MovingBenefitsBanner />
      <CarPlayTestimonials />
      <CarPlayFAQ />
      <Footer />
      <CarPlayOrderForm 
        isOpen={isOrderFormOpen} 
        onClose={handleCloseOrderForm}
      />
      
      {showFixedButton && !isOrderFormOpen && (
        <div className="fixed bottom-0 left-0 right-0 z-40 flex justify-center p-4">
          <button
            onClick={handleOrderClick}
            className="bg-gradient-to-r from-blue-600 via-blue-700 to-indigo-600 hover:from-blue-700 hover:via-blue-800 hover:to-indigo-700 text-white font-black py-3 px-6 rounded-xl text-sm transition-all duration-300 transform active:scale-95 shadow-2xl touch-manipulation max-w-xs mx-auto"
          >
            PAGA ALLA CONSEGNA
          </button>
        </div>
      )}
      
      {/* Back to Top Button */}
      {showBackToTop && (
        <div className="fixed bottom-20 right-4 z-30">
          <button
            onClick={scrollToTop}
            className="bg-white/90 backdrop-blur-sm hover:bg-white text-blue-600 p-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110 border border-blue-200"
            title="Torna all'inizio"
          >
            <ArrowUp className="h-5 w-5" />
          </button>
        </div>
      )}
    </div>
  );
}

export default CarPlayPage;