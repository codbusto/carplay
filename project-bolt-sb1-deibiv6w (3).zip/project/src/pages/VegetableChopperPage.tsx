import React, { useState, useEffect } from 'react';
import { initFacebookPixel, trackViewContent, trackTritatuttoEvent } from '../utils/facebookPixel';
import { trackSectionView, setClarityUserProperties } from '../utils/clarityTracking';
import { initCrispChat, setCrispUserData, trackCrispEvent } from '../utils/crispChat';
import { updateMetaTags, getMetaDataForPage } from '../utils/metaUtils';
import ChopperHeader from '../components/chopper/ChopperHeader';
import ChopperHero from '../components/chopper/ChopperHero';
import ChopperHowItWorks from '../components/chopper/ChopperHowItWorks';
import ChopperEffectiveness from '../components/chopper/ChopperEffectiveness';
import ChopperFeatures from '../components/chopper/ChopperFeatures';
import ChopperGallery from '../components/chopper/ChopperGallery';
import ChopperTestimonials from '../components/chopper/ChopperTestimonials';
import ChopperFAQ from '../components/chopper/ChopperFAQ';
import ChopperOrderForm from '../components/chopper/ChopperOrderForm';
import Footer from '../components/Footer';

function VegetableChopperPage() {
  const [isOrderFormOpen, setIsOrderFormOpen] = useState(false);
  const [showFixedButton, setShowFixedButton] = useState(false);
  const [selectedColor, setSelectedColor] = useState<string | null>(null);

  const handleOrderClick = (colorId?: string) => {
    if (colorId) {
      setSelectedColor(colorId);
    }
    setIsOrderFormOpen(true);
    
    // Single tracking event for order button
    trackTritatuttoEvent('InitiateCheckout', {
      button_location: 'fixed_bottom_button',
      selected_color: colorId || 'no_color_selected',
      value: 54.99,
      currency: 'EUR'
    });
    
    trackCrispEvent('order_form_opened', {
      product: 'tritatutto_3in1',
      page: 'tritatutto_landing',
      selected_color: colorId || 'no_color_selected'
    });
  };

  const handleCloseOrderForm = () => {
    setIsOrderFormOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      setShowFixedButton(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Update meta tags for tritatutto page
    const metaData = getMetaDataForPage('tritatutto');
    updateMetaTags(metaData);
    
    // Initialize tracking services
    initFacebookPixel();
    initCrispChat();
    
    // Single page view tracking after delay
    setTimeout(() => {
      trackViewContent('Landing Page - Tritatutto Elettrico 3-in-1', 'landing_page');
      trackSectionView('landing_page');
      
      setCrispUserData({
        page_type: 'tritatutto_landing',
        product_interest: 'tritatutto_3in1',
        visit_timestamp: new Date().toISOString()
      });
      
      trackCrispEvent('page_view', {
        page: 'tritatutto_landing',
        product: 'tritatutto_3in1'
      });
      
      console.log('🎯 Tritatutto Page: Tracking initialized (no duplicates)');
    }, 1000);

    setClarityUserProperties({
      page_type: 'landing_page',
      product: 'tritatutto_3in1',
      visit_timestamp: new Date().toISOString(),
      user_agent: navigator.userAgent,
      screen_resolution: `${screen.width}x${screen.height}`,
      viewport_size: `${window.innerWidth}x${window.innerHeight}`
    });
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <ChopperHeader />
      <ChopperHero 
        onOrderClick={handleOrderClick}
        onColorChange={setSelectedColor}
      />
      <ChopperHowItWorks />
      <ChopperEffectiveness />
      <ChopperFeatures />
      <ChopperGallery />
      <ChopperTestimonials />
      <ChopperFAQ />
      <Footer />
      <ChopperOrderForm 
        isOpen={isOrderFormOpen} 
        onClose={handleCloseOrderForm}
        selectedColor={selectedColor}
      />
      
      {showFixedButton && !isOrderFormOpen && (
        <div className="fixed bottom-0 left-0 right-0 z-40 flex justify-center p-4 bg-gradient-to-t from-white via-white to-transparent">
          <button
            onClick={() => handleOrderClick()}
            className="bg-gradient-to-r from-green-600 via-green-700 to-emerald-600 hover:from-green-700 hover:via-green-800 hover:to-emerald-700 text-white font-black py-4 px-8 rounded-xl text-base transition-all duration-300 transform active:scale-95 shadow-2xl touch-manipulation max-w-xs"
          >
            ORDINA ORA
          </button>
        </div>
      )}
    </div>
  );
}

export default VegetableChopperPage;