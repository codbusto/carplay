import React, { useState, useEffect } from 'react';
import { initFacebookPixel, trackViewContent, trackPiastraCapelliEvent } from '../utils/facebookPixel';
import { trackSectionView, setClarityUserProperties } from '../utils/clarityTracking';
import { initCrispChat, setCrispUserData, trackCrispEvent } from '../utils/crispChat';
import { updateMetaTags, getMetaDataForPage } from '../utils/metaUtils';
import HairStraightenerHeader from '../components/hair-straightener/HairStraightenerHeader';
import HairStraightenerHero from '../components/hair-straightener/HairStraightenerHero';
import HairStraightenerHowItWorks from '../components/hair-straightener/HairStraightenerHowItWorks';
import HairStraightenerEffectiveness from '../components/hair-straightener/HairStraightenerEffectiveness';
import HairStraightenerFeatures from '../components/hair-straightener/HairStraightenerFeatures';
import HairStraightenerGallery from '../components/hair-straightener/HairStraightenerGallery';
import HairStraightenerTestimonials from '../components/hair-straightener/HairStraightenerTestimonials';
import HairStraightenerFAQ from '../components/hair-straightener/HairStraightenerFAQ';
import HairStraightenerOrderForm from '../components/hair-straightener/HairStraightenerOrderForm';
import Footer from '../components/Footer';

function HairStraightenerPage() {
  const [isOrderFormOpen, setIsOrderFormOpen] = useState(false);
  const [showFixedButton, setShowFixedButton] = useState(false);

  const handleOrderClick = () => {
    setIsOrderFormOpen(true);
    
    // Single tracking event for order button
    trackPiastraCapelliEvent('InitiateCheckout', {
      button_location: 'fixed_bottom_button',
      value: 39.99,
      currency: 'EUR'
    });
    
    trackCrispEvent('order_form_opened', {
      product: 'piastra_capelli_crasts',
      page: 'hair_straightener_landing'
    });
  };

  const handleCloseOrderForm = () => {
    setIsOrderFormOpen(false);
  };

  useEffect(() => {
    const handleScroll = () => {
      setShowFixedButton(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    // Update meta tags for hair straightener page
    const metaData = getMetaDataForPage('hair-straightener');
    updateMetaTags(metaData);
    
    // Initialize tracking services
    initFacebookPixel();
    initCrispChat();
    
    // Single page view tracking after delay
    setTimeout(() => {
      trackViewContent('Landing Page - Piastra Capelli Crasts', 'landing_page');
      trackSectionView('landing_page');
      
      setCrispUserData({
        page_type: 'hair_straightener_landing',
        product_interest: 'piastra_capelli_crasts',
        visit_timestamp: new Date().toISOString()
      });
      
      trackCrispEvent('page_view', {
        page: 'hair_straightener_landing',
        product: 'piastra_capelli_crasts'
      });
      
      console.log('🎯 Piastra Capelli Page: Tracking initialized (no duplicates)');
    }, 1000);

    setClarityUserProperties({
      page_type: 'landing_page',
      product: 'piastra_capelli_crasts',
      visit_timestamp: new Date().toISOString(),
      user_agent: navigator.userAgent,
      screen_resolution: `${screen.width}x${screen.height}`,
      viewport_size: `${window.innerWidth}x${window.innerHeight}`
    });
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <HairStraightenerHeader />
      <HairStraightenerHero onOrderClick={handleOrderClick} />
      <HairStraightenerHowItWorks />
      <HairStraightenerEffectiveness />
      <HairStraightenerFeatures />
      <HairStraightenerGallery />
      <HairStraightenerTestimonials />
      <HairStraightenerFAQ />
      <Footer />
      <HairStraightenerOrderForm 
        isOpen={isOrderFormOpen} 
        onClose={handleCloseOrderForm}
      />
      
      {showFixedButton && !isOrderFormOpen && (
        <div className="fixed bottom-0 left-0 right-0 z-40 flex justify-center p-4 bg-gradient-to-t from-white via-white to-transparent">
          <button
            onClick={handleOrderClick}
            className="bg-gradient-to-r from-pink-600 via-pink-700 to-rose-600 hover:from-pink-700 hover:via-pink-800 hover:to-rose-700 text-white font-black py-4 px-8 rounded-xl text-base transition-all duration-300 transform active:scale-95 shadow-2xl touch-manipulation max-w-xs"
          >
            ORDINA ORA
          </button>
        </div>
      )}
    </div>
  );
}

export default HairStraightenerPage;