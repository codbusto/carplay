exports.handler = async (event, context) => {
  // Enable CORS
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: '',
    };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' }),
    };
  }

  try {
    const orderData = JSON.parse(event.body);
    
    // Shopify configuration
    const SHOPIFY_STORE_URL = 'ts6fiy-wq.myshopify.com';
    const ACCESS_TOKEN = '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';
    const API_VERSION = '2024-01';

    // Create order payload for Shopify Admin API
    const orderPayload = {
      order: {
        line_items: [
          {
            title: "Idropulitrice Professionale 21V",
            price: "59.99",
            quantity: orderData.quantity,
            requires_shipping: true,
            taxable: true,
            fulfillment_service: "manual"
          }
        ],
        customer: {
          first_name: orderData.firstName,
          last_name: orderData.lastName,
          email: orderData.email,
          phone: orderData.phone
        },
        shipping_address: {
          first_name: orderData.firstName,
          last_name: orderData.lastName,
          address1: orderData.address,
          city: orderData.city,
          province: orderData.province || '',
          zip: orderData.postalCode,
          country: "Italy",
          country_code: "IT"
        },
        billing_address: {
          first_name: orderData.firstName,
          last_name: orderData.lastName,
          address1: orderData.address,
          city: orderData.city,
          province: orderData.province || '',
          zip: orderData.postalCode,
          country: "Italy",
          country_code: "IT"
        },
        financial_status: "pending",
        fulfillment_status: null,
        tags: ["COD", "Tuttosconto", "Landing-Page"],
        note: `Ordine da Landing Page Tuttosconto - Pagamento alla Consegna\nNote: ${orderData.notes || 'Nessuna nota'}`,
        shipping_lines: [
          {
            title: "Spedizione Gratuita Italia",
            price: "0.00",
            code: "FREE_SHIPPING_IT"
          }
        ],
        total_price: (59.99 * orderData.quantity).toFixed(2),
        subtotal_price: (59.99 * orderData.quantity).toFixed(2),
        total_tax: "0.00",
        currency: "EUR",
        source_name: "Tuttosconto Landing Page",
        processing_method: "manual"
      }
    };

    console.log('Creating order in Shopify:', JSON.stringify(orderPayload, null, 2));

    // Make API call to Shopify Admin API
    const response = await fetch(`https://${SHOPIFY_STORE_URL}/admin/api/${API_VERSION}/orders.json`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Shopify-Access-Token': ACCESS_TOKEN,
        'Accept': 'application/json'
      },
      body: JSON.stringify(orderPayload)
    });

    const responseText = await response.text();
    console.log('Shopify response:', response.status, responseText);

    if (response.ok) {
      const result = JSON.parse(responseText);
      console.log('Order created successfully:', result.order.order_number);
      
      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          order: {
            order_number: result.order.order_number,
            total_price: result.order.total_price,
            id: result.order.id
          }
        }),
      };
    } else {
      console.error('Shopify API Error:', response.status, responseText);
      
      let errorMessage = 'Errore sconosciuto';
      try {
        const errorData = JSON.parse(responseText);
        if (errorData.errors) {
          errorMessage = Object.values(errorData.errors).flat().join(', ');
        }
      } catch (e) {
        errorMessage = responseText || `HTTP ${response.status}`;
      }
      
      return {
        statusCode: response.status,
        headers,
        body: JSON.stringify({
          success: false,
          error: `Errore Shopify (${response.status}): ${errorMessage}`
        }),
      };
    }
  } catch (error) {
    console.error('Function error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message || 'Errore interno del server'
      }),
    };
  }
};